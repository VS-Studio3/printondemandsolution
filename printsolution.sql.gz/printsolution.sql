-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Время создания: Июл 21 2014 г., 12:42
-- Версия сервера: 5.5.25
-- Версия PHP: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `printsolution`
--

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_assets`
--

CREATE TABLE IF NOT EXISTS `sdc98_assets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `parent_id` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set parent.',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `level` int(10) unsigned NOT NULL COMMENT 'The cached level in the nested tree.',
  `name` varchar(50) NOT NULL COMMENT 'The unique name for the asset.\n',
  `title` varchar(100) NOT NULL COMMENT 'The descriptive title for the asset.',
  `rules` varchar(5120) NOT NULL COMMENT 'JSON encoded access control.',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_asset_name` (`name`),
  KEY `idx_lft_rgt` (`lft`,`rgt`),
  KEY `idx_parent_id` (`parent_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=39 ;

--
-- Дамп данных таблицы `sdc98_assets`
--

INSERT INTO `sdc98_assets` (`id`, `parent_id`, `lft`, `rgt`, `level`, `name`, `title`, `rules`) VALUES
(1, 0, 1, 75, 0, 'root.1', 'Root Asset', '{"core.login.site":{"6":1,"2":1},"core.login.admin":{"6":1},"core.login.offline":{"6":1},"core.admin":{"8":1},"core.manage":{"7":1},"core.create":{"6":1,"3":1},"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1},"core.edit.own":{"6":1,"3":1}}'),
(2, 1, 1, 2, 1, 'com_admin', 'com_admin', '{}'),
(3, 1, 3, 6, 1, 'com_banners', 'com_banners', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(4, 1, 7, 8, 1, 'com_cache', 'com_cache', '{"core.admin":{"7":1},"core.manage":{"7":1}}'),
(5, 1, 9, 10, 1, 'com_checkin', 'com_checkin', '{"core.admin":{"7":1},"core.manage":{"7":1}}'),
(6, 1, 11, 12, 1, 'com_config', 'com_config', '{}'),
(7, 1, 13, 16, 1, 'com_contact', 'com_contact', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(8, 1, 17, 24, 1, 'com_content', 'com_content', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":{"3":1},"core.delete":[],"core.edit":{"4":1},"core.edit.state":{"5":1},"core.edit.own":[]}'),
(9, 1, 25, 26, 1, 'com_cpanel', 'com_cpanel', '{}'),
(10, 1, 27, 28, 1, 'com_installer', 'com_installer', '{"core.admin":[],"core.manage":{"7":0},"core.delete":{"7":0},"core.edit.state":{"7":0}}'),
(11, 1, 29, 30, 1, 'com_languages', 'com_languages', '{"core.admin":{"7":1},"core.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(12, 1, 31, 32, 1, 'com_login', 'com_login', '{}'),
(13, 1, 33, 34, 1, 'com_mailto', 'com_mailto', '{}'),
(14, 1, 35, 36, 1, 'com_massmail', 'com_massmail', '{}'),
(15, 1, 37, 38, 1, 'com_media', 'com_media', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":{"3":1},"core.delete":{"5":1}}'),
(16, 1, 39, 40, 1, 'com_menus', 'com_menus', '{"core.admin":{"7":1},"core.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(17, 1, 41, 42, 1, 'com_messages', 'com_messages', '{"core.admin":{"7":1},"core.manage":{"7":1}}'),
(18, 1, 43, 44, 1, 'com_modules', 'com_modules', '{"core.admin":{"7":1},"core.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(19, 1, 45, 48, 1, 'com_newsfeeds', 'com_newsfeeds', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(20, 1, 49, 50, 1, 'com_plugins', 'com_plugins', '{"core.admin":{"7":1},"core.manage":[],"core.edit":[],"core.edit.state":[]}'),
(21, 1, 51, 52, 1, 'com_redirect', 'com_redirect', '{"core.admin":{"7":1},"core.manage":[]}'),
(22, 1, 53, 54, 1, 'com_search', 'com_search', '{"core.admin":{"7":1},"core.manage":{"6":1}}'),
(23, 1, 55, 56, 1, 'com_templates', 'com_templates', '{"core.admin":{"7":1},"core.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(24, 1, 57, 60, 1, 'com_users', 'com_users', '{"core.admin":{"7":1},"core.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(25, 1, 61, 64, 1, 'com_weblinks', 'com_weblinks', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":{"3":1},"core.delete":[],"core.edit":{"4":1},"core.edit.state":{"5":1},"core.edit.own":[]}'),
(26, 1, 65, 66, 1, 'com_wrapper', 'com_wrapper', '{}'),
(27, 8, 18, 23, 2, 'com_content.category.2', 'Без категории', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(28, 3, 4, 5, 2, 'com_banners.category.3', 'Без категории', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(29, 7, 14, 15, 2, 'com_contact.category.4', 'Без категории', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(30, 19, 46, 47, 2, 'com_newsfeeds.category.5', 'Без категории', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(31, 25, 62, 63, 2, 'com_weblinks.category.6', 'Без категории', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(32, 24, 58, 59, 1, 'com_users.category.7', 'Без категории', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(33, 1, 67, 68, 1, 'com_finder', 'com_finder', '{"core.admin":{"7":1},"core.manage":{"6":1}}'),
(34, 1, 69, 70, 1, 'com_joomlaupdate', 'com_joomlaupdate', '{"core.admin":[],"core.manage":[],"core.delete":[],"core.edit.state":[]}'),
(35, 1, 71, 72, 1, 'com_zoo', 'com_zoo', '{}'),
(36, 27, 19, 20, 3, 'com_content.article.1', 'О нас', '{"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1}}'),
(37, 27, 21, 22, 3, 'com_content.article.2', 'Контакты', '{"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1}}'),
(38, 1, 73, 74, 1, 'com_foxcontact', 'com_foxcontact', '{}');

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_associations`
--

CREATE TABLE IF NOT EXISTS `sdc98_associations` (
  `id` varchar(50) NOT NULL COMMENT 'A reference to the associated item.',
  `context` varchar(50) NOT NULL COMMENT 'The context of the associated item.',
  `key` char(32) NOT NULL COMMENT 'The key for the association computed from an md5 on associated ids.',
  PRIMARY KEY (`context`,`id`),
  KEY `idx_key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_banners`
--

CREATE TABLE IF NOT EXISTS `sdc98_banners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `imptotal` int(11) NOT NULL DEFAULT '0',
  `impmade` int(11) NOT NULL DEFAULT '0',
  `clicks` int(11) NOT NULL DEFAULT '0',
  `clickurl` varchar(200) NOT NULL DEFAULT '',
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  `custombannercode` varchar(2048) NOT NULL,
  `sticky` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `params` text NOT NULL,
  `own_prefix` tinyint(1) NOT NULL DEFAULT '0',
  `metakey_prefix` varchar(255) NOT NULL DEFAULT '',
  `purchase_type` tinyint(4) NOT NULL DEFAULT '-1',
  `track_clicks` tinyint(4) NOT NULL DEFAULT '-1',
  `track_impressions` tinyint(4) NOT NULL DEFAULT '-1',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `reset` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `language` char(7) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_state` (`state`),
  KEY `idx_own_prefix` (`own_prefix`),
  KEY `idx_metakey_prefix` (`metakey_prefix`),
  KEY `idx_banner_catid` (`catid`),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_banner_clients`
--

CREATE TABLE IF NOT EXISTS `sdc98_banner_clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `contact` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `extrainfo` text NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `metakey` text NOT NULL,
  `own_prefix` tinyint(4) NOT NULL DEFAULT '0',
  `metakey_prefix` varchar(255) NOT NULL DEFAULT '',
  `purchase_type` tinyint(4) NOT NULL DEFAULT '-1',
  `track_clicks` tinyint(4) NOT NULL DEFAULT '-1',
  `track_impressions` tinyint(4) NOT NULL DEFAULT '-1',
  PRIMARY KEY (`id`),
  KEY `idx_own_prefix` (`own_prefix`),
  KEY `idx_metakey_prefix` (`metakey_prefix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_banner_tracks`
--

CREATE TABLE IF NOT EXISTS `sdc98_banner_tracks` (
  `track_date` datetime NOT NULL,
  `track_type` int(10) unsigned NOT NULL,
  `banner_id` int(10) unsigned NOT NULL,
  `count` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`track_date`,`track_type`,`banner_id`),
  KEY `idx_track_date` (`track_date`),
  KEY `idx_track_type` (`track_type`),
  KEY `idx_banner_id` (`banner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_categories`
--

CREATE TABLE IF NOT EXISTS `sdc98_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `lft` int(11) NOT NULL DEFAULT '0',
  `rgt` int(11) NOT NULL DEFAULT '0',
  `level` int(10) unsigned NOT NULL DEFAULT '0',
  `path` varchar(255) NOT NULL DEFAULT '',
  `extension` varchar(50) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  `description` mediumtext NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `metadesc` varchar(1024) NOT NULL COMMENT 'The meta description for the page.',
  `metakey` varchar(1024) NOT NULL COMMENT 'The meta keywords for the page.',
  `metadata` varchar(2048) NOT NULL COMMENT 'JSON encoded metadata properties.',
  `created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `language` char(7) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cat_idx` (`extension`,`published`,`access`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_path` (`path`),
  KEY `idx_left_right` (`lft`,`rgt`),
  KEY `idx_alias` (`alias`),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Дамп данных таблицы `sdc98_categories`
--

INSERT INTO `sdc98_categories` (`id`, `asset_id`, `parent_id`, `lft`, `rgt`, `level`, `path`, `extension`, `title`, `alias`, `note`, `description`, `published`, `checked_out`, `checked_out_time`, `access`, `params`, `metadesc`, `metakey`, `metadata`, `created_user_id`, `created_time`, `modified_user_id`, `modified_time`, `hits`, `language`) VALUES
(1, 0, 0, 0, 13, 0, '', 'system', 'ROOT', 'root', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{}', '', '', '', 0, '2009-10-18 16:07:09', 0, '0000-00-00 00:00:00', 0, '*'),
(2, 27, 1, 1, 2, 1, 'uncategorised', 'com_content', 'Без категории', 'uncategorised', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 42, '2010-06-28 13:26:37', 0, '0000-00-00 00:00:00', 0, '*'),
(3, 28, 1, 3, 4, 1, 'uncategorised', 'com_banners', 'Без категории', 'uncategorised', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":"","foobar":""}', '', '', '{"page_title":"","author":"","robots":""}', 42, '2010-06-28 13:27:35', 0, '0000-00-00 00:00:00', 0, '*'),
(4, 29, 1, 5, 6, 1, 'uncategorised', 'com_contact', 'Без категории', 'uncategorised', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 42, '2010-06-28 13:27:57', 0, '0000-00-00 00:00:00', 0, '*'),
(5, 30, 1, 7, 8, 1, 'uncategorised', 'com_newsfeeds', 'Без категории', 'uncategorised', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 42, '2010-06-28 13:28:15', 0, '0000-00-00 00:00:00', 0, '*'),
(6, 31, 1, 9, 10, 1, 'uncategorised', 'com_weblinks', 'Без категории', 'uncategorised', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 42, '2010-06-28 13:28:33', 0, '0000-00-00 00:00:00', 0, '*'),
(7, 32, 1, 11, 12, 1, 'uncategorised', 'com_users', 'Без категории', 'uncategorised', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 42, '2010-06-28 13:28:33', 0, '0000-00-00 00:00:00', 0, '*');

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_contact_details`
--

CREATE TABLE IF NOT EXISTS `sdc98_contact_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `con_position` varchar(255) DEFAULT NULL,
  `address` text,
  `suburb` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `postcode` varchar(100) DEFAULT NULL,
  `telephone` varchar(255) DEFAULT NULL,
  `fax` varchar(255) DEFAULT NULL,
  `misc` mediumtext,
  `image` varchar(255) DEFAULT NULL,
  `imagepos` varchar(20) DEFAULT NULL,
  `email_to` varchar(255) DEFAULT NULL,
  `default_con` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `catid` int(11) NOT NULL DEFAULT '0',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `mobile` varchar(255) NOT NULL DEFAULT '',
  `webpage` varchar(255) NOT NULL DEFAULT '',
  `sortname1` varchar(255) NOT NULL,
  `sortname2` varchar(255) NOT NULL,
  `sortname3` varchar(255) NOT NULL,
  `language` char(7) NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `metadata` text NOT NULL,
  `featured` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Set if article is featured.',
  `xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`published`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_featured_catid` (`featured`,`catid`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_content`
--

CREATE TABLE IF NOT EXISTS `sdc98_content` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `title_alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '' COMMENT 'Deprecated in Joomla! 3.0',
  `introtext` mediumtext NOT NULL,
  `fulltext` mediumtext NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `sectionid` int(10) unsigned NOT NULL DEFAULT '0',
  `mask` int(10) unsigned NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `images` text NOT NULL,
  `urls` text NOT NULL,
  `attribs` varchar(5120) NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `parentid` int(10) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `metadata` text NOT NULL,
  `featured` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Set if article is featured.',
  `language` char(7) NOT NULL COMMENT 'The language code for the article.',
  `xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`state`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_featured_catid` (`featured`,`catid`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `sdc98_content`
--

INSERT INTO `sdc98_content` (`id`, `asset_id`, `title`, `alias`, `title_alias`, `introtext`, `fulltext`, `state`, `sectionid`, `mask`, `catid`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `images`, `urls`, `attribs`, `version`, `parentid`, `ordering`, `metakey`, `metadesc`, `access`, `hits`, `metadata`, `featured`, `language`, `xreference`) VALUES
(1, 36, 'О нас', 'o-nas', '', '<p>Vivamus et venenatis mauris, posuere placerat ipsum. Proin lacinia orci est, vitae elementum tellus viverra ut Vivamus et venenatis mauris, posuere placerat ipsum. Proin lacinia orci est, vitae elementum tellus viverra utVivamus et venenatis mauris, posuere placerat ipsum. Proin lacinia orci est, vitae elementum tellus viverra utVivamus et venenatis mauris, posuere placerat ipsum. Proin lacinia orci est, vitae elementum tellus viverra utVivamus et venenatis mauris, posuere placerat ipsum. Proin lacinia orci est, vitae elementum tellus viverra utVivamus et venenatis mauris, posuere placerat ipsum. Proin lacinia orci est, vitae elementum tellus viverra utVivamus et venenatis mauris, posuere placerat ipsum. Proin lacinia orci est, vitae elementum tellus viverra ut</p>', '', 1, 0, 0, 2, '2014-07-18 14:13:26', 643, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2014-07-18 14:13:26', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":false,"urlatext":"","targeta":"","urlb":false,"urlbtext":"","targetb":"","urlc":false,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 1, 0, 1, '', '', 1, 0, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(2, 37, 'Контакты', 'kontakty', '', '<p>Vivamus et venenatis mauris, posuere placerat ipsum. Proin lacinia orci est, vitae elementum tellus viverra utVivamus et venenatis mauris, posuere placerat ipsum. Proin lacinia orci est, vitae elementum tellus viverra ut</p>', '', 1, 0, 0, 2, '2014-07-18 14:13:38', 643, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2014-07-18 14:13:38', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":false,"urlatext":"","targeta":"","urlb":false,"urlbtext":"","targetb":"","urlc":false,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 1, 0, 0, '', '', 1, 0, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', '');

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_content_frontpage`
--

CREATE TABLE IF NOT EXISTS `sdc98_content_frontpage` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_content_rating`
--

CREATE TABLE IF NOT EXISTS `sdc98_content_rating` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `rating_sum` int(10) unsigned NOT NULL DEFAULT '0',
  `rating_count` int(10) unsigned NOT NULL DEFAULT '0',
  `lastip` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_core_log_searches`
--

CREATE TABLE IF NOT EXISTS `sdc98_core_log_searches` (
  `search_term` varchar(128) NOT NULL DEFAULT '',
  `hits` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_extensions`
--

CREATE TABLE IF NOT EXISTS `sdc98_extensions` (
  `extension_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `type` varchar(20) NOT NULL,
  `element` varchar(100) NOT NULL,
  `folder` varchar(100) NOT NULL,
  `client_id` tinyint(3) NOT NULL,
  `enabled` tinyint(3) NOT NULL DEFAULT '1',
  `access` int(10) unsigned NOT NULL DEFAULT '1',
  `protected` tinyint(3) NOT NULL DEFAULT '0',
  `manifest_cache` text NOT NULL,
  `params` text NOT NULL,
  `custom_data` text NOT NULL,
  `system_data` text NOT NULL,
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) DEFAULT '0',
  `state` int(11) DEFAULT '0',
  PRIMARY KEY (`extension_id`),
  KEY `element_clientid` (`element`,`client_id`),
  KEY `element_folder_clientid` (`element`,`folder`,`client_id`),
  KEY `extension` (`type`,`element`,`folder`,`client_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10015 ;

--
-- Дамп данных таблицы `sdc98_extensions`
--

INSERT INTO `sdc98_extensions` (`extension_id`, `name`, `type`, `element`, `folder`, `client_id`, `enabled`, `access`, `protected`, `manifest_cache`, `params`, `custom_data`, `system_data`, `checked_out`, `checked_out_time`, `ordering`, `state`) VALUES
(1, 'com_mailto', 'component', 'com_mailto', '', 0, 1, 1, 1, '{"legacy":false,"name":"com_mailto","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_MAILTO_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(2, 'com_wrapper', 'component', 'com_wrapper', '', 0, 1, 1, 1, '{"legacy":false,"name":"com_wrapper","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_WRAPPER_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(3, 'com_admin', 'component', 'com_admin', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_admin","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_ADMIN_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(4, 'com_banners', 'component', 'com_banners', '', 1, 1, 1, 0, '{"legacy":false,"name":"com_banners","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_BANNERS_XML_DESCRIPTION","group":""}', '{"purchase_type":"3","track_impressions":"0","track_clicks":"0","metakey_prefix":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(5, 'com_cache', 'component', 'com_cache', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_cache","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_CACHE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(6, 'com_categories', 'component', 'com_categories', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_categories","type":"component","creationDate":"December 2007","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_CATEGORIES_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(7, 'com_checkin', 'component', 'com_checkin', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_checkin","type":"component","creationDate":"Unknown","author":"Joomla! Project","copyright":"(C) 2005 - 2008 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_CHECKIN_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(8, 'com_contact', 'component', 'com_contact', '', 1, 1, 1, 0, '{"legacy":false,"name":"com_contact","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_CONTACT_XML_DESCRIPTION","group":""}', '{"show_contact_category":"hide","show_contact_list":"0","presentation_style":"sliders","show_name":"1","show_position":"1","show_email":"0","show_street_address":"1","show_suburb":"1","show_state":"1","show_postcode":"1","show_country":"1","show_telephone":"1","show_mobile":"1","show_fax":"1","show_webpage":"1","show_misc":"1","show_image":"1","image":"","allow_vcard":"0","show_articles":"0","show_profile":"0","show_links":"0","linka_name":"","linkb_name":"","linkc_name":"","linkd_name":"","linke_name":"","contact_icons":"0","icon_address":"","icon_email":"","icon_telephone":"","icon_mobile":"","icon_fax":"","icon_misc":"","show_headings":"1","show_position_headings":"1","show_email_headings":"0","show_telephone_headings":"1","show_mobile_headings":"0","show_fax_headings":"0","allow_vcard_headings":"0","show_suburb_headings":"1","show_state_headings":"1","show_country_headings":"1","show_email_form":"1","show_email_copy":"1","banned_email":"","banned_subject":"","banned_text":"","validate_session":"1","custom_reply":"0","redirect":"","show_category_crumb":"0","metakey":"","metadesc":"","robots":"","author":"","rights":"","xreference":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(9, 'com_cpanel', 'component', 'com_cpanel', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_cpanel","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_CPANEL_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10, 'com_installer', 'component', 'com_installer', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_installer","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_INSTALLER_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(11, 'com_languages', 'component', 'com_languages', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_languages","type":"component","creationDate":"2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_LANGUAGES_XML_DESCRIPTION","group":""}', '{"administrator":"ru-RU","site":"ru-RU"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(12, 'com_login', 'component', 'com_login', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_login","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_LOGIN_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(13, 'com_media', 'component', 'com_media', '', 1, 1, 0, 1, '{"legacy":false,"name":"com_media","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_MEDIA_XML_DESCRIPTION","group":""}', '{"upload_extensions":"bmp,csv,doc,gif,ico,jpg,jpeg,odg,odp,ods,odt,pdf,png,ppt,swf,txt,xcf,xls,BMP,CSV,DOC,GIF,ICO,JPG,JPEG,ODG,ODP,ODS,ODT,PDF,PNG,PPT,SWF,TXT,XCF,XLS","upload_maxsize":"10","file_path":"images","image_path":"images","restrict_uploads":"1","allowed_media_usergroup":"3","check_mime":"1","image_extensions":"bmp,gif,jpg,png","ignore_extensions":"","upload_mime":"image\\/jpeg,image\\/gif,image\\/png,image\\/bmp,application\\/x-shockwave-flash,application\\/msword,application\\/excel,application\\/pdf,application\\/powerpoint,text\\/plain,application\\/x-zip","upload_mime_illegal":"text\\/html"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(14, 'com_menus', 'component', 'com_menus', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_menus","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_MENUS_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(15, 'com_messages', 'component', 'com_messages', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_messages","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_MESSAGES_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(16, 'com_modules', 'component', 'com_modules', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_modules","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_MODULES_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(17, 'com_newsfeeds', 'component', 'com_newsfeeds', '', 1, 1, 1, 0, '{"legacy":false,"name":"com_newsfeeds","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_NEWSFEEDS_XML_DESCRIPTION","group":""}', '{"show_feed_image":"1","show_feed_description":"1","show_item_description":"1","feed_word_count":"0","show_headings":"1","show_name":"1","show_articles":"0","show_link":"1","show_description":"1","show_description_image":"1","display_num":"","show_pagination_limit":"1","show_pagination":"1","show_pagination_results":"1","show_cat_items":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(18, 'com_plugins', 'component', 'com_plugins', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_plugins","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_PLUGINS_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(19, 'com_search', 'component', 'com_search', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_search","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_SEARCH_XML_DESCRIPTION","group":""}', '{"enabled":"0","show_date":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(20, 'com_templates', 'component', 'com_templates', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_templates","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_TEMPLATES_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(21, 'com_weblinks', 'component', 'com_weblinks', '', 1, 1, 1, 0, '{"legacy":false,"name":"com_weblinks","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_WEBLINKS_XML_DESCRIPTION","group":""}', '{"show_comp_description":"1","comp_description":"","show_link_hits":"1","show_link_description":"1","show_other_cats":"0","show_headings":"0","show_numbers":"0","show_report":"1","count_clicks":"1","target":"0","link_icons":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(22, 'com_content', 'component', 'com_content', '', 1, 1, 0, 1, '{"legacy":false,"name":"com_content","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_CONTENT_XML_DESCRIPTION","group":""}', '{"article_layout":"_:default","show_title":"1","link_titles":"1","show_intro":"1","show_category":"1","link_category":"1","show_parent_category":"0","link_parent_category":"0","show_author":"1","link_author":"0","show_create_date":"0","show_modify_date":"0","show_publish_date":"1","show_item_navigation":"1","show_vote":"0","show_readmore":"1","show_readmore_title":"1","readmore_limit":"100","show_icons":"1","show_print_icon":"1","show_email_icon":"1","show_hits":"1","show_noauth":"0","show_publishing_options":"1","show_article_options":"1","show_urls_images_frontend":"0","show_urls_images_backend":"1","targeta":0,"targetb":0,"targetc":0,"float_intro":"left","float_fulltext":"left","category_layout":"_:blog","show_category_title":"0","show_description":"0","show_description_image":"0","maxLevel":"1","show_empty_categories":"0","show_no_articles":"1","show_subcat_desc":"1","show_cat_num_articles":"0","show_base_description":"1","maxLevelcat":"-1","show_empty_categories_cat":"0","show_subcat_desc_cat":"1","show_cat_num_articles_cat":"1","num_leading_articles":"1","num_intro_articles":"4","num_columns":"2","num_links":"4","multi_column_order":"0","show_subcategory_content":"0","show_pagination_limit":"1","filter_field":"hide","show_headings":"1","list_show_date":"0","date_format":"","list_show_hits":"1","list_show_author":"1","orderby_pri":"order","orderby_sec":"rdate","order_date":"published","show_pagination":"2","show_pagination_results":"1","show_feed_link":"1","feed_summary":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(23, 'com_config', 'component', 'com_config', '', 1, 1, 0, 1, '{"legacy":false,"name":"com_config","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_CONFIG_XML_DESCRIPTION","group":""}', '{"filters":{"1":{"filter_type":"NH","filter_tags":"","filter_attributes":""},"6":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"7":{"filter_type":"NONE","filter_tags":"","filter_attributes":""},"2":{"filter_type":"NH","filter_tags":"","filter_attributes":""},"3":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"4":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"5":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"8":{"filter_type":"NONE","filter_tags":"","filter_attributes":""}}}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(24, 'com_redirect', 'component', 'com_redirect', '', 1, 1, 0, 1, '{"legacy":false,"name":"com_redirect","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_REDIRECT_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(25, 'com_users', 'component', 'com_users', '', 1, 1, 0, 1, '{"legacy":false,"name":"com_users","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_USERS_XML_DESCRIPTION","group":""}', '{"allowUserRegistration":"1","new_usertype":"2","guest_usergroup":"1","sendpassword":"1","useractivation":"2","mail_to_admin":"1","captcha":"","frontend_userparams":"1","site_language":"0","change_login_name":"0","reset_count":"10","reset_time":"1","mailSubjectPrefix":"","mailBodySuffix":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(27, 'com_finder', 'component', 'com_finder', '', 1, 1, 0, 0, '{"legacy":false,"name":"com_finder","type":"component","creationDate":"August 2011","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_FINDER_XML_DESCRIPTION","group":""}', '{"show_description":"1","description_length":255,"allow_empty_query":"0","show_url":"1","show_advanced":"1","expand_advanced":"0","show_date_filters":"0","highlight_terms":"1","opensearch_name":"","opensearch_description":"","batch_size":"50","memory_table_limit":30000,"title_multiplier":"1.7","text_multiplier":"0.7","meta_multiplier":"1.2","path_multiplier":"2.0","misc_multiplier":"0.3","stemmer":"snowball"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(28, 'com_joomlaupdate', 'component', 'com_joomlaupdate', '', 1, 1, 0, 1, '{"legacy":false,"name":"com_joomlaupdate","type":"component","creationDate":"February 2012","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_JOOMLAUPDATE_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(100, 'PHPMailer', 'library', 'phpmailer', '', 0, 1, 1, 1, '{"legacy":false,"name":"PHPMailer","type":"library","creationDate":"2001","author":"PHPMailer","copyright":"(c) 2001-2003, Brent R. Matzelle, (c) 2004-2009, Andy Prevost. All Rights Reserved., (c) 2010-2011, Jim Jagielski. All Rights Reserved.","authorEmail":"jimjag@gmail.com","authorUrl":"https:\\/\\/code.google.com\\/a\\/apache-extras.org\\/p\\/phpmailer\\/","version":"5.2","description":"LIB_PHPMAILER_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(101, 'SimplePie', 'library', 'simplepie', '', 0, 1, 1, 1, '{"legacy":false,"name":"SimplePie","type":"library","creationDate":"2004","author":"SimplePie","copyright":"Copyright (c) 2004-2009, Ryan Parman and Geoffrey Sneddon","authorEmail":"","authorUrl":"http:\\/\\/simplepie.org\\/","version":"1.2","description":"LIB_SIMPLEPIE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(102, 'phputf8', 'library', 'phputf8', '', 0, 1, 1, 1, '{"legacy":false,"name":"phputf8","type":"library","creationDate":"2006","author":"Harry Fuecks","copyright":"Copyright various authors","authorEmail":"hfuecks@gmail.com","authorUrl":"http:\\/\\/sourceforge.net\\/projects\\/phputf8","version":"0.5","description":"LIB_PHPUTF8_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(103, 'Joomla! Platform', 'library', 'joomla', '', 0, 1, 1, 1, '{"legacy":false,"name":"Joomla! Platform","type":"library","creationDate":"2008","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"http:\\/\\/www.joomla.org","version":"11.4","description":"LIB_JOOMLA_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(200, 'mod_articles_archive', 'module', 'mod_articles_archive', '', 0, 1, 1, 1, '{"legacy":false,"name":"mod_articles_archive","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters.\\n\\t\\tAll rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_ARTICLES_ARCHIVE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(201, 'mod_articles_latest', 'module', 'mod_articles_latest', '', 0, 1, 1, 1, '{"legacy":false,"name":"mod_articles_latest","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_LATEST_NEWS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(202, 'mod_articles_popular', 'module', 'mod_articles_popular', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_articles_popular","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_POPULAR_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(203, 'mod_banners', 'module', 'mod_banners', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_banners","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_BANNERS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(204, 'mod_breadcrumbs', 'module', 'mod_breadcrumbs', '', 0, 1, 1, 1, '{"legacy":false,"name":"mod_breadcrumbs","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_BREADCRUMBS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(205, 'mod_custom', 'module', 'mod_custom', '', 0, 1, 1, 1, '{"legacy":false,"name":"mod_custom","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_CUSTOM_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(206, 'mod_feed', 'module', 'mod_feed', '', 0, 1, 1, 1, '{"legacy":false,"name":"mod_feed","type":"module","creationDate":"July 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_FEED_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(207, 'mod_footer', 'module', 'mod_footer', '', 0, 1, 1, 1, '{"legacy":false,"name":"mod_footer","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_FOOTER_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(208, 'mod_login', 'module', 'mod_login', '', 0, 1, 1, 1, '{"legacy":false,"name":"mod_login","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_LOGIN_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(209, 'mod_menu', 'module', 'mod_menu', '', 0, 1, 1, 1, '{"legacy":false,"name":"mod_menu","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_MENU_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(210, 'mod_articles_news', 'module', 'mod_articles_news', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_articles_news","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_ARTICLES_NEWS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(211, 'mod_random_image', 'module', 'mod_random_image', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_random_image","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_RANDOM_IMAGE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(212, 'mod_related_items', 'module', 'mod_related_items', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_related_items","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_RELATED_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(213, 'mod_search', 'module', 'mod_search', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_search","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_SEARCH_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(214, 'mod_stats', 'module', 'mod_stats', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_stats","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_STATS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(215, 'mod_syndicate', 'module', 'mod_syndicate', '', 0, 1, 1, 1, '{"legacy":false,"name":"mod_syndicate","type":"module","creationDate":"May 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_SYNDICATE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(216, 'mod_users_latest', 'module', 'mod_users_latest', '', 0, 1, 1, 1, '{"legacy":false,"name":"mod_users_latest","type":"module","creationDate":"December 2009","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_USERS_LATEST_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(217, 'mod_weblinks', 'module', 'mod_weblinks', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_weblinks","type":"module","creationDate":"July 2009","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_WEBLINKS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(218, 'mod_whosonline', 'module', 'mod_whosonline', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_whosonline","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_WHOSONLINE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(219, 'mod_wrapper', 'module', 'mod_wrapper', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_wrapper","type":"module","creationDate":"October 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_WRAPPER_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(220, 'mod_articles_category', 'module', 'mod_articles_category', '', 0, 1, 1, 1, '{"legacy":false,"name":"mod_articles_category","type":"module","creationDate":"February 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_ARTICLES_CATEGORY_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(221, 'mod_articles_categories', 'module', 'mod_articles_categories', '', 0, 1, 1, 1, '{"legacy":false,"name":"mod_articles_categories","type":"module","creationDate":"February 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_ARTICLES_CATEGORIES_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(222, 'mod_languages', 'module', 'mod_languages', '', 0, 1, 1, 1, '{"legacy":false,"name":"mod_languages","type":"module","creationDate":"February 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_LANGUAGES_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(223, 'mod_finder', 'module', 'mod_finder', '', 0, 1, 0, 0, '{"legacy":false,"name":"mod_finder","type":"module","creationDate":"August 2011","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_FINDER_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(300, 'mod_custom', 'module', 'mod_custom', '', 1, 1, 1, 1, '{"legacy":false,"name":"mod_custom","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_CUSTOM_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(301, 'mod_feed', 'module', 'mod_feed', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_feed","type":"module","creationDate":"July 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_FEED_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(302, 'mod_latest', 'module', 'mod_latest', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_latest","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_LATEST_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(303, 'mod_logged', 'module', 'mod_logged', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_logged","type":"module","creationDate":"January 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_LOGGED_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(304, 'mod_login', 'module', 'mod_login', '', 1, 1, 1, 1, '{"legacy":false,"name":"mod_login","type":"module","creationDate":"March 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_LOGIN_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(305, 'mod_menu', 'module', 'mod_menu', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_menu","type":"module","creationDate":"March 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_MENU_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(307, 'mod_popular', 'module', 'mod_popular', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_popular","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_POPULAR_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(308, 'mod_quickicon', 'module', 'mod_quickicon', '', 1, 1, 1, 1, '{"legacy":false,"name":"mod_quickicon","type":"module","creationDate":"Nov 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_QUICKICON_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(309, 'mod_status', 'module', 'mod_status', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_status","type":"module","creationDate":"Feb 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_STATUS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(310, 'mod_submenu', 'module', 'mod_submenu', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_submenu","type":"module","creationDate":"Feb 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_SUBMENU_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(311, 'mod_title', 'module', 'mod_title', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_title","type":"module","creationDate":"Nov 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_TITLE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(312, 'mod_toolbar', 'module', 'mod_toolbar', '', 1, 1, 1, 1, '{"legacy":false,"name":"mod_toolbar","type":"module","creationDate":"Nov 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_TOOLBAR_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(313, 'mod_multilangstatus', 'module', 'mod_multilangstatus', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_multilangstatus","type":"module","creationDate":"September 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_MULTILANGSTATUS_XML_DESCRIPTION","group":""}', '{"cache":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(314, 'mod_version', 'module', 'mod_version', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_version","type":"module","creationDate":"January 2012","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_VERSION_XML_DESCRIPTION","group":""}', '{"format":"short","product":"1","cache":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(400, 'plg_authentication_gmail', 'plugin', 'gmail', 'authentication', 0, 0, 1, 0, '{"legacy":false,"name":"plg_authentication_gmail","type":"plugin","creationDate":"February 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_GMAIL_XML_DESCRIPTION","group":""}', '{"applysuffix":"0","suffix":"","verifypeer":"1","user_blacklist":""}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(401, 'plg_authentication_joomla', 'plugin', 'joomla', 'authentication', 0, 1, 1, 1, '{"legacy":false,"name":"plg_authentication_joomla","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_AUTH_JOOMLA_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(402, 'plg_authentication_ldap', 'plugin', 'ldap', 'authentication', 0, 0, 1, 0, '{"legacy":false,"name":"plg_authentication_ldap","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_LDAP_XML_DESCRIPTION","group":""}', '{"host":"","port":"389","use_ldapV3":"0","negotiate_tls":"0","no_referrals":"0","auth_method":"bind","base_dn":"","search_string":"","users_dn":"","username":"admin","password":"bobby7","ldap_fullname":"fullName","ldap_email":"mail","ldap_uid":"uid"}', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(404, 'plg_content_emailcloak', 'plugin', 'emailcloak', 'content', 0, 1, 1, 0, '{"legacy":false,"name":"plg_content_emailcloak","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_CONTENT_EMAILCLOAK_XML_DESCRIPTION","group":""}', '{"mode":"1"}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(405, 'plg_content_geshi', 'plugin', 'geshi', 'content', 0, 0, 1, 0, '{"legacy":false,"name":"plg_content_geshi","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"","authorUrl":"qbnz.com\\/highlighter","version":"2.5.0","description":"PLG_CONTENT_GESHI_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(406, 'plg_content_loadmodule', 'plugin', 'loadmodule', 'content', 0, 1, 1, 0, '{"legacy":false,"name":"plg_content_loadmodule","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_LOADMODULE_XML_DESCRIPTION","group":""}', '{"style":"xhtml"}', '', '', 0, '2011-09-18 15:22:50', 0, 0),
(407, 'plg_content_pagebreak', 'plugin', 'pagebreak', 'content', 0, 1, 1, 1, '{"legacy":false,"name":"plg_content_pagebreak","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_CONTENT_PAGEBREAK_XML_DESCRIPTION","group":""}', '{"title":"1","multipage_toc":"1","showall":"1"}', '', '', 0, '0000-00-00 00:00:00', 4, 0),
(408, 'plg_content_pagenavigation', 'plugin', 'pagenavigation', 'content', 0, 1, 1, 1, '{"legacy":false,"name":"plg_content_pagenavigation","type":"plugin","creationDate":"January 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_PAGENAVIGATION_XML_DESCRIPTION","group":""}', '{"position":"1"}', '', '', 0, '0000-00-00 00:00:00', 5, 0),
(409, 'plg_content_vote', 'plugin', 'vote', 'content', 0, 1, 1, 1, '{"legacy":false,"name":"plg_content_vote","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_VOTE_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 6, 0),
(410, 'plg_editors_codemirror', 'plugin', 'codemirror', 'editors', 0, 1, 1, 1, '{"legacy":false,"name":"plg_editors_codemirror","type":"plugin","creationDate":"28 March 2011","author":"Marijn Haverbeke","copyright":"","authorEmail":"N\\/A","authorUrl":"","version":"1.0","description":"PLG_CODEMIRROR_XML_DESCRIPTION","group":""}', '{"linenumbers":"0","tabmode":"indent"}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(411, 'plg_editors_none', 'plugin', 'none', 'editors', 0, 1, 1, 1, '{"legacy":false,"name":"plg_editors_none","type":"plugin","creationDate":"August 2004","author":"Unknown","copyright":"","authorEmail":"N\\/A","authorUrl":"","version":"2.5.0","description":"PLG_NONE_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(412, 'plg_editors_tinymce', 'plugin', 'tinymce', 'editors', 0, 1, 1, 1, '{"legacy":false,"name":"plg_editors_tinymce","type":"plugin","creationDate":"2005-2013","author":"Moxiecode Systems AB","copyright":"Moxiecode Systems AB","authorEmail":"N\\/A","authorUrl":"tinymce.moxiecode.com\\/","version":"3.5.4.1","description":"PLG_TINY_XML_DESCRIPTION","group":""}', '{"mode":"2","skin":"0","entity_encoding":"raw","lang_mode":"1","lang_code":"en","text_direction":"ltr","content_css":"1","content_css_custom":"","relative_urls":"1","newlines":"0","invalid_elements":"script,applet,iframe","extended_elements":"","toolbar":"top","toolbar_align":"left","html_height":"550","html_width":"750","resizing":"true","resize_horizontal":"false","element_path":"1","fonts":"1","paste":"1","searchreplace":"1","insertdate":"1","format_date":"%Y-%m-%d","inserttime":"1","format_time":"%H:%M:%S","colors":"1","table":"1","smilies":"1","media":"1","hr":"1","directionality":"1","fullscreen":"1","style":"1","layer":"1","xhtmlxtras":"1","visualchars":"1","nonbreaking":"1","template":"1","blockquote":"1","wordcount":"1","advimage":"1","advlink":"1","advlist":"1","autosave":"1","contextmenu":"1","inlinepopups":"1","custom_plugin":"","custom_button":""}', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(413, 'plg_editors-xtd_article', 'plugin', 'article', 'editors-xtd', 0, 1, 1, 1, '{"legacy":false,"name":"plg_editors-xtd_article","type":"plugin","creationDate":"October 2009","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_ARTICLE_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(414, 'plg_editors-xtd_image', 'plugin', 'image', 'editors-xtd', 0, 1, 1, 0, '{"legacy":false,"name":"plg_editors-xtd_image","type":"plugin","creationDate":"August 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_IMAGE_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(415, 'plg_editors-xtd_pagebreak', 'plugin', 'pagebreak', 'editors-xtd', 0, 1, 1, 0, '{"legacy":false,"name":"plg_editors-xtd_pagebreak","type":"plugin","creationDate":"August 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_EDITORSXTD_PAGEBREAK_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(416, 'plg_editors-xtd_readmore', 'plugin', 'readmore', 'editors-xtd', 0, 1, 1, 0, '{"legacy":false,"name":"plg_editors-xtd_readmore","type":"plugin","creationDate":"March 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_READMORE_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 4, 0),
(417, 'plg_search_categories', 'plugin', 'categories', 'search', 0, 1, 1, 0, '{"legacy":false,"name":"plg_search_categories","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_SEARCH_CATEGORIES_XML_DESCRIPTION","group":""}', '{"search_limit":"50","search_content":"1","search_archived":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(418, 'plg_search_contacts', 'plugin', 'contacts', 'search', 0, 1, 1, 0, '{"legacy":false,"name":"plg_search_contacts","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_SEARCH_CONTACTS_XML_DESCRIPTION","group":""}', '{"search_limit":"50","search_content":"1","search_archived":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(419, 'plg_search_content', 'plugin', 'content', 'search', 0, 1, 1, 0, '{"legacy":false,"name":"plg_search_content","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_SEARCH_CONTENT_XML_DESCRIPTION","group":""}', '{"search_limit":"50","search_content":"1","search_archived":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(420, 'plg_search_newsfeeds', 'plugin', 'newsfeeds', 'search', 0, 1, 1, 0, '{"legacy":false,"name":"plg_search_newsfeeds","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_SEARCH_NEWSFEEDS_XML_DESCRIPTION","group":""}', '{"search_limit":"50","search_content":"1","search_archived":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(421, 'plg_search_weblinks', 'plugin', 'weblinks', 'search', 0, 1, 1, 0, '{"legacy":false,"name":"plg_search_weblinks","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_SEARCH_WEBLINKS_XML_DESCRIPTION","group":""}', '{"search_limit":"50","search_content":"1","search_archived":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(422, 'plg_system_languagefilter', 'plugin', 'languagefilter', 'system', 0, 0, 1, 1, '{"legacy":false,"name":"plg_system_languagefilter","type":"plugin","creationDate":"July 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_SYSTEM_LANGUAGEFILTER_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(423, 'plg_system_p3p', 'plugin', 'p3p', 'system', 0, 1, 1, 1, '{"legacy":false,"name":"plg_system_p3p","type":"plugin","creationDate":"September 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_P3P_XML_DESCRIPTION","group":""}', '{"headers":"NOI ADM DEV PSAi COM NAV OUR OTRo STP IND DEM"}', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(424, 'plg_system_cache', 'plugin', 'cache', 'system', 0, 0, 1, 1, '{"legacy":false,"name":"plg_system_cache","type":"plugin","creationDate":"February 2007","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_CACHE_XML_DESCRIPTION","group":""}', '{"browsercache":"0","cachetime":"15"}', '', '', 0, '0000-00-00 00:00:00', 9, 0),
(425, 'plg_system_debug', 'plugin', 'debug', 'system', 0, 1, 1, 0, '{"legacy":false,"name":"plg_system_debug","type":"plugin","creationDate":"December 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_DEBUG_XML_DESCRIPTION","group":""}', '{"profile":"1","queries":"1","memory":"1","language_files":"1","language_strings":"1","strip-first":"1","strip-prefix":"","strip-suffix":""}', '', '', 0, '0000-00-00 00:00:00', 4, 0),
(426, 'plg_system_log', 'plugin', 'log', 'system', 0, 1, 1, 1, '{"legacy":false,"name":"plg_system_log","type":"plugin","creationDate":"April 2007","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_LOG_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 5, 0),
(427, 'plg_system_redirect', 'plugin', 'redirect', 'system', 0, 1, 1, 1, '{"legacy":false,"name":"plg_system_redirect","type":"plugin","creationDate":"April 2009","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_REDIRECT_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 6, 0);
INSERT INTO `sdc98_extensions` (`extension_id`, `name`, `type`, `element`, `folder`, `client_id`, `enabled`, `access`, `protected`, `manifest_cache`, `params`, `custom_data`, `system_data`, `checked_out`, `checked_out_time`, `ordering`, `state`) VALUES
(428, 'plg_system_remember', 'plugin', 'remember', 'system', 0, 1, 1, 1, '{"legacy":false,"name":"plg_system_remember","type":"plugin","creationDate":"April 2007","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_REMEMBER_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 7, 0),
(429, 'plg_system_sef', 'plugin', 'sef', 'system', 0, 1, 1, 0, '{"legacy":false,"name":"plg_system_sef","type":"plugin","creationDate":"December 2007","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_SEF_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 8, 0),
(430, 'plg_system_logout', 'plugin', 'logout', 'system', 0, 1, 1, 1, '{"legacy":false,"name":"plg_system_logout","type":"plugin","creationDate":"April 2009","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_SYSTEM_LOGOUT_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(431, 'plg_user_contactcreator', 'plugin', 'contactcreator', 'user', 0, 0, 1, 1, '{"legacy":false,"name":"plg_user_contactcreator","type":"plugin","creationDate":"August 2009","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_CONTACTCREATOR_XML_DESCRIPTION","group":""}', '{"autowebpage":"","category":"34","autopublish":"0"}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(432, 'plg_user_joomla', 'plugin', 'joomla', 'user', 0, 1, 1, 0, '{"legacy":false,"name":"plg_user_joomla","type":"plugin","creationDate":"December 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2009 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_USER_JOOMLA_XML_DESCRIPTION","group":""}', '{"autoregister":"1"}', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(433, 'plg_user_profile', 'plugin', 'profile', 'user', 0, 0, 1, 1, '{"legacy":false,"name":"plg_user_profile","type":"plugin","creationDate":"January 2008","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_USER_PROFILE_XML_DESCRIPTION","group":""}', '{"register-require_address1":"1","register-require_address2":"1","register-require_city":"1","register-require_region":"1","register-require_country":"1","register-require_postal_code":"1","register-require_phone":"1","register-require_website":"1","register-require_favoritebook":"1","register-require_aboutme":"1","register-require_tos":"1","register-require_dob":"1","profile-require_address1":"1","profile-require_address2":"1","profile-require_city":"1","profile-require_region":"1","profile-require_country":"1","profile-require_postal_code":"1","profile-require_phone":"1","profile-require_website":"1","profile-require_favoritebook":"1","profile-require_aboutme":"1","profile-require_tos":"1","profile-require_dob":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(434, 'plg_extension_joomla', 'plugin', 'joomla', 'extension', 0, 1, 1, 1, '{"legacy":false,"name":"plg_extension_joomla","type":"plugin","creationDate":"May 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_EXTENSION_JOOMLA_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(435, 'plg_content_joomla', 'plugin', 'joomla', 'content', 0, 1, 1, 0, '{"legacy":false,"name":"plg_content_joomla","type":"plugin","creationDate":"November 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_CONTENT_JOOMLA_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(436, 'plg_system_languagecode', 'plugin', 'languagecode', 'system', 0, 0, 1, 0, '{"legacy":false,"name":"plg_system_languagecode","type":"plugin","creationDate":"November 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_SYSTEM_LANGUAGECODE_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 10, 0),
(437, 'plg_quickicon_joomlaupdate', 'plugin', 'joomlaupdate', 'quickicon', 0, 1, 1, 1, '{"legacy":false,"name":"plg_quickicon_joomlaupdate","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_QUICKICON_JOOMLAUPDATE_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(438, 'plg_quickicon_extensionupdate', 'plugin', 'extensionupdate', 'quickicon', 0, 1, 1, 1, '{"legacy":false,"name":"plg_quickicon_extensionupdate","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_QUICKICON_EXTENSIONUPDATE_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(439, 'plg_captcha_recaptcha', 'plugin', 'recaptcha', 'captcha', 0, 0, 1, 0, '{"legacy":false,"name":"plg_captcha_recaptcha","type":"plugin","creationDate":"December 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_CAPTCHA_RECAPTCHA_XML_DESCRIPTION","group":""}', '{"public_key":"","private_key":"","theme":"clean"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(440, 'plg_system_highlight', 'plugin', 'highlight', 'system', 0, 1, 1, 0, '{"legacy":false,"name":"plg_system_highlight","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_SYSTEM_HIGHLIGHT_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 7, 0),
(441, 'plg_content_finder', 'plugin', 'finder', 'content', 0, 0, 1, 0, '{"legacy":false,"name":"plg_content_finder","type":"plugin","creationDate":"December 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_CONTENT_FINDER_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(442, 'plg_finder_categories', 'plugin', 'categories', 'finder', 0, 1, 1, 0, '{"legacy":false,"name":"plg_finder_categories","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_FINDER_CATEGORIES_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(443, 'plg_finder_contacts', 'plugin', 'contacts', 'finder', 0, 1, 1, 0, '{"legacy":false,"name":"plg_finder_contacts","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_FINDER_CONTACTS_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(444, 'plg_finder_content', 'plugin', 'content', 'finder', 0, 1, 1, 0, '{"legacy":false,"name":"plg_finder_content","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_FINDER_CONTENT_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(445, 'plg_finder_newsfeeds', 'plugin', 'newsfeeds', 'finder', 0, 1, 1, 0, '{"legacy":false,"name":"plg_finder_newsfeeds","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_FINDER_NEWSFEEDS_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 4, 0),
(446, 'plg_finder_weblinks', 'plugin', 'weblinks', 'finder', 0, 1, 1, 0, '{"legacy":false,"name":"plg_finder_weblinks","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_FINDER_WEBLINKS_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 5, 0),
(500, 'atomic', 'template', 'atomic', '', 0, 1, 1, 0, '{"legacy":false,"name":"atomic","type":"template","creationDate":"10\\/10\\/09","author":"Ron Severdia","copyright":"Copyright (C) 2005 - 2014 Open Source Matters, Inc. All rights reserved.","authorEmail":"contact@kontentdesign.com","authorUrl":"http:\\/\\/www.kontentdesign.com","version":"2.5.0","description":"TPL_ATOMIC_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(502, 'bluestork', 'template', 'bluestork', '', 1, 1, 1, 0, '{"legacy":false,"name":"bluestork","type":"template","creationDate":"07\\/02\\/09","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters, Inc. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"TPL_BLUESTORK_XML_DESCRIPTION","group":""}', '{"useRoundedCorners":"1","showSiteName":"0","textBig":"0","highContrast":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(503, 'beez_20', 'template', 'beez_20', '', 0, 1, 1, 0, '{"legacy":false,"name":"beez_20","type":"template","creationDate":"25 November 2009","author":"Angie Radtke","copyright":"Copyright (C) 2005 - 2014 Open Source Matters, Inc. All rights reserved.","authorEmail":"a.radtke@derauftritt.de","authorUrl":"http:\\/\\/www.der-auftritt.de","version":"2.5.0","description":"TPL_BEEZ2_XML_DESCRIPTION","group":""}', '{"wrapperSmall":"53","wrapperLarge":"72","sitetitle":"","sitedescription":"","navposition":"center","templatecolor":"nature"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(504, 'hathor', 'template', 'hathor', '', 1, 1, 1, 0, '{"legacy":false,"name":"hathor","type":"template","creationDate":"May 2010","author":"Andrea Tarr","copyright":"Copyright (C) 2005 - 2014 Open Source Matters, Inc. All rights reserved.","authorEmail":"hathor@tarrconsulting.com","authorUrl":"http:\\/\\/www.tarrconsulting.com","version":"2.5.0","description":"TPL_HATHOR_XML_DESCRIPTION","group":""}', '{"showSiteName":"0","colourChoice":"0","boldText":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(505, 'beez5', 'template', 'beez5', '', 0, 1, 1, 0, '{"legacy":false,"name":"beez5","type":"template","creationDate":"21 May 2010","author":"Angie Radtke","copyright":"Copyright (C) 2005 - 2014 Open Source Matters, Inc. All rights reserved.","authorEmail":"a.radtke@derauftritt.de","authorUrl":"http:\\/\\/www.der-auftritt.de","version":"2.5.0","description":"TPL_BEEZ5_XML_DESCRIPTION","group":""}', '{"wrapperSmall":"53","wrapperLarge":"72","sitetitle":"","sitedescription":"","navposition":"center","html5":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(600, 'English (United Kingdom)', 'language', 'en-GB', '', 0, 1, 1, 1, '{"legacy":false,"name":"English (United Kingdom)","type":"language","creationDate":"2008-03-15","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.19","description":"en-GB site language","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(601, 'English (United Kingdom)', 'language', 'en-GB', '', 1, 1, 1, 1, '{"legacy":false,"name":"English (United Kingdom)","type":"language","creationDate":"2008-03-15","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.19","description":"en-GB administrator language","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(602, 'Russian', 'language', 'ru-RU', '', 0, 1, 0, 0, '{"legacy":false,"name":"Russian","type":"language","creationDate":"2013-12-20","author":"Russian Translation Team","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved","authorEmail":"smart@joomlaportal.ru","authorUrl":"www.joomlaportal.ru","version":"2.5.17.1","description":"Russian language pack (site) for Joomla! 2.5","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(603, 'Russian', 'language', 'ru-RU', '', 1, 1, 0, 0, '{"legacy":false,"name":"Russian","type":"language","creationDate":"2013-12-20","author":"Russian Translation Team","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved","authorEmail":"smart@joomlaportal.ru","authorUrl":"www.joomlaportal.ru","version":"2.5.17.1","description":"Russian language pack (administrator) for Joomla! 2.5","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(700, 'files_joomla', 'file', 'joomla', '', 0, 1, 1, 1, '{"legacy":false,"name":"files_joomla","type":"file","creationDate":"June 2014","author":"Joomla! Project","copyright":"(C) 2005 - 2014 Open Source Matters. All rights reserved","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.22","description":"FILES_JOOMLA_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(800, 'PKG_JOOMLA', 'package', 'pkg_joomla', '', 0, 1, 1, 1, '{"legacy":false,"name":"PKG_JOOMLA","type":"package","creationDate":"2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2014 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"http:\\/\\/www.joomla.org","version":"2.5.0","description":"PKG_JOOMLA_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10000, 'com_zoo', 'component', 'com_zoo', '', 1, 1, 0, 0, '{"legacy":false,"name":"com_zoo","type":"component","creationDate":"March 2014","author":"YOOtheme","copyright":"Copyright (C) YOOtheme GmbH","authorEmail":"info@yootheme.com","authorUrl":"http:\\/\\/www.yootheme.com","version":"3.1.6","description":"ZOO component for Joomla 2.5+ developed by YOOtheme (http:\\/\\/www.yootheme.com)","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10001, 'ZOO Category', 'module', 'mod_zoocategory', '', 0, 1, 0, 0, '{"legacy":false,"name":"ZOO Category","type":"module","creationDate":"October 2012","author":"YOOtheme","copyright":"Copyright (C) YOOtheme GmbH","authorEmail":"info@yootheme.com","authorUrl":"http:\\/\\/www.yootheme.com","version":"3.0.0","description":"Category module for ZOO developed by YOOtheme (http:\\/\\/www.yootheme.com)","group":""}', '{"theme":"","application":"","depth":"0","add_count":"0","menu_item":"","moduleclass_sfx":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10002, 'ZOO Comment', 'module', 'mod_zoocomment', '', 0, 1, 0, 0, '{"legacy":false,"name":"ZOO Comment","type":"module","creationDate":"October 2012","author":"YOOtheme","copyright":"Copyright (C) YOOtheme GmbH","authorEmail":"info@yootheme.com","authorUrl":"http:\\/\\/www.yootheme.com","version":"3.0.0","description":"Comment module for ZOO developed by YOOtheme (http:\\/\\/www.yootheme.com)","group":""}', '{"theme":"","application":"","subcategories":"0","count":"10","show_avatar":"1","avatar_size":"40","show_author":"1","show_meta":"1","moduleclass_sfx":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10003, 'ZOO Item', 'module', 'mod_zooitem', '', 0, 1, 0, 0, '{"legacy":false,"name":"ZOO Item","type":"module","creationDate":"October 2012","author":"YOOtheme","copyright":"Copyright (C) YOOtheme GmbH","authorEmail":"info@yootheme.com","authorUrl":"http:\\/\\/www.yootheme.com","version":"3.0.1","description":"Item module for ZOO developed by YOOtheme (http:\\/\\/www.yootheme.com)","group":""}', '{"theme":"","layout":"","media_position":"left","application":"","subcategories":"0","count":"4","order":"_itemname","moduleclass_sfx":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10004, 'ZOO Quick Icons', 'module', 'mod_zooquickicon', '', 1, 1, 2, 0, '{"legacy":false,"name":"ZOO Quick Icons","type":"module","creationDate":"October 2012","author":"YOOtheme","copyright":"Copyright (C) YOOtheme GmbH","authorEmail":"info@yootheme.com","authorUrl":"http:\\/\\/www.yootheme.com","version":"3.0.0","description":"Quick Icons module for ZOO developed by YOOtheme (http:\\/\\/www.yootheme.com)","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(10005, 'ZOO Tag', 'module', 'mod_zootag', '', 0, 1, 0, 0, '{"legacy":false,"name":"ZOO Tag","type":"module","creationDate":"October 2012","author":"YOOtheme","copyright":"Copyright (C) YOOtheme GmbH","authorEmail":"info@yootheme.com","authorUrl":"http:\\/\\/www.yootheme.com","version":"3.0.0","description":"Tag module for ZOO developed by YOOtheme (http:\\/\\/www.yootheme.com)","group":""}', '{"theme":"","application":"","subcategories":"0","count":"10","order":"alpha","menu_item":"","moduleclass_sfx":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10006, 'Content - ZOO Shortcode', 'plugin', 'zooshortcode', 'content', 0, 1, 1, 0, '{"legacy":false,"name":"Content - ZOO Shortcode","type":"plugin","creationDate":"October 2012","author":"YOOtheme","copyright":"Copyright (C) YOOtheme GmbH","authorEmail":"info@yootheme.com","authorUrl":"http:\\/\\/www.yootheme.com","version":"3.0.0","description":"Shortcode plugin for ZOO developed by YOOtheme (http:\\/\\/www.yootheme.com) Usage: {zooitem OR zoocategory: ID OR alias} Optionally: {zooitem: ID text: MYTEXT}","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10007, 'Smart Search - ZOO', 'plugin', 'zoosmartsearch', 'finder', 0, 1, 1, 0, '{"legacy":false,"name":"Smart Search - ZOO","type":"plugin","creationDate":"Febuary 2012","author":"YOOtheme","copyright":"Copyright (C) YOOtheme GmbH","authorEmail":"info@yootheme.com","authorUrl":"http:\\/\\/www.yootheme.com","version":"2.5.0","description":"Smart Search plugin for ZOO developed by YOOtheme (http:\\/\\/www.yootheme.com)","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10008, 'Search - ZOO', 'plugin', 'zoosearch', 'search', 0, 1, 1, 0, '{"legacy":false,"name":"Search - ZOO","type":"plugin","creationDate":"October 2012","author":"YOOtheme","copyright":"Copyright (C) YOOtheme GmbH","authorEmail":"info@yootheme.com","authorUrl":"http:\\/\\/www.yootheme.com","version":"3.0.0","description":"Search plugin for ZOO developed by YOOtheme (http:\\/\\/www.yootheme.com)","group":""}', '{"search_fulltext":"0","search_limit":"50"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10009, 'System - ZOO Event', 'plugin', 'zooevent', 'system', 0, 1, 1, 0, '{"legacy":false,"name":"System - ZOO Event","type":"plugin","creationDate":"October 2012","author":"YOOtheme","copyright":"Copyright (C) YOOtheme GmbH","authorEmail":"info@yootheme.com","authorUrl":"http:\\/\\/www.yootheme.com","version":"3.0.0","description":"Event plugin for ZOO developed by YOOtheme (http:\\/\\/www.yootheme.com)","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10010, 'zoo', 'package', 'pkg_zoo', '', 0, 1, 1, 0, '{"legacy":false,"name":"ZOO Package","type":"package","creationDate":"March 2014","author":"YOOtheme","copyright":"Copyright (C) YOOtheme GmbH","authorEmail":"info@yootheme.com","authorUrl":"http:\\/\\/www.yootheme.com","version":"3.1.6","description":"ZOO component and extensions for Joomla 2.5+ developed by YOOtheme (http:\\/\\/www.yootheme.com)","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10011, 'System - JBZoo (events)', 'plugin', 'jbzoo', 'system', 0, 1, 1, 0, '{"legacy":false,"name":"System - JBZoo (events)","type":"plugin","creationDate":"2013 01","author":"Joomla-book.ru","copyright":"Joomla-book.ru","authorEmail":"admin@joomla-book.ru","authorUrl":"http:\\/\\/joomla-book.ru","version":"1.6.0","description":"Event plugin for JBZoo by Joomla-book.ru","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10012, 'printsolution', 'template', 'printsolution', '', 0, 1, 1, 0, '{"legacy":false,"name":"printsolution","type":"template","creationDate":"24-09-2013","author":"printsolution","copyright":"Copyright (C) 2013","authorEmail":"asd@asd.ru","authorUrl":"","version":"1.0","description":"printsolution","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10013, 'Fox Contact', 'module', 'mod_foxcontact', '', 0, 1, 0, 0, '{"legacy":false,"name":"Fox Contact","type":"module","creationDate":"Unknown","author":"Demis Palma","copyright":"Demis Palma","authorEmail":"demis@fox.ra.it","authorUrl":"http:\\/\\/www.fox.ra.it\\/","version":"2.0.19","description":"MOD_FOXCONTACT_DESCRIPTION","group":""}', '{"form_width":"100","form_unit":"%","customhtml0display":"1","customhtml0order":"-1000","customhtml1display":"1","customhtml1order":"1000","labelsdisplay":"0","labelswidth":"230","labelsunit":"px","sender0display":"2","sender0order":"5","sender1display":"2","sender1order":"10","sender1isemail":"1","senderwidth":"85","senderunit":"%","text0display":"1","text0order":"15","text1display":"0","text1order":"20","text2display":"0","text2order":"25","text3display":"0","text3order":"30","text4display":"0","text4order":"35","text5display":"0","text5order":"40","text6display":"0","text6order":"45","text7display":"0","text7order":"50","text8display":"0","text8order":"55","text9display":"0","text9order":"60","textwidth":"85","textunit":"%","dropdown0display":"1","dropdown0order":"65","dropdown1display":"0","dropdown1order":"70","dropdown2display":"0","dropdown2order":"75","dropdownwidth":"85","dropdownunit":"%","textarea0display":"1","textarea0order":"80","textarea1display":"0","textarea1order":"85","textarea2display":"0","textarea2order":"90","textareawidth":"85","textareaheight":"180","textareaunit":"%","checkbox0display":"1","checkbox0order":"95","checkbox1display":"0","checkbox1order":"100","checkbox2display":"0","checkbox2order":"105","checkbox3display":"0","checkbox3order":"110","checkbox4display":"0","checkbox4order":"115","uploaddisplay":"0","uploadmethod":"1","uploadmax_file_size":"10000","upload_filter":"1","upload_audio":"0","upload_video":"0","upload_images":"1","upload_documents":"1","upload_archives":"1","submittype":"0","submiticon":"","resetbutton":"0","resettype":"0","reseticon":"","email_sent_action":"0","email_sent_textdisplay":"1","copy_to_submitter":"1","email_copy_summary":"0","spam_check":"1","spam_detected_textdisplay":"1","stdcaptchadisplay":"0","stdcaptchatype":"0","stdcaptcha_length":"5","stdcaptchawidth":"150","stdcaptchaheight":"75","stdcaptchafont":"","stdcaptchafontmin":"14","stdcaptchafontmax":"20","stdcaptchaangle":"20","stdcaptcha_backgroundcolor":"#ffffff","stdcaptcha_textcolor":"#191919","stdcaptcha_disturbcolor":"#c8c8c8","stylesheet":"neon.css","acymailing":"0","acymailing_checkboxes":"hidden|hidden","acymailing_auto_checked":"0","jnews":"0","jnews_checkboxes":"hidden|hidden","jnews_auto_checked":"0","othernewsletters":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10014, 'com_foxcontact', 'component', 'com_foxcontact', '', 1, 1, 0, 0, '{"legacy":false,"name":"COM_FOXCONTACT","type":"component","creationDate":"Unknown","author":"Demis Palma","copyright":"Demis Palma","authorEmail":"demis@fox.ra.it","authorUrl":"http:\\/\\/www.fox.ra.it\\/","version":"2.0.19","description":"COM_FOXCONTACT_DESCRIPTION","group":""}', '{"adminemailfrom":{"select":"admin"},"adminemailreplyto":{"select":"submitter"},"submitteremailfrom":{"select":"admin"},"submitteremailreplyto":{"select":"admin"}}', '', '', 0, '0000-00-00 00:00:00', 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_finder_filters`
--

CREATE TABLE IF NOT EXISTS `sdc98_finder_filters` (
  `filter_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `state` tinyint(1) NOT NULL DEFAULT '1',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL,
  `created_by_alias` varchar(255) NOT NULL,
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `map_count` int(10) unsigned NOT NULL DEFAULT '0',
  `data` text NOT NULL,
  `params` mediumtext,
  PRIMARY KEY (`filter_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_finder_links`
--

CREATE TABLE IF NOT EXISTS `sdc98_finder_links` (
  `link_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `route` varchar(255) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `indexdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `md5sum` varchar(32) DEFAULT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `state` int(5) DEFAULT '1',
  `access` int(5) DEFAULT '0',
  `language` varchar(8) NOT NULL,
  `publish_start_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_end_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `start_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `end_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `list_price` double unsigned NOT NULL DEFAULT '0',
  `sale_price` double unsigned NOT NULL DEFAULT '0',
  `type_id` int(11) NOT NULL,
  `object` mediumblob NOT NULL,
  PRIMARY KEY (`link_id`),
  KEY `idx_type` (`type_id`),
  KEY `idx_title` (`title`),
  KEY `idx_md5` (`md5sum`),
  KEY `idx_url` (`url`(75)),
  KEY `idx_published_list` (`published`,`state`,`access`,`publish_start_date`,`publish_end_date`,`list_price`),
  KEY `idx_published_sale` (`published`,`state`,`access`,`publish_start_date`,`publish_end_date`,`sale_price`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Дамп данных таблицы `sdc98_finder_links`
--

INSERT INTO `sdc98_finder_links` (`link_id`, `url`, `route`, `title`, `description`, `indexdate`, `md5sum`, `published`, `state`, `access`, `language`, `publish_start_date`, `publish_end_date`, `start_date`, `end_date`, `list_price`, `sale_price`, `type_id`, `object`) VALUES
(4, 'index.php?option=com_zoo&view=item&id=2', 'index.php?option=com_zoo&task=item&item_id=2', 'Вася Пупкин', '', '2014-07-21 11:09:29', 'c2851e6a14441099ab24792ef0eeea29', 1, 1, 1, '*', '2014-07-21 08:07:17', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, 1, 0x4f3a31393a2246696e646572496e6465786572526573756c74223a31383a7b733a31313a22002a00656c656d656e7473223b613a31323a7b733a323a226964223b733a313a2232223b733a353a22616c696173223b733a31323a2276617379612d7075706b696e223b733a31363a22637265617465645f62795f616c696173223b733a303a22223b733a383a226d6f646966696564223b733a31393a22323031342d30372d32312030383a30393a3237223b733a31313a226d6f6469666965645f6279223b733a333a22363433223b733a31303a2273656172636861626c65223b733a313a2231223b733a363a226c61796f7574223b733a343a226974656d223b733a383a226d65746164617461223b4f3a393a224a5265676973747279223a313a7b733a373a22002a0064617461223b4f3a383a22737464436c617373223a353a7b733a353a227469746c65223b733a303a22223b733a31313a226465736372697074696f6e223b733a303a22223b733a383a226b6579776f726473223b733a303a22223b733a363a22726f626f7473223b733a303a22223b733a363a22617574686f72223b733a303a22223b7d7d733a31303a226d657461617574686f72223b733a303a22223b733a373a2273756d6d617279223b733a303a22223b733a343a2270617468223b733a34313a22696e6465782e7068702f636f6d706f6e656e742f7a6f6f2f6974656d2f76617379612d7075706b696e223b733a31323a22656c656d656e745f64617461223b613a323a7b693a303b733a36303a22d0b3d0b5d0bdd0b5d180d0b0d0bbd18cd0bdd18bd0b920d0b4d0b8d180d0b5d0bad182d0bed18020c2abd09ad0bed0bcd0bfd0b0d0bdd0b8d0b8c2bb223b693a313b733a3332363a224c6f72656d20697073756d20646f6c6f722073697420616d65742c20636f6e73656374657475722061646970697363696e6720656c69742e2053656420706f7375657265206d6f6c6573746965206c6563747573757420766f6c75747061742e20566976616d75732065742076656e656e61746973206d61757269732c20706f737565726520706c61636572617420697073756d2e2050726f696e206c6163696e69616f726369206573742c20766974616520656c656d656e74756d2074656c6c757320766976657272612075742e204e756e632066657567696174206d61676e61e2809d2061632065726f7320656c656d656e74756d20616c69717565742e204e756c6c6120617420706f72747469746f72206f64696f2e205175697371756520736564206f726369206574206f726369207363656c657269737175652073656d7065722e223b7d7d733a31353a22002a00696e737472756374696f6e73223b613a353a7b693a313b613a333a7b693a303b733a353a227469746c65223b693a313b733a383a227375627469746c65223b693a323b733a323a226964223b7d693a323b613a323a7b693a303b733a373a2273756d6d617279223b693a313b733a343a22626f6479223b7d693a333b613a31303a7b693a303b733a343a226d657461223b693a313b733a31303a226c6973745f7072696365223b693a323b733a31303a2273616c655f7072696365223b693a333b733a343a226c696e6b223b693a343b733a373a226d6574616b6579223b693a353b733a383a226d65746164657363223b693a363b733a31303a226d657461617574686f72223b693a373b733a363a22617574686f72223b693a383b733a31363a22637265617465645f62795f616c696173223b693a393b733a31323a22656c656d656e745f64617461223b7d693a343b613a323a7b693a303b733a343a2270617468223b693a313b733a353a22616c696173223b7d693a353b613a313a7b693a303b733a383a22636f6d6d656e7473223b7d7d733a31313a22002a007461786f6e6f6d79223b613a313a7b733a343a2254797065223b613a313a7b733a31303a22d09ed182d0b7d18bd0b2223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a31303a22d09ed182d0b7d18bd0b2223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d7d7d733a333a2275726c223b733a33393a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f26766965773d6974656d2669643d32223b733a353a22726f757465223b733a34343a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f267461736b3d6974656d266974656d5f69643d32223b733a353a227469746c65223b733a32313a22d092d0b0d181d18f20d09fd183d0bfd0bad0b8d0bd223b733a31313a226465736372697074696f6e223b733a303a22223b733a393a227075626c6973686564223b4e3b733a353a227374617465223b623a313b733a363a22616363657373223b733a313a2231223b733a383a226c616e6775616765223b733a313a222a223b733a31383a227075626c6973685f73746172745f64617465223b733a31393a22323031342d30372d32312030383a30373a3137223b733a31363a227075626c6973685f656e645f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a31303a2273746172745f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a383a22656e645f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a31303a226c6973745f7072696365223b4e3b733a31303a2273616c655f7072696365223b4e3b733a373a22747970655f6964223b693a313b7d),
(10, 'index.php?option=com_zoo&view=item&id=3', 'index.php?option=com_zoo&task=item&item_id=3', 'Вася Пупкин 2', '', '2014-07-21 11:38:08', 'ca8736921f28be7b9937715b88c92a89', 1, 1, 1, '*', '2014-07-21 08:07:17', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, 1, 0x4f3a31393a2246696e646572496e6465786572526573756c74223a31383a7b733a31313a22002a00656c656d656e7473223b613a31323a7b733a323a226964223b733a313a2233223b733a353a22616c696173223b733a31343a2276617379612d7075706b696e2d32223b733a31363a22637265617465645f62795f616c696173223b733a303a22223b733a383a226d6f646966696564223b733a31393a22323031342d30372d32312030383a33383a3037223b733a31313a226d6f6469666965645f6279223b733a333a22363433223b733a31303a2273656172636861626c65223b733a313a2231223b733a363a226c61796f7574223b733a343a226974656d223b733a383a226d65746164617461223b4f3a393a224a5265676973747279223a313a7b733a373a22002a0064617461223b4f3a383a22737464436c617373223a353a7b733a353a227469746c65223b733a303a22223b733a31313a226465736372697074696f6e223b733a303a22223b733a383a226b6579776f726473223b733a303a22223b733a363a22726f626f7473223b733a303a22223b733a363a22617574686f72223b733a303a22223b7d7d733a31303a226d657461617574686f72223b733a303a22223b733a373a2273756d6d617279223b733a303a22223b733a343a2270617468223b733a34333a22696e6465782e7068702f636f6d706f6e656e742f7a6f6f2f6974656d2f76617379612d7075706b696e2d32223b733a31323a22656c656d656e745f64617461223b613a323a7b693a303b733a36303a22d0b3d0b5d0bdd0b5d180d0b0d0bbd18cd0bdd18bd0b920d0b4d0b8d180d0b5d0bad182d0bed18020c2abd09ad0bed0bcd0bfd0b0d0bdd0b8d0b8c2bb223b693a313b733a3332363a224c6f72656d20697073756d20646f6c6f722073697420616d65742c20636f6e73656374657475722061646970697363696e6720656c69742e2053656420706f7375657265206d6f6c6573746965206c6563747573757420766f6c75747061742e20566976616d75732065742076656e656e61746973206d61757269732c20706f737565726520706c61636572617420697073756d2e2050726f696e206c6163696e69616f726369206573742c20766974616520656c656d656e74756d2074656c6c757320766976657272612075742e204e756e632066657567696174206d61676e61e2809d2061632065726f7320656c656d656e74756d20616c69717565742e204e756c6c6120617420706f72747469746f72206f64696f2e205175697371756520736564206f726369206574206f726369207363656c657269737175652073656d7065722e223b7d7d733a31353a22002a00696e737472756374696f6e73223b613a353a7b693a313b613a333a7b693a303b733a353a227469746c65223b693a313b733a383a227375627469746c65223b693a323b733a323a226964223b7d693a323b613a323a7b693a303b733a373a2273756d6d617279223b693a313b733a343a22626f6479223b7d693a333b613a31303a7b693a303b733a343a226d657461223b693a313b733a31303a226c6973745f7072696365223b693a323b733a31303a2273616c655f7072696365223b693a333b733a343a226c696e6b223b693a343b733a373a226d6574616b6579223b693a353b733a383a226d65746164657363223b693a363b733a31303a226d657461617574686f72223b693a373b733a363a22617574686f72223b693a383b733a31363a22637265617465645f62795f616c696173223b693a393b733a31323a22656c656d656e745f64617461223b7d693a343b613a323a7b693a303b733a343a2270617468223b693a313b733a353a22616c696173223b7d693a353b613a313a7b693a303b733a383a22636f6d6d656e7473223b7d7d733a31313a22002a007461786f6e6f6d79223b613a313a7b733a343a2254797065223b613a313a7b733a31303a22d09ed182d0b7d18bd0b2223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a31303a22d09ed182d0b7d18bd0b2223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d7d7d733a333a2275726c223b733a33393a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f26766965773d6974656d2669643d33223b733a353a22726f757465223b733a34343a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f267461736b3d6974656d266974656d5f69643d33223b733a353a227469746c65223b733a32333a22d092d0b0d181d18f20d09fd183d0bfd0bad0b8d0bd2032223b733a31313a226465736372697074696f6e223b733a303a22223b733a393a227075626c6973686564223b4e3b733a353a227374617465223b623a313b733a363a22616363657373223b733a313a2231223b733a383a226c616e6775616765223b733a313a222a223b733a31383a227075626c6973685f73746172745f64617465223b733a31393a22323031342d30372d32312030383a30373a3137223b733a31363a227075626c6973685f656e645f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a31303a2273746172745f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a383a22656e645f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a31303a226c6973745f7072696365223b4e3b733a31303a2273616c655f7072696365223b4e3b733a373a22747970655f6964223b693a313b7d),
(11, 'index.php?option=com_zoo&view=item&id=5', 'index.php?option=com_zoo&task=item&item_id=5', 'Вася Пупкин 3', '', '2014-07-21 11:38:28', 'c1798ef18c21c4b2b9168fa5cf4ce71e', 1, 1, 1, '*', '2014-07-21 08:07:17', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, 1, 0x4f3a31393a2246696e646572496e6465786572526573756c74223a31383a7b733a31313a22002a00656c656d656e7473223b613a31323a7b733a323a226964223b733a313a2235223b733a353a22616c696173223b733a31343a2276617379612d7075706b696e2d33223b733a31363a22637265617465645f62795f616c696173223b733a303a22223b733a383a226d6f646966696564223b733a31393a22323031342d30372d32312030383a33383a3237223b733a31313a226d6f6469666965645f6279223b733a333a22363433223b733a31303a2273656172636861626c65223b733a313a2231223b733a363a226c61796f7574223b733a343a226974656d223b733a383a226d65746164617461223b4f3a393a224a5265676973747279223a313a7b733a373a22002a0064617461223b4f3a383a22737464436c617373223a353a7b733a353a227469746c65223b733a303a22223b733a31313a226465736372697074696f6e223b733a303a22223b733a383a226b6579776f726473223b733a303a22223b733a363a22726f626f7473223b733a303a22223b733a363a22617574686f72223b733a303a22223b7d7d733a31303a226d657461617574686f72223b733a303a22223b733a373a2273756d6d617279223b733a303a22223b733a343a2270617468223b733a34333a22696e6465782e7068702f636f6d706f6e656e742f7a6f6f2f6974656d2f76617379612d7075706b696e2d33223b733a31323a22656c656d656e745f64617461223b613a323a7b693a303b733a36303a22d0b3d0b5d0bdd0b5d180d0b0d0bbd18cd0bdd18bd0b920d0b4d0b8d180d0b5d0bad182d0bed18020c2abd09ad0bed0bcd0bfd0b0d0bdd0b8d0b8c2bb223b693a313b733a3332363a224c6f72656d20697073756d20646f6c6f722073697420616d65742c20636f6e73656374657475722061646970697363696e6720656c69742e2053656420706f7375657265206d6f6c6573746965206c6563747573757420766f6c75747061742e20566976616d75732065742076656e656e61746973206d61757269732c20706f737565726520706c61636572617420697073756d2e2050726f696e206c6163696e69616f726369206573742c20766974616520656c656d656e74756d2074656c6c757320766976657272612075742e204e756e632066657567696174206d61676e61e2809d2061632065726f7320656c656d656e74756d20616c69717565742e204e756c6c6120617420706f72747469746f72206f64696f2e205175697371756520736564206f726369206574206f726369207363656c657269737175652073656d7065722e223b7d7d733a31353a22002a00696e737472756374696f6e73223b613a353a7b693a313b613a333a7b693a303b733a353a227469746c65223b693a313b733a383a227375627469746c65223b693a323b733a323a226964223b7d693a323b613a323a7b693a303b733a373a2273756d6d617279223b693a313b733a343a22626f6479223b7d693a333b613a31303a7b693a303b733a343a226d657461223b693a313b733a31303a226c6973745f7072696365223b693a323b733a31303a2273616c655f7072696365223b693a333b733a343a226c696e6b223b693a343b733a373a226d6574616b6579223b693a353b733a383a226d65746164657363223b693a363b733a31303a226d657461617574686f72223b693a373b733a363a22617574686f72223b693a383b733a31363a22637265617465645f62795f616c696173223b693a393b733a31323a22656c656d656e745f64617461223b7d693a343b613a323a7b693a303b733a343a2270617468223b693a313b733a353a22616c696173223b7d693a353b613a313a7b693a303b733a383a22636f6d6d656e7473223b7d7d733a31313a22002a007461786f6e6f6d79223b613a313a7b733a343a2254797065223b613a313a7b733a31303a22d09ed182d0b7d18bd0b2223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a31303a22d09ed182d0b7d18bd0b2223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d7d7d733a333a2275726c223b733a33393a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f26766965773d6974656d2669643d35223b733a353a22726f757465223b733a34343a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f267461736b3d6974656d266974656d5f69643d35223b733a353a227469746c65223b733a32333a22d092d0b0d181d18f20d09fd183d0bfd0bad0b8d0bd2033223b733a31313a226465736372697074696f6e223b733a303a22223b733a393a227075626c6973686564223b4e3b733a353a227374617465223b623a313b733a363a22616363657373223b733a313a2231223b733a383a226c616e6775616765223b733a313a222a223b733a31383a227075626c6973685f73746172745f64617465223b733a31393a22323031342d30372d32312030383a30373a3137223b733a31363a227075626c6973685f656e645f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a31303a2273746172745f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a383a22656e645f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a31303a226c6973745f7072696365223b4e3b733a31303a2273616c655f7072696365223b4e3b733a373a22747970655f6964223b693a313b7d),
(12, 'index.php?option=com_zoo&view=item&id=4', 'index.php?option=com_zoo&task=item&item_id=4', 'Вася Пупкин 4', '', '2014-07-21 11:38:47', '4dd1e51ea26b5ea5ee91e358e04f8266', 1, 1, 1, '*', '2014-07-21 08:07:17', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, 1, 0x4f3a31393a2246696e646572496e6465786572526573756c74223a31383a7b733a31313a22002a00656c656d656e7473223b613a31323a7b733a323a226964223b733a313a2234223b733a353a22616c696173223b733a31343a2276617379612d7075706b696e2d34223b733a31363a22637265617465645f62795f616c696173223b733a303a22223b733a383a226d6f646966696564223b733a31393a22323031342d30372d32312030383a33383a3436223b733a31313a226d6f6469666965645f6279223b733a333a22363433223b733a31303a2273656172636861626c65223b733a313a2231223b733a363a226c61796f7574223b733a343a226974656d223b733a383a226d65746164617461223b4f3a393a224a5265676973747279223a313a7b733a373a22002a0064617461223b4f3a383a22737464436c617373223a353a7b733a353a227469746c65223b733a303a22223b733a31313a226465736372697074696f6e223b733a303a22223b733a383a226b6579776f726473223b733a303a22223b733a363a22726f626f7473223b733a303a22223b733a363a22617574686f72223b733a303a22223b7d7d733a31303a226d657461617574686f72223b733a303a22223b733a373a2273756d6d617279223b733a303a22223b733a343a2270617468223b733a34333a22696e6465782e7068702f636f6d706f6e656e742f7a6f6f2f6974656d2f76617379612d7075706b696e2d34223b733a31323a22656c656d656e745f64617461223b613a323a7b693a303b733a36303a22d0b3d0b5d0bdd0b5d180d0b0d0bbd18cd0bdd18bd0b920d0b4d0b8d180d0b5d0bad182d0bed18020c2abd09ad0bed0bcd0bfd0b0d0bdd0b8d0b8c2bb223b693a313b733a3332363a224c6f72656d20697073756d20646f6c6f722073697420616d65742c20636f6e73656374657475722061646970697363696e6720656c69742e2053656420706f7375657265206d6f6c6573746965206c6563747573757420766f6c75747061742e20566976616d75732065742076656e656e61746973206d61757269732c20706f737565726520706c61636572617420697073756d2e2050726f696e206c6163696e69616f726369206573742c20766974616520656c656d656e74756d2074656c6c757320766976657272612075742e204e756e632066657567696174206d61676e61e2809d2061632065726f7320656c656d656e74756d20616c69717565742e204e756c6c6120617420706f72747469746f72206f64696f2e205175697371756520736564206f726369206574206f726369207363656c657269737175652073656d7065722e223b7d7d733a31353a22002a00696e737472756374696f6e73223b613a353a7b693a313b613a333a7b693a303b733a353a227469746c65223b693a313b733a383a227375627469746c65223b693a323b733a323a226964223b7d693a323b613a323a7b693a303b733a373a2273756d6d617279223b693a313b733a343a22626f6479223b7d693a333b613a31303a7b693a303b733a343a226d657461223b693a313b733a31303a226c6973745f7072696365223b693a323b733a31303a2273616c655f7072696365223b693a333b733a343a226c696e6b223b693a343b733a373a226d6574616b6579223b693a353b733a383a226d65746164657363223b693a363b733a31303a226d657461617574686f72223b693a373b733a363a22617574686f72223b693a383b733a31363a22637265617465645f62795f616c696173223b693a393b733a31323a22656c656d656e745f64617461223b7d693a343b613a323a7b693a303b733a343a2270617468223b693a313b733a353a22616c696173223b7d693a353b613a313a7b693a303b733a383a22636f6d6d656e7473223b7d7d733a31313a22002a007461786f6e6f6d79223b613a313a7b733a343a2254797065223b613a313a7b733a31303a22d09ed182d0b7d18bd0b2223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a31303a22d09ed182d0b7d18bd0b2223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d7d7d733a333a2275726c223b733a33393a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f26766965773d6974656d2669643d34223b733a353a22726f757465223b733a34343a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f267461736b3d6974656d266974656d5f69643d34223b733a353a227469746c65223b733a32333a22d092d0b0d181d18f20d09fd183d0bfd0bad0b8d0bd2034223b733a31313a226465736372697074696f6e223b733a303a22223b733a393a227075626c6973686564223b4e3b733a353a227374617465223b623a313b733a363a22616363657373223b733a313a2231223b733a383a226c616e6775616765223b733a313a222a223b733a31383a227075626c6973685f73746172745f64617465223b733a31393a22323031342d30372d32312030383a30373a3137223b733a31363a227075626c6973685f656e645f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a31303a2273746172745f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a383a22656e645f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a31303a226c6973745f7072696365223b4e3b733a31303a2273616c655f7072696365223b4e3b733a373a22747970655f6964223b693a313b7d),
(13, 'index.php?option=com_zoo&view=item&id=1', 'index.php?option=com_zoo&view=item&layout=item&Itemid=101', 'Сувенирная продукция', '', '2014-07-21 11:39:35', '6f8e3cc76bfba83bbc90d33642d5b754', 1, 1, 1, '*', '2014-07-18 13:42:45', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, 1, 0x4f3a31393a2246696e646572496e6465786572526573756c74223a31383a7b733a31313a22002a00656c656d656e7473223b613a31323a7b733a323a226964223b733a313a2231223b733a353a22616c696173223b733a32323a22737576656e69726e6179612d70726f64756b63697961223b733a31363a22637265617465645f62795f616c696173223b733a303a22223b733a383a226d6f646966696564223b733a31393a22323031342d30372d32312030383a33393a3334223b733a31313a226d6f6469666965645f6279223b733a333a22363433223b733a31303a2273656172636861626c65223b733a313a2231223b733a363a226c61796f7574223b733a343a226974656d223b733a383a226d65746164617461223b4f3a393a224a5265676973747279223a313a7b733a373a22002a0064617461223b4f3a383a22737464436c617373223a353a7b733a353a227469746c65223b733a303a22223b733a31313a226465736372697074696f6e223b733a303a22223b733a383a226b6579776f726473223b733a303a22223b733a363a22726f626f7473223b733a303a22223b733a363a22617574686f72223b733a303a22223b7d7d733a31303a226d657461617574686f72223b733a303a22223b733a373a2273756d6d617279223b733a303a22223b733a343a2270617468223b733a303a22223b733a31323a22656c656d656e745f64617461223b613a383a7b693a303b733a3737393a224c6f72656d20697073756d20646f6c6f722073697420616d65742c20636f6e73656374657475722061646970697363696e6720656c69742e2053656420706f7375657265206d6f6c6573746965206c656374757320757420766f6c75747061742e20566976616d75732065742076656e656e61746973206d61757269732c20706f737565726520706c61636572617420697073756d2e2050726f696e206c6163696e6961206f726369206573742c20766974616520656c656d656e74756d2074656c6c757320766976657272612075742e204e756e632066657567696174206d61676e612061632065726f7320656c656d656e74756d20616c69717565742e204e756c6c6120617420706f72747469746f72206f64696f2e205175697371756520736564206f726369206574206f726369207363656c657269737175652073656d7065722e4c6f72656d20697073756d20646f6c6f722073697420616d65742c20636f6e73656374657475722061646970697363696e6720656c69742e2053656420706f7375c2a06f726369206573742c20766974616520656c656d656e74756d2074656c6c757320766976657272612075742e204e756e632066657567696174206d61676e612061632065726f7320656c656d656e74756d20616c69717565742e204e756c6c6120617420706f72747469746f72206f64696f2e205175697371756520736564206f726369206574206f726369207363656c657269737175652073656d706572c2a0566976616d75732065742076656e656e61746973206d61757269732c20706f737565726520706c61636572617420697073756d2e2050726f696e206c6163696e6961206f726369206573742c20766974616520656c656d656e74756d2074656c6c757320766976657272612075742e204e756e632066657567696174206d61676e612061632065726f7320656c656d656e74756d20616c69717565742e204e756c6c6120617420706f72747469746f72206f64696f2e205175697371756520736564206f726369206574206f726369207363656c657269737175652073656d706572223b693a313b733a3837373a224c6f72656d20697073756d20646f6c6f722073697420616d65742c20636f6e73656374657475722061646970697363696e6720656c69742e2053656420706f7375657265206d6f6c6573746965206c656374757320757420766f6c75747061742e20566976616d75732065742076656e656e61746973206d61757269732c20706f737565726520706c61636572617420697073756d2e2050726f696e206c6163696e6961206f726369206573742c20766974616520656c656d656e74756d2074656c6c757320766976657272612075742e204e756e632066657567696174206d61676e612061632065726f7320656c656d656e74756d20616c69717565742e204e756c6c6120617420706f72747469746f72206f64696f2e205175697371756520736564206f726369206574206f726369207363656c657269737175652073656d7065722e4c6f72656d20697073756d20646f6c6f722073697420616d65742c20636f6e73656374657475722061646970697363696e6720656c69742e2053656420706f7375657265206d6f6c6573746965206c656374757320757420766f6c75747061742e20566976616d75732065742076656e656e61746973206d61757269732c20706f737565726520706c61636572617420697073756d2e2050726f696e206c6163696e6961206f726369206573742c20766974616520656c656d656e74756d2074656c6c757320766976657272612075742e204e756e632066657567696174206d61676e612061632065726f7320656c656d656e74756d20616c69717565742e204e756c6c6120617420706f72747469746f72206f64696f2e205175697371756520736564206f726369206574206f726369207363656c657269737175652073656d706572c2a0566976616d75732065742076656e656e61746973206d61757269732c20706f737565726520706c61636572617420697073756d2e2050726f696e206c6163696e6961206f726369206573742c20766974616520656c656d656e74756d2074656c6c757320766976657272612075742e204e756e632066657567696174206d61676e612061632065726f7320656c656d656e74756d20616c69717565742e204e756c6c6120617420706f72747469746f72206f64696f2e205175697371756520736564206f726369206574206f726369207363656c657269737175652073656d706572223b693a323b733a3338363a22d09bd18ed0b1d18bd0b520d0b2d0b8d0b4d18b20d181d183d0b2d0b5d0bdd0b8d180d0bdd0bed0b920d0bfd180d0bed0b4d183d0bad186d0b8d0b80d0a4c6f72656d20697073756d20646f6c6f722073697420616d65742c20636f6e73656374657475722061646970697363696e6720656c69742e2053656420706f7375657265206d6f6c6573746965206c656374757320757420766f6c75747061742e20566976616d75732065742076656e656e61746973206d61757269732c20706f737565726520706c61636572617420697073756d2e2050726f696e206c6163696e6961206f726369206573742c20766974616520656c656d656e74756d2074656c6c757320766976657272612075742e204e756e632066657567696174206d61676e612061632065726f7320656c656d656e74756d20616c69717565742e204e756c6c6120617420706f72747469746f72206f64696f2e205175697371756520736564206f726369206574206f726369207363656c657269737175652073656d7065722e223b693a333b733a3130313a22d09ad180d183d0b6d0bad0b80ad0a4d183d182d0b1d0bed0bbd0bad0b80ad09fd0bed0b4d183d188d0bad0b80ad091d180d0b5d0bbd0bed0bad0b80ad09fd0b0d0b7d0bbd18b0ad09ad180d183d0b6d0bad0b8320a0ad09fd0bed0b4d183d188d0bad0b832223b693a343b733a3738363a22d09ed0bdd0bbd0b0d0b9d0bd20d180d0b5d188d0b5d0bdd0b8d0b520d0b4d0bbd18f20d184d0bed182d0bed186d0b5d0bdd182d180d0bed0b22c20d0bfd0bed0bbd0b8d0b3d180d0b0d184d0b8d187d0b5d181d0bad0b8d18520d0b820d181d183d0b2d0b5d0bdd0b8d180d0bdd18bd18520d0bad0bed0bcd0bfd0b0d0bdd0b8d0b90d0ad097d0b4d0b5d181d18c20d0b4d0bed0bbd0b6d0bdd0b020d0bad180d0b0d182d0bad0be20d180d0b0d181d188d0b8d184d180d0bed0b2d18bd0b2d0b0d182d18cd181d18f20d181d183d182d18c20d0bfd180d0b5d0b4d0bbd0bed0b6d0b5d0bdd0b8d18f202b20d0bfd0b5d180d0b5d187d0b8d181d0bbd0b5d0bdd0b8d0b520d0bad0b0d0bad0b8d1852dd182d0be20d0bad0bbd18ed187d0b2d18bd18520d0bfd0bbd18ed189d0b5d0ba2c20d0bad0bed182d0bed180d18bd0b520d0bfd0bed0bbd183d187d0b8d18220d0bad0bbd0b8d0b5d0bdd1822e20d097d0b4d0b5d181d18c20d0b4d0bed0bbd0b6d0bdd0b020d0bad180d0b0d182d0bad0be20d180d0b0d181d188d0b8d184d180d0bed0b2d18bd0b2d0b0d182d18cd181d18f20d181d183d182d18c20d0bfd180d0b5d0b4d0bbd0bed0b6d0b5d0bdd0b8d18f202b20d0bfd0b5d180d0b5d187d0b8d181d0bbd0b5d0bdd0b8d0b520d0bad0b0d0bad0b8d1852dd182d0be20d0bad0bbd18ed187d0b2d18bd18520d0bfd0bbd18ed189d0b5d0ba2c20d0bad0bed182d0bed180d18bd0b520d0bfd0bed0bbd183d187d0b8d18220d0bad0bbd0b8d0b5d0bdd1822e20d097d0b4d0b5d181d18c20d0b4d0bed0bbd0b6d0bdd0b020d0bad180d0b0d182d0bad0be20d180d0b0d181d188d0b8d184d180d0bed0b2d18bd0b2d0b0d182d18cd181d18f20d181d183d182d18c20d0bfd180d0b5d0b4d0bbd0be20d0b6d0b5d0bdd0b8d18f202b20d0bfd0b5d180d0b5d187d0b8d181d0bbd0b5d0bdd0b8d0b520d0bad0b0d0bad0b8d1852dd182d0be20d0bad0bbd18ed187d0b2d18bd18520d0bfd0bbd18ed189d0b5d0ba2c20d0bad0bed182d0bed180d18bd0b520d0bfd0bed0bbd183d187d0b8d18220d0bad0bbd0b8d0b5d0bdd1822e223b693a353b733a3736313a224c6f72656d20697073756d20646f6c6f722073697420616d65742c20636f6e73656374657475722061646970697363696e6720656c69742e2053656420706f7375657265206d6f6c6573746965206c656374757320757420766f6c75747061742e20566976616d75732065742076656e656e61746973206d61757269732c20706f737565726520706c61636572617420697073756d2e2050726f696e206c6163696e6961206f726369206573742c20766974616520656c656d656e74756d2074656c6c757320766976657272612075742e204e756e632066657567696174206d61676e612061632065726f7320656c656d656e74756d20616c69717565742e204e756c6c6120617420706f72747469746f72206f64696f2e205175697371756520736564206f726369206574206f726369207363656c657269737175652073656d7065722e4c6f72656d20697073756d20646f6c6f722073697420616d65742c20636f6e73656374657475722061646970697363696e6720656c69742e2053656420706f7375657265206d6f6c6573746965206c656374757320757420766f6c75747061742e20566976616d75732065742076656e656e61746973206d61757269732c20706f737565726520706c61636572617420697073756d2e2050726f696e206c6163696e6961206f726369206573742c20766974616520656c656d656e74756d2074656c6c757320766976657272612075742e204e756e632066657567696174206d61676e612061632065726f7320656c656d656e74756d20616c69717565742e204e756c6c6120617420706f72747469746f72206f64696f2e205175697371756520736564206f726369206574206f726369207363656c657269737175652073656d7065720d0a566976616d75732065742076656e656e61746973206d61757269732c20706f737565726520706c61636572617420697073756d2e2050726f696e206c6163696e6961206f726369206573742c20766974616520656c656d656e74756d2074656c6c75732076697665727261207574223b693a363b733a3634393a224c6f72656d20697073756d20646f6c6f722073697420616d65742c20636f6e73656374657475722061646970697363696e6720656c69742e2053656420706f7375657265206d6f6c6573746965206c656374757320757420766f6c75747061742e20566976616d75732065742076656e656e61746973206d61757269732c20706f737565726520706c61636572617420697073756d2e2050726f696e206c6163696e6961206f726369206573742c20766974616520656c656d656e74756d2074656c6c757320766976657272612075742e204e756e632066657567696174206d61676e612061632065726f7320656c656d656e74756d20616c69717565742e204e756c6c6120617420706f72747469746f72206f64696f2e205175697371756520736564206f726369206574206f726369207363656c657269737175652073656d7065722e4c6f72656d20697073756d20646f6c6f722073697420616d65742c20636f6e73656374657475722061646970697363696e6720656c69742e2053656420706f7375657265206d6f6c6573746965206c656374757320757420766f6c75747061742e20566976616d75732065742076656e656e61746973206d61757269732c20706f737565726520706c61636572617420697073756d2e2050726f696e206c6163696e6961206f726369206573742c20766974616520656c656d656e74756d2074656c6c757320766976657272612075742e204e756e632066657567696174206d61676e612061632065726f7320656c656d656e74756d20616c69717565742e204e756c6c6120617420706f72747469746f72206f64696f2e205175697371756520736564206f726369206574206f726369207363656c657269737175652073656d706572223b693a373b733a39323a22d09ed182d0bad180d0bed0b920d181d0b2d0bed0b920d181d0b0d0b9d18220d0b7d0b0d0bad0b0d0b7d0bed0b220d0bdd0b020d181d183d0b2d0b5d0bdd0b8d0b8d180d0bdd183d18e20d0bfd180d0bed0b4d183d0bad186d0b8d18e223b7d7d733a31353a22002a00696e737472756374696f6e73223b613a353a7b693a313b613a333a7b693a303b733a353a227469746c65223b693a313b733a383a227375627469746c65223b693a323b733a323a226964223b7d693a323b613a323a7b693a303b733a373a2273756d6d617279223b693a313b733a343a22626f6479223b7d693a333b613a31303a7b693a303b733a343a226d657461223b693a313b733a31303a226c6973745f7072696365223b693a323b733a31303a2273616c655f7072696365223b693a333b733a343a226c696e6b223b693a343b733a373a226d6574616b6579223b693a353b733a383a226d65746164657363223b693a363b733a31303a226d657461617574686f72223b693a373b733a363a22617574686f72223b693a383b733a31363a22637265617465645f62795f616c696173223b693a393b733a31323a22656c656d656e745f64617461223b7d693a343b613a323a7b693a303b733a343a2270617468223b693a313b733a353a22616c696173223b7d693a353b613a313a7b693a303b733a383a22636f6d6d656e7473223b7d7d733a31313a22002a007461786f6e6f6d79223b613a313a7b733a343a2254797065223b613a313a7b733a31343a22d09fd180d0bed0b4d183d0bad182223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a31343a22d09fd180d0bed0b4d183d0bad182223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d7d7d733a333a2275726c223b733a33393a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f26766965773d6974656d2669643d31223b733a353a22726f757465223b733a35373a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f26766965773d6974656d266c61796f75743d6974656d264974656d69643d313031223b733a353a227469746c65223b733a33393a22d0a1d183d0b2d0b5d0bdd0b8d180d0bdd0b0d18f20d0bfd180d0bed0b4d183d0bad186d0b8d18f223b733a31313a226465736372697074696f6e223b733a303a22223b733a393a227075626c6973686564223b4e3b733a353a227374617465223b623a313b733a363a22616363657373223b733a313a2231223b733a383a226c616e6775616765223b733a313a222a223b733a31383a227075626c6973685f73746172745f64617465223b733a31393a22323031342d30372d31382031333a34323a3435223b733a31363a227075626c6973685f656e645f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a31303a2273746172745f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a383a22656e645f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a31303a226c6973745f7072696365223b4e3b733a31303a2273616c655f7072696365223b4e3b733a373a22747970655f6964223b693a313b7d);

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_finder_links_terms0`
--

CREATE TABLE IF NOT EXISTS `sdc98_finder_links_terms0` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sdc98_finder_links_terms0`
--

INSERT INTO `sdc98_finder_links_terms0` (`link_id`, `term_id`, `weight`) VALUES
(4, 1024, 0.15996),
(10, 1024, 0.15996),
(11, 1024, 0.15996),
(12, 1024, 0.15996),
(13, 1024, 1.75956),
(4, 1025, 1.47996),
(10, 1025, 1.47996),
(11, 1025, 1.47996),
(12, 1025, 1.47996),
(13, 1025, 16.2796),
(4, 1026, 1.88004),
(10, 1026, 1.88004),
(11, 1026, 1.88004),
(12, 1026, 1.88004),
(13, 1026, 20.6804),
(4, 1027, 0.80004),
(10, 1027, 0.80004),
(11, 1027, 0.80004),
(12, 1027, 0.80004),
(13, 1027, 7.20036),
(4, 1028, 1.8),
(10, 1028, 1.8),
(11, 1028, 1.8),
(12, 1028, 1.8),
(13, 1028, 16.2),
(4, 1029, 1.95996),
(10, 1029, 1.95996),
(11, 1029, 1.95996),
(12, 1029, 1.95996),
(13, 1029, 17.6396),
(4, 1030, 0.56004),
(10, 1030, 0.56004),
(11, 1030, 0.56004),
(12, 1030, 0.56004),
(13, 1030, 6.16044),
(4, 1031, 1.71996),
(10, 1031, 1.71996),
(11, 1031, 1.71996),
(12, 1031, 1.71996),
(13, 1031, 18.9196),
(4, 1032, 1.83996),
(10, 1032, 1.83996),
(11, 1032, 1.83996),
(12, 1032, 1.83996),
(13, 1032, 20.2396),
(4, 1033, 0.32004),
(10, 1033, 0.32004),
(11, 1033, 0.32004),
(12, 1033, 0.32004),
(13, 1033, 2.88036),
(4, 1034, 1.83996),
(10, 1034, 1.83996),
(11, 1034, 1.83996),
(12, 1034, 1.83996),
(13, 1034, 16.5596),
(4, 1035, 2.28),
(10, 1035, 2.28),
(11, 1035, 2.28),
(12, 1035, 2.28),
(13, 1035, 20.52),
(4, 1036, 0.15996),
(10, 1036, 0.15996),
(11, 1036, 0.15996),
(12, 1036, 0.15996),
(13, 1036, 1.75956),
(4, 1037, 1.68),
(10, 1037, 1.68),
(11, 1037, 1.68),
(12, 1037, 1.68),
(13, 1037, 18.48),
(4, 1038, 1.88004),
(10, 1038, 1.88004),
(11, 1038, 1.88004),
(12, 1038, 1.88004),
(13, 1038, 20.6804),
(4, 1128, 0.87996),
(10, 1128, 0.87996),
(11, 1128, 0.87996),
(12, 1128, 0.87996),
(13, 1128, 9.67956),
(4, 1129, 1.92),
(10, 1129, 1.92),
(11, 1129, 1.92),
(12, 1129, 1.92),
(13, 1129, 21.12),
(4, 1132, 0.48),
(10, 1132, 0.48),
(11, 1132, 0.48),
(12, 1132, 0.48),
(13, 1132, 4.8),
(4, 1133, 1.52004),
(10, 1133, 1.52004),
(11, 1133, 1.52004),
(12, 1133, 1.52004),
(13, 1133, 16.7204),
(4, 1134, 1.64004),
(10, 1134, 1.64004),
(11, 1134, 1.64004),
(12, 1134, 1.64004),
(13, 1134, 18.0404),
(4, 1137, 1.64004),
(10, 1137, 1.64004),
(11, 1137, 1.64004),
(12, 1137, 1.64004),
(13, 1137, 13.1203),
(4, 1138, 2.00004),
(10, 1138, 2.00004),
(11, 1138, 2.00004),
(12, 1138, 2.00004),
(13, 1138, 16.0003),
(4, 1139, 0.48),
(10, 1139, 0.48),
(11, 1139, 0.48),
(12, 1139, 0.48),
(13, 1139, 5.28),
(4, 1144, 0.24),
(10, 1144, 0.24),
(11, 1144, 0.24),
(12, 1144, 0.24),
(13, 1144, 2.16),
(4, 1145, 1.52004),
(10, 1145, 1.52004),
(11, 1145, 1.52004),
(12, 1145, 1.52004),
(13, 1145, 13.6804),
(4, 1146, 2.00004),
(10, 1146, 2.00004),
(11, 1146, 2.00004),
(12, 1146, 2.00004),
(13, 1146, 18.0004),
(13, 1685, 8.64),
(13, 1686, 6.72012),
(13, 1687, 1.52004),
(13, 1688, 1.71996),
(13, 1689, 6.72),
(13, 1690, 7.68),
(13, 1691, 5.28012),
(13, 1692, 5.64012),
(13, 1693, 1.4666),
(13, 1694, 3.4666);

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_finder_links_terms1`
--

CREATE TABLE IF NOT EXISTS `sdc98_finder_links_terms1` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sdc98_finder_links_terms1`
--

INSERT INTO `sdc98_finder_links_terms1` (`link_id`, `term_id`, `weight`) VALUES
(13, 1744, 0.39996),
(13, 1745, 1.59996),
(13, 1746, 2.04);

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_finder_links_terms2`
--

CREATE TABLE IF NOT EXISTS `sdc98_finder_links_terms2` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sdc98_finder_links_terms2`
--

INSERT INTO `sdc98_finder_links_terms2` (`link_id`, `term_id`, `weight`) VALUES
(4, 1079, 0.39996),
(10, 1079, 0.39996),
(11, 1079, 0.39996),
(12, 1079, 0.39996),
(13, 1079, 3.59964),
(4, 1080, 1.64004),
(10, 1080, 1.64004),
(11, 1080, 1.64004),
(12, 1080, 1.64004),
(13, 1080, 14.7604),
(4, 1081, 1.88004),
(10, 1081, 1.88004),
(11, 1081, 1.88004),
(12, 1081, 1.88004),
(13, 1081, 16.9204),
(4, 1301, 0.87996),
(10, 1301, 0.87996),
(11, 1301, 0.87996),
(12, 1301, 0.87996),
(4, 1302, 1.8),
(10, 1302, 1.8),
(11, 1302, 1.8),
(12, 1302, 1.8),
(4, 1303, 2.04),
(10, 1303, 2.04),
(11, 1303, 2.04),
(12, 1303, 2.04),
(4, 1304, 0.63996),
(10, 1304, 0.63996),
(11, 1304, 0.63996),
(12, 1304, 0.63996),
(4, 1305, 1.88004),
(10, 1305, 1.88004),
(11, 1305, 1.88004),
(12, 1305, 1.88004),
(4, 1306, 2.19996),
(10, 1306, 2.19996),
(11, 1306, 2.19996),
(12, 1306, 2.19996),
(4, 1325, 0.63996),
(10, 1325, 0.63996),
(11, 1325, 0.63996),
(12, 1325, 0.63996),
(4, 1326, 1.95996),
(10, 1326, 1.95996),
(11, 1326, 1.95996),
(12, 1326, 1.95996),
(13, 1664, 6.16044),
(13, 1665, 18.48),
(13, 1666, 20.2396),
(13, 1667, 3.84),
(13, 1668, 12.48),
(13, 1669, 15.36),
(13, 1703, 0.24),
(13, 1704, 1.8),
(13, 1705, 2.4),
(13, 1706, 1.44),
(13, 1707, 5.15988),
(13, 1708, 7.2),
(13, 1815, 0.87996),
(13, 1816, 2.28),
(13, 1817, 2.36004),
(13, 1818, 0.63996),
(13, 1819, 1.83996),
(13, 1820, 2.16);

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_finder_links_terms3`
--

CREATE TABLE IF NOT EXISTS `sdc98_finder_links_terms3` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_finder_links_terms4`
--

CREATE TABLE IF NOT EXISTS `sdc98_finder_links_terms4` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sdc98_finder_links_terms4`
--

INSERT INTO `sdc98_finder_links_terms4` (`link_id`, `term_id`, `weight`) VALUES
(4, 1039, 0.87996),
(10, 1039, 0.87996),
(11, 1039, 0.87996),
(12, 1039, 0.87996),
(13, 1039, 7.91964),
(4, 1040, 2.07996),
(10, 1040, 2.07996),
(11, 1040, 2.07996),
(12, 1040, 2.07996),
(13, 1040, 18.7196),
(4, 1041, 2.28),
(10, 1041, 2.28),
(11, 1041, 2.28),
(12, 1041, 2.28),
(13, 1041, 20.52),
(13, 1697, 0.56004),
(13, 1698, 1.71996),
(13, 1699, 2.04),
(13, 1718, 0.08004),
(13, 1719, 1.68),
(13, 1720, 2.04);

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_finder_links_terms5`
--

CREATE TABLE IF NOT EXISTS `sdc98_finder_links_terms5` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sdc98_finder_links_terms5`
--

INSERT INTO `sdc98_finder_links_terms5` (`link_id`, `term_id`, `weight`) VALUES
(4, 1319, 0.80004),
(10, 1319, 0.80004),
(11, 1319, 0.80004),
(12, 1319, 0.80004),
(13, 1721, 1.91988),
(13, 1722, 5.51988),
(13, 1723, 6.36012),
(13, 1724, 1.44),
(13, 1725, 3.36),
(13, 1726, 3.91992),
(13, 1727, 1.68012),
(13, 1728, 5.28012),
(13, 1729, 6.23988),
(13, 1730, 0.63996),
(13, 1731, 1.76004),
(13, 1732, 2.04),
(13, 1733, 1.68012),
(13, 1734, 5.4),
(13, 1735, 6.23988),
(13, 1736, 1.44),
(13, 1737, 6.36012),
(13, 1738, 6.95988),
(13, 1739, 0.48),
(13, 1740, 1.8),
(13, 1741, 2.12004),
(13, 1742, 0.56004),
(13, 1743, 1.83996);

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_finder_links_terms6`
--

CREATE TABLE IF NOT EXISTS `sdc98_finder_links_terms6` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sdc98_finder_links_terms6`
--

INSERT INTO `sdc98_finder_links_terms6` (`link_id`, `term_id`, `weight`) VALUES
(4, 1085, 0.48),
(10, 1085, 0.48),
(11, 1085, 0.48),
(12, 1085, 0.48),
(13, 1085, 5.28),
(4, 1086, 1.76004),
(10, 1086, 1.76004),
(11, 1086, 1.76004),
(12, 1086, 1.76004),
(13, 1086, 19.3604),
(4, 1087, 2.12004),
(10, 1087, 2.12004),
(11, 1087, 2.12004),
(12, 1087, 2.12004),
(13, 1087, 23.3204),
(4, 1088, 0.63996),
(10, 1088, 0.63996),
(11, 1088, 0.63996),
(12, 1088, 0.63996),
(13, 1088, 5.11968),
(4, 1307, 0.48),
(10, 1307, 0.48),
(11, 1307, 0.48),
(12, 1307, 0.48),
(4, 1308, 1.56),
(10, 1308, 1.56),
(11, 1308, 1.56),
(12, 1308, 1.56),
(4, 1309, 1.76004),
(10, 1309, 1.76004),
(11, 1309, 1.76004),
(12, 1309, 1.76004),
(4, 1310, 1.88004),
(10, 1310, 1.88004),
(11, 1310, 1.88004),
(12, 1310, 1.88004),
(4, 1311, 2.24004),
(10, 1311, 2.24004),
(11, 1311, 2.24004),
(12, 1311, 2.24004),
(13, 1670, 4.39956),
(13, 1671, 16.7204),
(13, 1672, 18.9196),
(13, 1673, 14.4),
(13, 1674, 15.36);

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_finder_links_terms7`
--

CREATE TABLE IF NOT EXISTS `sdc98_finder_links_terms7` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sdc98_finder_links_terms7`
--

INSERT INTO `sdc98_finder_links_terms7` (`link_id`, `term_id`, `weight`) VALUES
(4, 1091, 0.39996),
(10, 1091, 0.39996),
(11, 1091, 0.39996),
(12, 1091, 0.39996),
(13, 1091, 4.39956),
(4, 1092, 1.52004),
(10, 1092, 1.52004),
(11, 1092, 1.52004),
(12, 1092, 1.52004),
(13, 1092, 16.7204),
(4, 1093, 1.92),
(10, 1093, 1.92),
(11, 1093, 1.92),
(12, 1093, 1.92),
(13, 1093, 21.12),
(4, 1094, 0.32004),
(10, 1094, 0.32004),
(11, 1094, 0.32004),
(12, 1094, 0.32004),
(13, 1094, 3.52044),
(4, 1095, 1.68),
(10, 1095, 1.68),
(11, 1095, 1.68),
(12, 1095, 1.68),
(13, 1095, 18.48),
(4, 1125, 0.56004),
(10, 1125, 0.56004),
(11, 1125, 0.56004),
(12, 1125, 0.56004),
(13, 1125, 6.16044),
(4, 1126, 1.64004),
(10, 1126, 1.64004),
(11, 1126, 1.64004),
(12, 1126, 1.64004),
(13, 1126, 18.0404),
(4, 1127, 1.83996),
(10, 1127, 1.83996),
(11, 1127, 1.83996),
(12, 1127, 1.83996),
(13, 1127, 20.2396),
(4, 1152, 0.15996),
(10, 1152, 0.15996),
(11, 1152, 0.15996),
(12, 1152, 0.15996),
(13, 1152, 3.1992),
(4, 1153, 1.47996),
(10, 1153, 1.47996),
(11, 1153, 1.47996),
(12, 1153, 1.47996),
(13, 1153, 16.2796),
(4, 1154, 1.8),
(10, 1154, 1.8),
(11, 1154, 1.8),
(12, 1154, 1.8),
(13, 1154, 19.8),
(4, 1312, 1.95996),
(10, 1312, 1.95996),
(11, 1312, 1.95996),
(12, 1312, 1.95996),
(4, 1328, 0.68),
(10, 1328, 0.68),
(11, 1328, 0.68),
(12, 1328, 0.68),
(10, 1642, 2.15339),
(11, 1649, 2.15339),
(12, 1656, 2.15339),
(13, 1675, 21.12),
(13, 1695, 13.1203),
(13, 1696, 15.6797),
(13, 1756, 0.39996),
(13, 1757, 1.71996),
(13, 1758, 2.07996),
(13, 1759, 2.88),
(13, 1760, 6.12),
(13, 1761, 7.08012),
(13, 1762, 1.44),
(13, 1763, 5.28012),
(13, 1764, 6.23988),
(13, 1765, 0.56004),
(13, 1766, 1.8),
(13, 1767, 2.04),
(13, 1768, 0.63996),
(13, 1769, 1.2),
(13, 1770, 1.88004),
(13, 1771, 2.31996),
(13, 1772, 1.68012),
(13, 1773, 5.28012),
(13, 1774, 4.00008),
(13, 1775, 0.48),
(13, 1776, 1.68),
(13, 1777, 2.19996),
(13, 1778, 1.75992),
(13, 1779, 4.32),
(13, 1780, 4.8),
(13, 1781, 0.56004),
(13, 1782, 0.72),
(13, 1783, 1.8),
(13, 1784, 2.04),
(13, 1785, 0.72),
(13, 1786, 1.02);

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_finder_links_terms8`
--

CREATE TABLE IF NOT EXISTS `sdc98_finder_links_terms8` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sdc98_finder_links_terms8`
--

INSERT INTO `sdc98_finder_links_terms8` (`link_id`, `term_id`, `weight`) VALUES
(4, 1042, 0.39996),
(10, 1042, 0.39996),
(11, 1042, 0.39996),
(12, 1042, 0.39996),
(13, 1042, 3.59964),
(4, 1043, 1.56),
(10, 1043, 1.56),
(11, 1043, 1.56),
(12, 1043, 1.56),
(13, 1043, 14.04),
(4, 1044, 1.76004),
(10, 1044, 1.76004),
(11, 1044, 1.76004),
(12, 1044, 1.76004),
(13, 1044, 15.8404),
(4, 1065, 0.56004),
(10, 1065, 0.56004),
(11, 1065, 0.56004),
(12, 1065, 0.56004),
(13, 1065, 6.16044),
(4, 1068, 0.79992),
(10, 1068, 0.79992),
(11, 1068, 0.79992),
(12, 1068, 0.79992),
(13, 1068, 7.9992),
(4, 1069, 1.64004),
(10, 1069, 1.64004),
(11, 1069, 1.64004),
(12, 1069, 1.64004),
(13, 1069, 14.7604),
(4, 1070, 1.8),
(10, 1070, 1.8),
(11, 1070, 1.8),
(12, 1070, 1.8),
(13, 1070, 16.2),
(4, 1071, 1.64004),
(10, 1071, 1.64004),
(11, 1071, 1.64004),
(12, 1071, 1.64004),
(13, 1071, 18.0404),
(4, 1107, 0.63996),
(10, 1107, 0.63996),
(11, 1107, 0.63996),
(12, 1107, 0.63996),
(13, 1107, 7.03956),
(4, 1108, 1.76004),
(10, 1108, 1.76004),
(11, 1108, 1.76004),
(12, 1108, 1.76004),
(13, 1108, 19.3604),
(4, 1109, 2.00004),
(10, 1109, 2.00004),
(11, 1109, 2.00004),
(12, 1109, 2.00004),
(13, 1109, 22.0004),
(4, 1110, 0.72),
(10, 1110, 0.72),
(11, 1110, 0.72),
(12, 1110, 0.72),
(13, 1110, 7.92),
(4, 1111, 1.76004),
(10, 1111, 1.76004),
(11, 1111, 1.76004),
(12, 1111, 1.76004),
(13, 1111, 19.3604),
(4, 1112, 2.07996),
(10, 1112, 2.07996),
(11, 1112, 2.07996),
(12, 1112, 2.07996),
(13, 1112, 22.8796),
(4, 1116, 1.12008),
(10, 1116, 1.12008),
(11, 1116, 1.12008),
(12, 1116, 1.12008),
(13, 1116, 10.6408),
(4, 1117, 1.83996),
(10, 1117, 1.83996),
(11, 1117, 1.83996),
(12, 1117, 1.83996),
(13, 1117, 14.7197),
(4, 1119, 1.83996),
(10, 1119, 1.83996),
(11, 1119, 1.83996),
(12, 1119, 1.83996),
(13, 1119, 20.2396),
(4, 1120, 2.07996),
(10, 1120, 2.07996),
(11, 1120, 2.07996),
(12, 1120, 2.07996),
(13, 1120, 22.8796),
(4, 1122, 0.39996),
(10, 1122, 0.39996),
(11, 1122, 0.39996),
(12, 1122, 0.39996),
(13, 1122, 4.39956),
(4, 1297, 1.76004),
(10, 1297, 1.76004),
(11, 1297, 1.76004),
(12, 1297, 1.76004),
(4, 1298, 1.88004),
(10, 1298, 1.88004),
(11, 1298, 1.88004),
(12, 1298, 1.88004),
(4, 1299, 0.6666),
(10, 1299, 0.6666),
(11, 1299, 0.6666),
(12, 1299, 0.6666),
(4, 1300, 2.12004),
(10, 1300, 2.12004),
(11, 1300, 2.12004),
(12, 1300, 2.12004),
(4, 1313, 2.19996),
(10, 1313, 2.19996),
(11, 1313, 2.19996),
(12, 1313, 2.19996),
(4, 1314, 1.88004),
(10, 1314, 1.88004),
(11, 1314, 1.88004),
(12, 1314, 1.88004),
(4, 1315, 2.04),
(10, 1315, 2.04),
(11, 1315, 2.04),
(12, 1315, 2.04),
(4, 1316, 0.8),
(10, 1316, 0.8),
(11, 1316, 0.8),
(12, 1316, 0.8),
(10, 1639, 2.5334),
(11, 1646, 2.5334),
(12, 1653, 2.5334),
(13, 1661, 18.9196),
(13, 1662, 20.2396),
(13, 1663, 21.5596),
(13, 1678, 0.32004),
(13, 1679, 1.56),
(13, 1680, 1.71996),
(13, 1681, 16.9603),
(13, 1682, 1.3334),
(13, 1683, 18.9196),
(13, 1684, 21.12);

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_finder_links_terms9`
--

CREATE TABLE IF NOT EXISTS `sdc98_finder_links_terms9` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sdc98_finder_links_terms9`
--

INSERT INTO `sdc98_finder_links_terms9` (`link_id`, `term_id`, `weight`) VALUES
(4, 1157, 0.72),
(10, 1157, 0.72),
(11, 1157, 0.72),
(12, 1157, 0.72),
(13, 1157, 7.92),
(4, 1158, 1.83996),
(10, 1158, 1.83996),
(11, 1158, 1.83996),
(12, 1158, 1.83996),
(13, 1158, 20.2396),
(4, 1159, 2.16),
(10, 1159, 2.16),
(11, 1159, 2.16),
(12, 1159, 2.16),
(13, 1159, 23.76),
(4, 1160, 0.39996),
(10, 1160, 0.39996),
(11, 1160, 0.39996),
(12, 1160, 0.39996),
(13, 1160, 4.79952),
(4, 1161, 1.8),
(10, 1161, 1.8),
(11, 1161, 1.8),
(12, 1161, 1.8),
(13, 1161, 21.6),
(4, 1162, 2.07996),
(10, 1162, 2.07996),
(11, 1162, 2.07996),
(12, 1162, 2.07996),
(13, 1162, 24.9595),
(4, 1163, 0.56004),
(10, 1163, 0.56004),
(11, 1163, 0.56004),
(12, 1163, 0.56004),
(13, 1163, 6.16044),
(4, 1164, 1.59996),
(10, 1164, 1.59996),
(11, 1164, 1.59996),
(12, 1164, 1.59996),
(13, 1164, 17.5996),
(4, 1165, 2.00004),
(10, 1165, 2.00004),
(11, 1165, 2.00004),
(12, 1165, 2.00004),
(13, 1165, 22.0004),
(4, 1166, 0.56004),
(10, 1166, 0.56004),
(11, 1166, 0.56004),
(12, 1166, 0.56004),
(13, 1166, 6.72048),
(4, 1167, 1.59996),
(10, 1167, 1.59996),
(11, 1167, 1.59996),
(12, 1167, 1.59996),
(13, 1167, 19.1995),
(4, 1168, 1.8),
(10, 1168, 1.8),
(11, 1168, 1.8),
(12, 1168, 1.8),
(13, 1168, 19.8),
(4, 1169, 0.63996),
(10, 1169, 0.63996),
(11, 1169, 0.63996),
(12, 1169, 0.63996),
(13, 1169, 5.11968),
(4, 1170, 1.83996),
(10, 1170, 1.83996),
(11, 1170, 1.83996),
(12, 1170, 1.83996),
(13, 1170, 14.7197),
(4, 1171, 1.95996),
(10, 1171, 1.95996),
(11, 1171, 1.95996),
(12, 1171, 1.95996),
(13, 1171, 15.6797),
(4, 1317, 0.6666),
(10, 1317, 0.6666),
(11, 1317, 0.6666),
(12, 1317, 0.6666),
(4, 1318, 2.8),
(10, 1318, 2.8),
(11, 1318, 2.8),
(12, 1318, 2.8),
(4, 1322, 0.87996),
(10, 1322, 0.87996),
(11, 1322, 0.87996),
(12, 1322, 0.87996),
(4, 1323, 2.00004),
(10, 1323, 2.00004),
(11, 1323, 2.00004),
(12, 1323, 2.00004),
(4, 1324, 2.4),
(10, 1324, 2.4),
(11, 1324, 2.4),
(12, 1324, 2.4),
(4, 1327, 0.39996),
(10, 1327, 0.39996),
(11, 1327, 0.39996),
(12, 1327, 0.39996),
(10, 1640, 2.9334),
(11, 1647, 2.9334),
(12, 1654, 2.9334),
(13, 1750, 0.48),
(13, 1751, 1.76004),
(13, 1752, 1.92),
(13, 1753, 0.48),
(13, 1754, 1.64004),
(13, 1755, 1.83996),
(13, 1794, 0.32004),
(13, 1795, 1.68),
(13, 1796, 1.8),
(13, 1797, 0.32004),
(13, 1798, 1.56),
(13, 1799, 1.88004),
(13, 1800, 0.87996),
(13, 1801, 2.04),
(13, 1802, 1.13339),
(13, 1803, 2.83339),
(13, 1804, 0.80004),
(13, 1805, 2.00004),
(13, 1806, 2.24004),
(13, 1807, 0.80004),
(13, 1808, 1.95996),
(13, 1809, 2.19996),
(13, 1810, 0.96012),
(13, 1811, 1.64004),
(13, 1812, 1.88004),
(13, 1813, 3.67992),
(13, 1814, 4.72008);

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_finder_links_termsa`
--

CREATE TABLE IF NOT EXISTS `sdc98_finder_links_termsa` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sdc98_finder_links_termsa`
--

INSERT INTO `sdc98_finder_links_termsa` (`link_id`, `term_id`, `weight`) VALUES
(12, 1652, 0.54);

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_finder_links_termsb`
--

CREATE TABLE IF NOT EXISTS `sdc98_finder_links_termsb` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sdc98_finder_links_termsb`
--

INSERT INTO `sdc98_finder_links_termsb` (`link_id`, `term_id`, `weight`) VALUES
(4, 1320, 0.45339),
(10, 1320, 0.45339),
(11, 1320, 0.45339),
(12, 1320, 0.45339),
(4, 1321, 2.32339),
(10, 1321, 2.32339),
(11, 1321, 2.32339),
(12, 1321, 2.32339),
(10, 1641, 2.43661),
(11, 1648, 2.43661),
(12, 1655, 2.43661),
(13, 1700, 0.32004),
(13, 1701, 1.8),
(13, 1702, 2.19996);

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_finder_links_termsc`
--

CREATE TABLE IF NOT EXISTS `sdc98_finder_links_termsc` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sdc98_finder_links_termsc`
--

INSERT INTO `sdc98_finder_links_termsc` (`link_id`, `term_id`, `weight`) VALUES
(4, 1296, 0.17),
(10, 1296, 0.37),
(13, 1659, 0.17);

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_finder_links_termsd`
--

CREATE TABLE IF NOT EXISTS `sdc98_finder_links_termsd` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sdc98_finder_links_termsd`
--

INSERT INTO `sdc98_finder_links_termsd` (`link_id`, `term_id`, `weight`) VALUES
(4, 1097, 0.32004),
(10, 1097, 0.32004),
(11, 1097, 0.32004),
(12, 1097, 0.32004),
(13, 1097, 3.52044),
(4, 1098, 1.68),
(10, 1098, 1.68),
(11, 1098, 1.68),
(12, 1098, 1.68),
(13, 1098, 18.48),
(4, 1099, 1.83996),
(10, 1099, 1.83996),
(11, 1099, 1.83996),
(12, 1099, 1.83996),
(13, 1099, 20.2396),
(4, 1100, 0.64008),
(10, 1100, 0.64008),
(11, 1100, 0.64008),
(12, 1100, 0.64008),
(13, 1100, 10.8814),
(4, 1103, 1.47996),
(10, 1103, 1.47996),
(11, 1103, 1.47996),
(12, 1103, 1.47996),
(13, 1103, 16.2796),
(4, 1104, 1.68),
(10, 1104, 1.68),
(11, 1104, 1.68),
(12, 1104, 1.68),
(13, 1104, 18.48),
(4, 1105, 1.83996),
(10, 1105, 1.83996),
(11, 1105, 1.83996),
(12, 1105, 1.83996),
(13, 1105, 20.2396),
(4, 1106, 2.12004),
(10, 1106, 2.12004),
(11, 1106, 2.12004),
(12, 1106, 2.12004),
(13, 1106, 23.3204),
(13, 1676, 18.2405),
(13, 1677, 21.1205),
(13, 1709, 0.39996),
(13, 1710, 1.92),
(13, 1711, 2.28),
(13, 1747, 0.15996),
(13, 1748, 1.76004),
(13, 1749, 2.16);

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_finder_links_termse`
--

CREATE TABLE IF NOT EXISTS `sdc98_finder_links_termse` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sdc98_finder_links_termse`
--

INSERT INTO `sdc98_finder_links_termse` (`link_id`, `term_id`, `weight`) VALUES
(4, 1045, 1.44),
(10, 1045, 1.44),
(11, 1045, 1.44),
(12, 1045, 1.44),
(13, 1045, 16.56),
(4, 1046, 1.88004),
(10, 1046, 1.88004),
(11, 1046, 1.88004),
(12, 1046, 1.88004),
(13, 1046, 20.6804),
(4, 1047, 2.12004),
(10, 1047, 2.12004),
(11, 1047, 2.12004),
(12, 1047, 2.12004),
(13, 1047, 23.3204),
(4, 1048, 1.83996),
(10, 1048, 1.83996),
(11, 1048, 1.83996),
(12, 1048, 1.83996),
(13, 1048, 22.0795),
(4, 1049, 2.16),
(10, 1049, 2.16),
(11, 1049, 2.16),
(12, 1049, 2.16),
(13, 1049, 25.92),
(4, 1050, 0.32004),
(10, 1050, 0.32004),
(11, 1050, 0.32004),
(12, 1050, 0.32004),
(13, 1050, 2.88036),
(4, 1051, 1.52004),
(10, 1051, 1.52004),
(11, 1051, 1.52004),
(12, 1051, 1.52004),
(13, 1051, 13.6804),
(4, 1053, 1.83996),
(10, 1053, 1.83996),
(11, 1053, 1.83996),
(12, 1053, 1.83996),
(13, 1053, 14.7197),
(4, 1054, 0.32004),
(10, 1054, 0.32004),
(11, 1054, 0.32004),
(12, 1054, 0.32004),
(13, 1054, 3.52044),
(4, 1055, 1.76004),
(10, 1055, 1.76004),
(11, 1055, 1.76004),
(12, 1055, 1.76004),
(13, 1055, 19.3604),
(4, 1056, 2.07996),
(10, 1056, 2.07996),
(11, 1056, 2.07996),
(12, 1056, 2.07996),
(13, 1056, 22.8796),
(4, 1057, 0.24),
(10, 1057, 0.24),
(11, 1057, 0.24),
(12, 1057, 0.24),
(13, 1057, 2.88),
(4, 1058, 1.56),
(10, 1058, 1.56),
(11, 1058, 1.56),
(12, 1058, 1.56),
(13, 1058, 18.72),
(4, 1059, 1.95996),
(10, 1059, 1.95996),
(11, 1059, 1.95996),
(12, 1059, 1.95996),
(13, 1059, 23.5195),
(4, 1060, 0.31992),
(10, 1060, 0.31992),
(11, 1060, 0.31992),
(12, 1060, 0.31992),
(13, 1060, 3.51912),
(4, 1061, 1.47996),
(10, 1061, 1.47996),
(11, 1061, 1.47996),
(12, 1061, 1.47996),
(13, 1061, 16.2796),
(4, 1062, 1.95996),
(10, 1062, 1.95996),
(11, 1062, 1.95996),
(12, 1062, 1.95996),
(13, 1062, 21.5596),
(4, 1063, 1.68),
(10, 1063, 1.68),
(11, 1063, 1.68),
(12, 1063, 1.68),
(13, 1063, 18.48),
(4, 1064, 1.95996),
(10, 1064, 1.95996),
(11, 1064, 1.95996),
(12, 1064, 1.95996),
(13, 1064, 21.5596),
(4, 1149, 0.48),
(10, 1149, 0.48),
(11, 1149, 0.48),
(12, 1149, 0.48),
(13, 1149, 5.76),
(4, 1150, 1.76004),
(10, 1150, 1.76004),
(11, 1150, 1.76004),
(12, 1150, 1.76004),
(13, 1150, 21.1205),
(4, 1151, 1.88004),
(10, 1151, 1.88004),
(11, 1151, 1.88004),
(12, 1151, 1.88004),
(13, 1151, 22.5605),
(10, 1638, 0.17),
(11, 1638, 0.37),
(11, 1645, 0.17),
(13, 1660, 1.71996),
(13, 1712, 0.56004),
(13, 1713, 1.59996),
(13, 1714, 2.07996),
(13, 1715, 1.19988),
(13, 1716, 5.04),
(13, 1717, 5.87988),
(13, 1787, 3.6),
(13, 1788, 6.12),
(13, 1789, 2.31996),
(13, 1790, 4.8),
(13, 1791, 0.56004),
(13, 1792, 1.64004),
(13, 1793, 2.12004);

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_finder_links_termsf`
--

CREATE TABLE IF NOT EXISTS `sdc98_finder_links_termsf` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_finder_taxonomy`
--

CREATE TABLE IF NOT EXISTS `sdc98_finder_taxonomy` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `state` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `access` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ordering` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  KEY `state` (`state`),
  KEY `ordering` (`ordering`),
  KEY `access` (`access`),
  KEY `idx_parent_published` (`parent_id`,`state`,`access`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Дамп данных таблицы `sdc98_finder_taxonomy`
--

INSERT INTO `sdc98_finder_taxonomy` (`id`, `parent_id`, `title`, `state`, `access`, `ordering`) VALUES
(1, 0, 'ROOT', 0, 0, 0),
(2, 1, 'Type', 1, 1, 0),
(6, 2, 'Отзыв', 1, 1, 0),
(8, 2, 'Продукт', 1, 1, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_finder_taxonomy_map`
--

CREATE TABLE IF NOT EXISTS `sdc98_finder_taxonomy_map` (
  `link_id` int(10) unsigned NOT NULL,
  `node_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`node_id`),
  KEY `link_id` (`link_id`),
  KEY `node_id` (`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sdc98_finder_taxonomy_map`
--

INSERT INTO `sdc98_finder_taxonomy_map` (`link_id`, `node_id`) VALUES
(4, 6),
(10, 6),
(11, 6),
(12, 6),
(13, 8);

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_finder_terms`
--

CREATE TABLE IF NOT EXISTS `sdc98_finder_terms` (
  `term_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `term` varchar(75) NOT NULL,
  `stem` varchar(75) NOT NULL,
  `common` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `phrase` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` float unsigned NOT NULL DEFAULT '0',
  `soundex` varchar(75) NOT NULL,
  `links` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `idx_term` (`term`),
  KEY `idx_term_phrase` (`term`,`phrase`),
  KEY `idx_stem_phrase` (`stem`,`phrase`),
  KEY `idx_soundex_phrase` (`soundex`,`phrase`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1821 ;

--
-- Дамп данных таблицы `sdc98_finder_terms`
--

INSERT INTO `sdc98_finder_terms` (`term_id`, `term`, `stem`, `common`, `phrase`, `weight`, `soundex`, `links`) VALUES
(1024, 'ac', 'ac', 0, 0, 0.1333, 'A200', 5),
(1025, 'ac eros', 'ac eros', 0, 1, 1.2333, 'A262', 5),
(1026, 'ac eros elementum', 'ac eros elementum', 0, 1, 1.5667, 'A2624535', 5),
(1027, 'adipiscing', 'adipiscing', 0, 0, 0.6667, 'A31252', 5),
(1028, 'adipiscing elit', 'adipiscing elit', 0, 1, 1.5, 'A3125243', 5),
(1029, 'adipiscing elit sed', 'adipiscing elit sed', 0, 1, 1.6333, 'A312524323', 5),
(1030, 'aliquet', 'aliquet', 0, 0, 0.4667, 'A423', 5),
(1031, 'aliquet nulla', 'aliquet nulla', 0, 1, 1.4333, 'A42354', 5),
(1032, 'aliquet nulla at', 'aliquet nulla at', 0, 1, 1.5333, 'A423543', 5),
(1033, 'amet', 'amet', 0, 0, 0.2667, 'A530', 5),
(1034, 'amet consectetur', 'amet consectetur', 0, 1, 1.5333, 'A5325236', 5),
(1035, 'amet consectetur adipiscing', 'amet consectetur adipiscing', 0, 1, 1.9, 'A532523631252', 5),
(1036, 'at', 'at', 0, 0, 0.1333, 'A300', 5),
(1037, 'at porttitor', 'at porttitor', 0, 1, 1.4, 'A31636', 5),
(1038, 'at porttitor odio', 'at porttitor odio', 0, 1, 1.5667, 'A316363', 5),
(1039, 'consectetur', 'consectetur', 0, 0, 0.7333, 'C5236', 5),
(1040, 'consectetur adipiscing', 'consectetur adipiscing', 0, 1, 1.7333, 'C523631252', 5),
(1041, 'consectetur adipiscing elit', 'consectetur adipiscing elit', 0, 1, 1.9, 'C52363125243', 5),
(1042, 'dolor', 'dolor', 0, 0, 0.3333, 'D460', 5),
(1043, 'dolor sit', 'dolor sit', 0, 1, 1.3, 'D4623', 5),
(1044, 'dolor sit amet', 'dolor sit amet', 0, 1, 1.4667, 'D462353', 5),
(1045, 'elementum', 'elementum', 0, 0, 0.6, 'E4535', 5),
(1046, 'elementum aliquet', 'elementum aliquet', 0, 1, 1.5667, 'E4535423', 5),
(1047, 'elementum aliquet nulla', 'elementum aliquet nulla', 0, 1, 1.7667, 'E453542354', 5),
(1048, 'elementum tellus', 'elementum tellus', 0, 1, 1.5333, 'E4535342', 5),
(1049, 'elementum tellus viverra', 'elementum tellus viverra', 0, 1, 1.8, 'E453534216', 5),
(1050, 'elit', 'elit', 0, 0, 0.2667, 'E430', 5),
(1051, 'elit sed', 'elit sed', 0, 1, 1.2667, 'E4323', 5),
(1053, 'elit sed posuere', 'elit sed posuere', 0, 1, 1.5333, 'E4323126', 5),
(1054, 'eros', 'eros', 0, 0, 0.2667, 'E620', 5),
(1055, 'eros elementum', 'eros elementum', 0, 1, 1.4667, 'E624535', 5),
(1056, 'eros elementum aliquet', 'eros elementum aliquet', 0, 1, 1.7333, 'E624535423', 5),
(1057, 'est', 'est', 0, 0, 0.2, 'E230', 5),
(1058, 'est vitae', 'est vitae', 0, 1, 1.3, 'E2313', 5),
(1059, 'est vitae elementum', 'est vitae elementum', 0, 1, 1.6333, 'E23134535', 5),
(1060, 'et', 'et', 0, 0, 0.1333, 'E300', 5),
(1061, 'et orci', 'et orci', 0, 1, 1.2333, 'E362', 5),
(1062, 'et orci scelerisque', 'et orci scelerisque', 0, 1, 1.6333, 'E362462', 5),
(1063, 'et venenatis', 'et venenatis', 0, 1, 1.4, 'E31532', 5),
(1064, 'et venenatis mauris', 'et venenatis mauris', 0, 1, 1.6333, 'E31532562', 5),
(1065, 'feugiat', 'feugiat', 0, 0, 0.4667, 'F230', 5),
(1068, 'ipsum', 'ipsum', 0, 0, 0.3333, 'I125', 5),
(1069, 'ipsum dolor', 'ipsum dolor', 0, 1, 1.3667, 'I125346', 5),
(1070, 'ipsum dolor sit', 'ipsum dolor sit', 0, 1, 1.5, 'I12534623', 5),
(1071, 'ipsum proin', 'ipsum proin', 0, 1, 1.3667, 'I125165', 5),
(1079, 'lorem', 'lorem', 0, 0, 0.3333, 'L650', 5),
(1080, 'lorem ipsum', 'lorem ipsum', 0, 1, 1.3667, 'L65125', 5),
(1081, 'lorem ipsum dolor', 'lorem ipsum dolor', 0, 1, 1.5667, 'L65125346', 5),
(1085, 'mauris', 'mauris', 0, 0, 0.4, 'M620', 5),
(1086, 'mauris posuere', 'mauris posuere', 0, 1, 1.4667, 'M62126', 5),
(1087, 'mauris posuere placerat', 'mauris posuere placerat', 0, 1, 1.7667, 'M6212614263', 5),
(1088, 'molestie', 'molestie', 0, 0, 0.5333, 'M423', 5),
(1091, 'nulla', 'nulla', 0, 0, 0.3333, 'N400', 5),
(1092, 'nulla at', 'nulla at', 0, 1, 1.2667, 'N430', 5),
(1093, 'nulla at porttitor', 'nulla at porttitor', 0, 1, 1.6, 'N431636', 5),
(1094, 'nunc', 'nunc', 0, 0, 0.2667, 'N200', 5),
(1095, 'nunc feugiat', 'nunc feugiat', 0, 1, 1.4, 'N2123', 5),
(1097, 'odio', 'odio', 0, 0, 0.2667, 'O300', 5),
(1098, 'odio quisque', 'odio quisque', 0, 1, 1.4, 'O320', 5),
(1099, 'odio quisque sed', 'odio quisque sed', 0, 1, 1.5333, 'O323', 5),
(1100, 'orci', 'orci', 0, 0, 0.2667, 'O620', 5),
(1103, 'orci et', 'orci et', 0, 1, 1.2333, 'O623', 5),
(1104, 'orci et orci', 'orci et orci', 0, 1, 1.4, 'O62362', 5),
(1105, 'orci scelerisque', 'orci scelerisque', 0, 1, 1.5333, 'O62462', 5),
(1106, 'orci scelerisque semper', 'orci scelerisque semper', 0, 1, 1.7667, 'O62462516', 5),
(1107, 'placerat', 'placerat', 0, 0, 0.5333, 'P4263', 5),
(1108, 'placerat ipsum', 'placerat ipsum', 0, 1, 1.4667, 'P4263125', 5),
(1109, 'placerat ipsum proin', 'placerat ipsum proin', 0, 1, 1.6667, 'P4263125165', 5),
(1110, 'porttitor', 'porttitor', 0, 0, 0.6, 'P636', 5),
(1111, 'porttitor odio', 'porttitor odio', 0, 1, 1.4667, 'P6363', 5),
(1112, 'porttitor odio quisque', 'porttitor odio quisque', 0, 1, 1.7333, 'P63632', 5),
(1116, 'posuere', 'posuere', 0, 0, 0.4667, 'P260', 5),
(1117, 'posuere molestie', 'posuere molestie', 0, 1, 1.5333, 'P265423', 5),
(1119, 'posuere placerat', 'posuere placerat', 0, 1, 1.5333, 'P2614263', 5),
(1120, 'posuere placerat ipsum', 'posuere placerat ipsum', 0, 1, 1.7333, 'P2614263125', 5),
(1122, 'proin', 'proin', 0, 0, 0.3333, 'P650', 5),
(1125, 'quisque', 'quisque', 0, 0, 0.4667, 'Q000', 5),
(1126, 'quisque sed', 'quisque sed', 0, 1, 1.3667, 'Q300', 5),
(1127, 'quisque sed orci', 'quisque sed orci', 0, 1, 1.5333, 'Q362', 5),
(1128, 'scelerisque', 'scelerisque', 0, 0, 0.7333, 'S462', 5),
(1129, 'scelerisque semper', 'scelerisque semper', 0, 1, 1.6, 'S462516', 5),
(1132, 'sed', 'sed', 0, 0, 0.2, 'S300', 5),
(1133, 'sed orci', 'sed orci', 0, 1, 1.2667, 'S362', 5),
(1134, 'sed orci et', 'sed orci et', 0, 1, 1.3667, 'S3623', 5),
(1137, 'sed posuere', 'sed posuere', 0, 1, 1.3667, 'S3126', 5),
(1138, 'sed posuere molestie', 'sed posuere molestie', 0, 1, 1.6667, 'S31265423', 5),
(1139, 'semper', 'semper', 0, 0, 0.4, 'S516', 5),
(1144, 'sit', 'sit', 0, 0, 0.2, 'S300', 5),
(1145, 'sit amet', 'sit amet', 0, 1, 1.2667, 'S353', 5),
(1146, 'sit amet consectetur', 'sit amet consectetur', 0, 1, 1.6667, 'S35325236', 5),
(1149, 'tellus', 'tellus', 0, 0, 0.4, 'T420', 5),
(1150, 'tellus viverra', 'tellus viverra', 0, 1, 1.4667, 'T4216', 5),
(1151, 'tellus viverra ut', 'tellus viverra ut', 0, 1, 1.5667, 'T42163', 5),
(1152, 'ut', 'ut', 0, 0, 0.1333, 'U300', 5),
(1153, 'ut nunc', 'ut nunc', 0, 1, 1.2333, 'U352', 5),
(1154, 'ut nunc feugiat', 'ut nunc feugiat', 0, 1, 1.5, 'U352123', 5),
(1157, 'venenatis', 'venenatis', 0, 0, 0.6, 'V532', 5),
(1158, 'venenatis mauris', 'venenatis mauris', 0, 1, 1.5333, 'V532562', 5),
(1159, 'venenatis mauris posuere', 'venenatis mauris posuere', 0, 1, 1.8, 'V532562126', 5),
(1160, 'vitae', 'vitae', 0, 0, 0.3333, 'V300', 5),
(1161, 'vitae elementum', 'vitae elementum', 0, 1, 1.5, 'V34535', 5),
(1162, 'vitae elementum tellus', 'vitae elementum tellus', 0, 1, 1.7333, 'V34535342', 5),
(1163, 'vivamus', 'vivamus', 0, 0, 0.4667, 'V520', 5),
(1164, 'vivamus et', 'vivamus et', 0, 1, 1.3333, 'V523', 5),
(1165, 'vivamus et venenatis', 'vivamus et venenatis', 0, 1, 1.6667, 'V5231532', 5),
(1166, 'viverra', 'viverra', 0, 0, 0.4667, 'V600', 5),
(1167, 'viverra ut', 'viverra ut', 0, 1, 1.3333, 'V630', 5),
(1168, 'viverra ut nunc', 'viverra ut nunc', 0, 1, 1.5, 'V6352', 5),
(1169, 'volutpat', 'volutpat', 0, 0, 0.5333, 'V4313', 5),
(1170, 'volutpat vivamus', 'volutpat vivamus', 0, 1, 1.5333, 'V4313152', 5),
(1171, 'volutpat vivamus et', 'volutpat vivamus et', 0, 1, 1.6333, 'V43131523', 5),
(1296, '2', '2', 0, 0, 0.1, '', 2),
(1297, 'feugiat magna”', 'feugiat magna”', 0, 1, 1.4667, 'F23525', 4),
(1298, 'feugiat magna” ac', 'feugiat magna” ac', 0, 1, 1.5667, 'F235252', 4),
(1299, 'index', 'index', 0, 0, 0.3333, 'I532', 4),
(1300, 'ipsum proin laciniaorci', 'ipsum proin laciniaorci', 0, 1, 1.7667, 'I12516542562', 4),
(1301, 'laciniaorci', 'laciniaorci', 0, 0, 0.7333, 'L2562', 4),
(1302, 'laciniaorci est', 'laciniaorci est', 0, 1, 1.5, 'L25623', 4),
(1303, 'laciniaorci est vitae', 'laciniaorci est vitae', 0, 1, 1.7, 'L2562313', 4),
(1304, 'lectusut', 'lectusut', 0, 0, 0.5333, 'L2323', 4),
(1305, 'lectusut volutpat', 'lectusut volutpat', 0, 1, 1.5667, 'L232314313', 4),
(1306, 'lectusut volutpat vivamus', 'lectusut volutpat vivamus', 0, 1, 1.8333, 'L232314313152', 4),
(1307, 'magna”', 'magna”', 0, 0, 0.4, 'M250', 4),
(1308, 'magna” ac', 'magna” ac', 0, 1, 1.3, 'M252', 4),
(1309, 'magna” ac eros', 'magna” ac eros', 0, 1, 1.4667, 'M25262', 4),
(1310, 'molestie lectusut', 'molestie lectusut', 0, 1, 1.5667, 'M42342323', 4),
(1311, 'molestie lectusut volutpat', 'molestie lectusut volutpat', 0, 1, 1.8667, 'M4234232314313', 4),
(1312, 'nunc feugiat magna”', 'nunc feugiat magna”', 0, 1, 1.6333, 'N2123525', 4),
(1313, 'posuere molestie lectusut', 'posuere molestie lectusut', 0, 1, 1.8333, 'P26542342323', 4),
(1314, 'proin laciniaorci', 'proin laciniaorci', 0, 1, 1.5667, 'P6542562', 4),
(1315, 'proin laciniaorci est', 'proin laciniaorci est', 0, 1, 1.7, 'P65425623', 4),
(1316, 'pupkin', 'pupkin', 0, 0, 0.4, 'P250', 4),
(1317, 'vasya', 'vasya', 0, 0, 0.3333, 'V200', 4),
(1318, 'vasya pupkin', 'vasya pupkin', 0, 1, 1.4, 'V2125', 4),
(1319, '«компании»', '«компании»', 0, 0, 0.6667, 'к000', 4),
(1320, 'вася', 'вася', 0, 0, 0.2667, 'в000', 4),
(1321, 'вася пупкин', 'вася пупкин', 0, 1, 1.3667, 'в000', 4),
(1322, 'генеральный', 'генеральный', 0, 0, 0.7333, 'г000', 4),
(1323, 'генеральный директор', 'генеральный директор', 0, 1, 1.6667, 'г000', 4),
(1324, 'генеральный директор «компании»', 'генеральный директор «компании»', 0, 1, 2, 'г000', 4),
(1325, 'директор', 'директор', 0, 0, 0.5333, 'д000', 4),
(1326, 'директор «компании»', 'директор «компании»', 0, 1, 1.6333, 'д000', 4),
(1327, 'отзыв', 'отзыв', 0, 0, 0.3333, 'о000', 4),
(1328, 'пупкин', 'пупкин', 0, 0, 0.4, 'п000', 4),
(1638, '3', '3', 0, 0, 0.1, '', 2),
(1639, 'pupkin 2', 'pupkin 2', 0, 1, 1.2667, 'P250', 1),
(1640, 'vasya pupkin 2', 'vasya pupkin 2', 0, 1, 1.4667, 'V2125', 1),
(1641, 'вася пупкин 2', 'вася пупкин 2', 0, 1, 1.4333, 'в000', 1),
(1642, 'пупкин 2', 'пупкин 2', 0, 1, 1.2667, 'п000', 1),
(1645, '5', '5', 0, 0, 0.1, '', 1),
(1646, 'pupkin 3', 'pupkin 3', 0, 1, 1.2667, 'P250', 1),
(1647, 'vasya pupkin 3', 'vasya pupkin 3', 0, 1, 1.4667, 'V2125', 1),
(1648, 'вася пупкин 3', 'вася пупкин 3', 0, 1, 1.4333, 'в000', 1),
(1649, 'пупкин 3', 'пупкин 3', 0, 1, 1.2667, 'п000', 1),
(1652, '4', '4', 0, 0, 0.1, '', 1),
(1653, 'pupkin 4', 'pupkin 4', 0, 1, 1.2667, 'P250', 1),
(1654, 'vasya pupkin 4', 'vasya pupkin 4', 0, 1, 1.4667, 'V2125', 1),
(1655, 'вася пупкин 4', 'вася пупкин 4', 0, 1, 1.4333, 'в000', 1),
(1656, 'пупкин 4', 'пупкин 4', 0, 1, 1.2667, 'п000', 1),
(1659, '1', '1', 0, 0, 0.1, '', 1),
(1660, 'elit sed posu', 'elit sed posu', 0, 1, 1.4333, 'E432312', 1),
(1661, 'feugiat magna', 'feugiat magna', 0, 1, 1.4333, 'F23525', 1),
(1662, 'feugiat magna ac', 'feugiat magna ac', 0, 1, 1.5333, 'F235252', 1),
(1663, 'ipsum proin lacinia', 'ipsum proin lacinia', 0, 1, 1.6333, 'I125165425', 1),
(1664, 'lacinia', 'lacinia', 0, 0, 0.4667, 'L250', 1),
(1665, 'lacinia orci', 'lacinia orci', 0, 1, 1.4, 'L2562', 1),
(1666, 'lacinia orci est', 'lacinia orci est', 0, 1, 1.5333, 'L25623', 1),
(1667, 'lectus', 'lectus', 0, 0, 0.4, 'L232', 1),
(1668, 'lectus ut', 'lectus ut', 0, 1, 1.3, 'L2323', 1),
(1669, 'lectus ut volutpat', 'lectus ut volutpat', 0, 1, 1.6, 'L232314313', 1),
(1670, 'magna', 'magna', 0, 0, 0.3333, 'M250', 1),
(1671, 'magna ac', 'magna ac', 0, 1, 1.2667, 'M252', 1),
(1672, 'magna ac eros', 'magna ac eros', 0, 1, 1.4333, 'M25262', 1),
(1673, 'molestie lectus', 'molestie lectus', 0, 1, 1.5, 'M4234232', 1),
(1674, 'molestie lectus ut', 'molestie lectus ut', 0, 1, 1.6, 'M42342323', 1),
(1675, 'nunc feugiat magna', 'nunc feugiat magna', 0, 1, 1.6, 'N2123525', 1),
(1676, 'orci est', 'orci est', 0, 1, 1.2667, 'O623', 1),
(1677, 'orci est vitae', 'orci est vitae', 0, 1, 1.4667, 'O62313', 1),
(1678, 'posu', 'posu', 0, 0, 0.2667, 'P200', 1),
(1679, 'posu orci', 'posu orci', 0, 1, 1.3, 'P262', 1),
(1680, 'posu orci est', 'posu orci est', 0, 1, 1.4333, 'P2623', 1),
(1681, 'posuere molestie lectus', 'posuere molestie lectus', 0, 1, 1.7667, 'P2654234232', 1),
(1682, 'produkciya', 'produkciya', 0, 0, 0.6667, 'P632', 1),
(1683, 'proin lacinia', 'proin lacinia', 0, 1, 1.4333, 'P65425', 1),
(1684, 'proin lacinia orci', 'proin lacinia orci', 0, 1, 1.6, 'P6542562', 1),
(1685, 'scelerisque semper lorem', 'scelerisque semper lorem', 0, 1, 1.8, 'S462516465', 1),
(1686, 'scelerisque semper vivamus', 'scelerisque semper vivamus', 0, 1, 1.8667, 'S462516152', 1),
(1687, 'sed posu', 'sed posu', 0, 1, 1.2667, 'S312', 1),
(1688, 'sed posu orci', 'sed posu orci', 0, 1, 1.4333, 'S31262', 1),
(1689, 'semper lorem', 'semper lorem', 0, 1, 1.4, 'S516465', 1),
(1690, 'semper lorem ipsum', 'semper lorem ipsum', 0, 1, 1.6, 'S516465125', 1),
(1691, 'semper vivamus', 'semper vivamus', 0, 1, 1.4667, 'S516152', 1),
(1692, 'semper vivamus et', 'semper vivamus et', 0, 1, 1.5667, 'S5161523', 1),
(1693, 'suvenirnaya', 'suvenirnaya', 0, 0, 0.7333, 'S1565', 1),
(1694, 'suvenirnaya produkciya', 'suvenirnaya produkciya', 0, 1, 1.7333, 'S15651632', 1),
(1695, 'ut volutpat', 'ut volutpat', 0, 1, 1.3667, 'U314313', 1),
(1696, 'ut volutpat vivamus', 'ut volutpat vivamus', 0, 1, 1.6333, 'U314313152', 1),
(1697, 'брелоки', 'брелоки', 0, 0, 0.4667, 'б000', 1),
(1698, 'брелоки пазлы', 'брелоки пазлы', 0, 1, 1.4333, 'б000', 1),
(1699, 'брелоки пазлы кружки2', 'брелоки пазлы кружки2', 0, 1, 1.7, 'б000', 1),
(1700, 'виды', 'виды', 0, 0, 0.2667, 'в000', 1),
(1701, 'виды сувенирной', 'виды сувенирной', 0, 1, 1.5, 'в000', 1),
(1702, 'виды сувенирной продукции', 'виды сувенирной продукции', 0, 1, 1.8333, 'в000', 1),
(1703, 'для', 'для', 0, 0, 0.2, 'д000', 1),
(1704, 'для фотоцентров', 'для фотоцентров', 0, 1, 1.5, 'д000', 1),
(1705, 'для фотоцентров полиграфических', 'для фотоцентров полиграфических', 0, 1, 2, 'д000', 1),
(1706, 'должна', 'должна', 0, 0, 0.4, 'д000', 1),
(1707, 'должна кратко', 'должна кратко', 0, 1, 1.4333, 'д000', 1),
(1708, 'должна кратко расшифровываться', 'должна кратко расшифровываться', 0, 1, 2, 'д000', 1),
(1709, 'жения', 'жения', 0, 0, 0.3333, 'ж000', 1),
(1710, 'жения перечисление', 'жения перечисление', 0, 1, 1.6, 'ж000', 1),
(1711, 'жения перечисление каких-то', 'жения перечисление каких-то', 0, 1, 1.9, 'ж000', 1),
(1712, 'заказов', 'заказов', 0, 0, 0.4667, 'з000', 1),
(1713, 'заказов на', 'заказов на', 0, 1, 1.3333, 'з000', 1),
(1714, 'заказов на сувениирную', 'заказов на сувениирную', 0, 1, 1.7333, 'з000', 1),
(1715, 'здесь', 'здесь', 0, 0, 0.3333, 'з000', 1),
(1716, 'здесь должна', 'здесь должна', 0, 1, 1.4, 'з000', 1),
(1717, 'здесь должна кратко', 'здесь должна кратко', 0, 1, 1.6333, 'з000', 1),
(1718, 'и', 'и', 0, 0, 0.0667, 'и000', 1),
(1719, 'и сувенирных', 'и сувенирных', 0, 1, 1.4, 'и000', 1),
(1720, 'и сувенирных компаний', 'и сувенирных компаний', 0, 1, 1.7, 'и000', 1),
(1721, 'каких-то', 'каких-то', 0, 0, 0.5333, 'к000', 1),
(1722, 'каких-то ключвых', 'каких-то ключвых', 0, 1, 1.5333, 'к000', 1),
(1723, 'каких-то ключвых плющек', 'каких-то ключвых плющек', 0, 1, 1.7667, 'к000', 1),
(1724, 'клиент', 'клиент', 0, 0, 0.4, 'к000', 1),
(1725, 'клиент здесь', 'клиент здесь', 0, 1, 1.4, 'к000', 1),
(1726, 'клиент здесь должна', 'клиент здесь должна', 0, 1, 1.6333, 'к000', 1),
(1727, 'ключвых', 'ключвых', 0, 0, 0.4667, 'к000', 1),
(1728, 'ключвых плющек', 'ключвых плющек', 0, 1, 1.4667, 'к000', 1),
(1729, 'ключвых плющек которые', 'ключвых плющек которые', 0, 1, 1.7333, 'к000', 1),
(1730, 'компаний', 'компаний', 0, 0, 0.5333, 'к000', 1),
(1731, 'компаний здесь', 'компаний здесь', 0, 1, 1.4667, 'к000', 1),
(1732, 'компаний здесь должна', 'компаний здесь должна', 0, 1, 1.7, 'к000', 1),
(1733, 'которые', 'которые', 0, 0, 0.4667, 'к000', 1),
(1734, 'которые получит', 'которые получит', 0, 1, 1.5, 'к000', 1),
(1735, 'которые получит клиент', 'которые получит клиент', 0, 1, 1.7333, 'к000', 1),
(1736, 'кратко', 'кратко', 0, 0, 0.4, 'к000', 1),
(1737, 'кратко расшифровываться', 'кратко расшифровываться', 0, 1, 1.7667, 'к000', 1),
(1738, 'кратко расшифровываться суть', 'кратко расшифровываться суть', 0, 1, 1.9333, 'к000', 1),
(1739, 'кружки', 'кружки', 0, 0, 0.4, 'к000', 1),
(1740, 'кружки футболки', 'кружки футболки', 0, 1, 1.5, 'к000', 1),
(1741, 'кружки футболки подушки', 'кружки футболки подушки', 0, 1, 1.7667, 'к000', 1),
(1742, 'кружки2', 'кружки2', 0, 0, 0.4667, 'к000', 1),
(1743, 'кружки2 подушки2', 'кружки2 подушки2', 0, 1, 1.5333, 'к000', 1),
(1744, 'любые', 'любые', 0, 0, 0.3333, 'л000', 1),
(1745, 'любые виды', 'любые виды', 0, 1, 1.3333, 'л000', 1),
(1746, 'любые виды сувенирной', 'любые виды сувенирной', 0, 1, 1.7, 'л000', 1),
(1747, 'на', 'на', 0, 0, 0.1333, 'н000', 1),
(1748, 'на сувениирную', 'на сувениирную', 0, 1, 1.4667, 'н000', 1),
(1749, 'на сувениирную продукцию', 'на сувениирную продукцию', 0, 1, 1.8, 'н000', 1),
(1750, 'онлайн', 'онлайн', 0, 0, 0.4, 'о000', 1),
(1751, 'онлайн решение', 'онлайн решение', 0, 1, 1.4667, 'о000', 1),
(1752, 'онлайн решение для', 'онлайн решение для', 0, 1, 1.6, 'о000', 1),
(1753, 'открой', 'открой', 0, 0, 0.4, 'о000', 1),
(1754, 'открой свой', 'открой свой', 0, 1, 1.3667, 'о000', 1),
(1755, 'открой свой сайт', 'открой свой сайт', 0, 1, 1.5333, 'о000', 1),
(1756, 'пазлы', 'пазлы', 0, 0, 0.3333, 'п000', 1),
(1757, 'пазлы кружки2', 'пазлы кружки2', 0, 1, 1.4333, 'п000', 1),
(1758, 'пазлы кружки2 подушки2', 'пазлы кружки2 подушки2', 0, 1, 1.7333, 'п000', 1),
(1759, 'перечисление', 'перечисление', 0, 0, 0.8, 'п000', 1),
(1760, 'перечисление каких-то', 'перечисление каких-то', 0, 1, 1.7, 'п000', 1),
(1761, 'перечисление каких-то ключвых', 'перечисление каких-то ключвых', 0, 1, 1.9667, 'п000', 1),
(1762, 'плющек', 'плющек', 0, 0, 0.4, 'п000', 1),
(1763, 'плющек которые', 'плющек которые', 0, 1, 1.4667, 'п000', 1),
(1764, 'плющек которые получит', 'плющек которые получит', 0, 1, 1.7333, 'п000', 1),
(1765, 'подушки', 'подушки', 0, 0, 0.4667, 'п000', 1),
(1766, 'подушки брелоки', 'подушки брелоки', 0, 1, 1.5, 'п000', 1),
(1767, 'подушки брелоки пазлы', 'подушки брелоки пазлы', 0, 1, 1.7, 'п000', 1),
(1768, 'подушки2', 'подушки2', 0, 0, 0.5333, 'п000', 1),
(1769, 'полиграфических', 'полиграфических', 0, 0, 1, 'п000', 1),
(1770, 'полиграфических и', 'полиграфических и', 0, 1, 1.5667, 'п000', 1),
(1771, 'полиграфических и сувенирных', 'полиграфических и сувенирных', 0, 1, 1.9333, 'п000', 1),
(1772, 'получит', 'получит', 0, 0, 0.4667, 'п000', 1),
(1773, 'получит клиент', 'получит клиент', 0, 1, 1.4667, 'п000', 1),
(1774, 'получит клиент здесь', 'получит клиент здесь', 0, 1, 1.6667, 'п000', 1),
(1775, 'предло', 'предло', 0, 0, 0.4, 'п000', 1),
(1776, 'предло жения', 'предло жения', 0, 1, 1.4, 'п000', 1),
(1777, 'предло жения перечисление', 'предло жения перечисление', 0, 1, 1.8333, 'п000', 1),
(1778, 'предложения', 'предложения', 0, 0, 0.7333, 'п000', 1),
(1779, 'предложения перечисление', 'предложения перечисление', 0, 1, 1.8, 'п000', 1),
(1780, 'предложения перечисление каких-то', 'предложения перечисление каких-то', 0, 1, 2, 'п000', 1),
(1781, 'продукт', 'продукт', 0, 0, 0.4667, 'п000', 1),
(1782, 'продукции', 'продукции', 0, 0, 0.6, 'п000', 1),
(1783, 'продукции lorem', 'продукции lorem', 0, 1, 1.5, 'п465', 1),
(1784, 'продукции lorem ipsum', 'продукции lorem ipsum', 0, 1, 1.7, 'п465125', 1),
(1785, 'продукцию', 'продукцию', 0, 0, 0.6, 'п000', 1),
(1786, 'продукция', 'продукция', 0, 0, 0.6, 'п000', 1),
(1787, 'расшифровываться', 'расшифровываться', 0, 0, 1, 'р000', 1),
(1788, 'расшифровываться суть', 'расшифровываться суть', 0, 1, 1.7, 'р000', 1),
(1789, 'расшифровываться суть предло', 'расшифровываться суть предло', 0, 1, 1.9333, 'р000', 1),
(1790, 'расшифровываться суть предложения', 'расшифровываться суть предложения', 0, 1, 2, 'р000', 1),
(1791, 'решение', 'решение', 0, 0, 0.4667, 'р000', 1),
(1792, 'решение для', 'решение для', 0, 1, 1.3667, 'р000', 1),
(1793, 'решение для фотоцентров', 'решение для фотоцентров', 0, 1, 1.7667, 'р000', 1),
(1794, 'сайт', 'сайт', 0, 0, 0.2667, 'с000', 1),
(1795, 'сайт заказов', 'сайт заказов', 0, 1, 1.4, 'с000', 1),
(1796, 'сайт заказов на', 'сайт заказов на', 0, 1, 1.5, 'с000', 1),
(1797, 'свой', 'свой', 0, 0, 0.2667, 'с000', 1),
(1798, 'свой сайт', 'свой сайт', 0, 1, 1.3, 'с000', 1),
(1799, 'свой сайт заказов', 'свой сайт заказов', 0, 1, 1.5667, 'с000', 1),
(1800, 'сувениирную', 'сувениирную', 0, 0, 0.7333, 'с000', 1),
(1801, 'сувениирную продукцию', 'сувениирную продукцию', 0, 1, 1.7, 'с000', 1),
(1802, 'сувенирная', 'сувенирная', 0, 0, 0.6667, 'с000', 1),
(1803, 'сувенирная продукция', 'сувенирная продукция', 0, 1, 1.6667, 'с000', 1),
(1804, 'сувенирной', 'сувенирной', 0, 0, 0.6667, 'с000', 1),
(1805, 'сувенирной продукции', 'сувенирной продукции', 0, 1, 1.6667, 'с000', 1),
(1806, 'сувенирной продукции lorem', 'сувенирной продукции lorem', 0, 1, 1.8667, 'с465', 1),
(1807, 'сувенирных', 'сувенирных', 0, 0, 0.6667, 'с000', 1),
(1808, 'сувенирных компаний', 'сувенирных компаний', 0, 1, 1.6333, 'с000', 1),
(1809, 'сувенирных компаний здесь', 'сувенирных компаний здесь', 0, 1, 1.8333, 'с000', 1),
(1810, 'суть', 'суть', 0, 0, 0.2667, 'с000', 1),
(1811, 'суть предло', 'суть предло', 0, 1, 1.3667, 'с000', 1),
(1812, 'суть предло жения', 'суть предло жения', 0, 1, 1.5667, 'с000', 1),
(1813, 'суть предложения', 'суть предложения', 0, 1, 1.5333, 'с000', 1),
(1814, 'суть предложения перечисление', 'суть предложения перечисление', 0, 1, 1.9667, 'с000', 1),
(1815, 'фотоцентров', 'фотоцентров', 0, 0, 0.7333, 'ф000', 1),
(1816, 'фотоцентров полиграфических', 'фотоцентров полиграфических', 0, 1, 1.9, 'ф000', 1),
(1817, 'фотоцентров полиграфических и', 'фотоцентров полиграфических и', 0, 1, 1.9667, 'ф000', 1),
(1818, 'футболки', 'футболки', 0, 0, 0.5333, 'ф000', 1),
(1819, 'футболки подушки', 'футболки подушки', 0, 1, 1.5333, 'ф000', 1),
(1820, 'футболки подушки брелоки', 'футболки подушки брелоки', 0, 1, 1.8, 'ф000', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_finder_terms_common`
--

CREATE TABLE IF NOT EXISTS `sdc98_finder_terms_common` (
  `term` varchar(75) NOT NULL,
  `language` varchar(3) NOT NULL,
  KEY `idx_word_lang` (`term`,`language`),
  KEY `idx_lang` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sdc98_finder_terms_common`
--

INSERT INTO `sdc98_finder_terms_common` (`term`, `language`) VALUES
('a', 'en'),
('about', 'en'),
('after', 'en'),
('ago', 'en'),
('all', 'en'),
('am', 'en'),
('an', 'en'),
('and', 'en'),
('ani', 'en'),
('any', 'en'),
('are', 'en'),
('aren''t', 'en'),
('as', 'en'),
('at', 'en'),
('be', 'en'),
('but', 'en'),
('by', 'en'),
('for', 'en'),
('from', 'en'),
('get', 'en'),
('go', 'en'),
('how', 'en'),
('if', 'en'),
('in', 'en'),
('into', 'en'),
('is', 'en'),
('isn''t', 'en'),
('it', 'en'),
('its', 'en'),
('me', 'en'),
('more', 'en'),
('most', 'en'),
('must', 'en'),
('my', 'en'),
('new', 'en'),
('no', 'en'),
('none', 'en'),
('not', 'en'),
('noth', 'en'),
('nothing', 'en'),
('of', 'en'),
('off', 'en'),
('often', 'en'),
('old', 'en'),
('on', 'en'),
('onc', 'en'),
('once', 'en'),
('onli', 'en'),
('only', 'en'),
('or', 'en'),
('other', 'en'),
('our', 'en'),
('ours', 'en'),
('out', 'en'),
('over', 'en'),
('page', 'en'),
('she', 'en'),
('should', 'en'),
('small', 'en'),
('so', 'en'),
('some', 'en'),
('than', 'en'),
('thank', 'en'),
('that', 'en'),
('the', 'en'),
('their', 'en'),
('theirs', 'en'),
('them', 'en'),
('then', 'en'),
('there', 'en'),
('these', 'en'),
('they', 'en'),
('this', 'en'),
('those', 'en'),
('thus', 'en'),
('time', 'en'),
('times', 'en'),
('to', 'en'),
('too', 'en'),
('true', 'en'),
('under', 'en'),
('until', 'en'),
('up', 'en'),
('upon', 'en'),
('use', 'en'),
('user', 'en'),
('users', 'en'),
('veri', 'en'),
('version', 'en'),
('very', 'en'),
('via', 'en'),
('want', 'en'),
('was', 'en'),
('way', 'en'),
('were', 'en'),
('what', 'en'),
('when', 'en'),
('where', 'en'),
('whi', 'en'),
('which', 'en'),
('who', 'en'),
('whom', 'en'),
('whose', 'en'),
('why', 'en'),
('wide', 'en'),
('will', 'en'),
('with', 'en'),
('within', 'en'),
('without', 'en'),
('would', 'en'),
('yes', 'en'),
('yet', 'en'),
('you', 'en'),
('your', 'en'),
('yours', 'en');

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_finder_tokens`
--

CREATE TABLE IF NOT EXISTS `sdc98_finder_tokens` (
  `term` varchar(75) NOT NULL,
  `stem` varchar(75) NOT NULL,
  `common` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `phrase` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` float unsigned NOT NULL DEFAULT '1',
  `context` tinyint(1) unsigned NOT NULL DEFAULT '2',
  KEY `idx_word` (`term`),
  KEY `idx_context` (`context`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_finder_tokens_aggregate`
--

CREATE TABLE IF NOT EXISTS `sdc98_finder_tokens_aggregate` (
  `term_id` int(10) unsigned NOT NULL,
  `map_suffix` char(1) NOT NULL,
  `term` varchar(75) NOT NULL,
  `stem` varchar(75) NOT NULL,
  `common` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `phrase` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `term_weight` float unsigned NOT NULL,
  `context` tinyint(1) unsigned NOT NULL DEFAULT '2',
  `context_weight` float unsigned NOT NULL,
  `total_weight` float unsigned NOT NULL,
  KEY `token` (`term`),
  KEY `keyword_id` (`term_id`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_finder_types`
--

CREATE TABLE IF NOT EXISTS `sdc98_finder_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `mime` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `sdc98_finder_types`
--

INSERT INTO `sdc98_finder_types` (`id`, `title`, `mime`) VALUES
(1, 'ZOO Item', ''),
(2, 'Category', ''),
(3, 'Contact', ''),
(4, 'Article', ''),
(5, 'News Feed', ''),
(6, 'Web Link', '');

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_foxcontact_sessions`
--

CREATE TABLE IF NOT EXISTS `sdc98_foxcontact_sessions` (
  `id` varchar(32) NOT NULL,
  `cid` int(11) NOT NULL,
  `mid` int(11) NOT NULL,
  `keyword` varchar(32) NOT NULL,
  `birth` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data` text,
  UNIQUE KEY `index` (`id`,`cid`,`mid`,`keyword`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_foxcontact_settings`
--

CREATE TABLE IF NOT EXISTS `sdc98_foxcontact_settings` (
  `name` varchar(32) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sdc98_foxcontact_settings`
--

INSERT INTO `sdc98_foxcontact_settings` (`name`, `value`) VALUES
('captchadrawer', 'use_gd'),
('dns', 'dns_check'),
('mimefilter', 'disabled');

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_languages`
--

CREATE TABLE IF NOT EXISTS `sdc98_languages` (
  `lang_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `lang_code` char(7) NOT NULL,
  `title` varchar(50) NOT NULL,
  `title_native` varchar(50) NOT NULL,
  `sef` varchar(50) NOT NULL,
  `image` varchar(50) NOT NULL,
  `description` varchar(512) NOT NULL,
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `sitename` varchar(1024) NOT NULL DEFAULT '',
  `published` int(11) NOT NULL DEFAULT '0',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lang_id`),
  UNIQUE KEY `idx_sef` (`sef`),
  UNIQUE KEY `idx_image` (`image`),
  UNIQUE KEY `idx_langcode` (`lang_code`),
  KEY `idx_access` (`access`),
  KEY `idx_ordering` (`ordering`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `sdc98_languages`
--

INSERT INTO `sdc98_languages` (`lang_id`, `lang_code`, `title`, `title_native`, `sef`, `image`, `description`, `metakey`, `metadesc`, `sitename`, `published`, `access`, `ordering`) VALUES
(1, 'en-GB', 'English (UK)', 'English (UK)', 'en', 'en', '', '', '', '', 1, 1, 1),
(2, 'ru-RU', 'Russian', 'Russian', 'ru', 'ru', '', '', '', '', 1, 1, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_menu`
--

CREATE TABLE IF NOT EXISTS `sdc98_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menutype` varchar(24) NOT NULL COMMENT 'The type of menu this item belongs to. FK to #__menu_types.menutype',
  `title` varchar(255) NOT NULL COMMENT 'The display title of the menu item.',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT 'The SEF alias of the menu item.',
  `note` varchar(255) NOT NULL DEFAULT '',
  `path` varchar(1024) NOT NULL COMMENT 'The computed path of the menu item based on the alias field.',
  `link` varchar(1024) NOT NULL COMMENT 'The actually link the menu item refers to.',
  `type` varchar(16) NOT NULL COMMENT 'The type of link: Component, URL, Alias, Separator',
  `published` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'The published state of the menu link.',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '1' COMMENT 'The parent menu item in the menu tree.',
  `level` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The relative level in the tree.',
  `component_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to #__extensions.id',
  `ordering` int(11) NOT NULL DEFAULT '0' COMMENT 'The relative ordering of the menu item in the tree.',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to #__users.id',
  `checked_out_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'The time the menu item was checked out.',
  `browserNav` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'The click behaviour of the link.',
  `access` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The access level required to view the menu item.',
  `img` varchar(255) NOT NULL COMMENT 'The image of the menu item.',
  `template_style_id` int(10) unsigned NOT NULL DEFAULT '0',
  `params` text NOT NULL COMMENT 'JSON encoded data for the menu item.',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `home` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Indicates if this menu item is the home or default page.',
  `language` char(7) NOT NULL DEFAULT '',
  `client_id` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_client_id_parent_id_alias_language` (`client_id`,`parent_id`,`alias`,`language`),
  KEY `idx_componentid` (`component_id`,`menutype`,`published`,`access`),
  KEY `idx_menutype` (`menutype`),
  KEY `idx_left_right` (`lft`,`rgt`),
  KEY `idx_alias` (`alias`),
  KEY `idx_path` (`path`(255)),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=107 ;

--
-- Дамп данных таблицы `sdc98_menu`
--

INSERT INTO `sdc98_menu` (`id`, `menutype`, `title`, `alias`, `note`, `path`, `link`, `type`, `published`, `parent_id`, `level`, `component_id`, `ordering`, `checked_out`, `checked_out_time`, `browserNav`, `access`, `img`, `template_style_id`, `params`, `lft`, `rgt`, `home`, `language`, `client_id`) VALUES
(1, '', 'Menu_Item_Root', 'root', '', '', '', '', 1, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, 0, '', 0, '', 0, 53, 0, '*', 0),
(2, 'menu', 'com_banners', 'Banners', '', 'Banners', 'index.php?option=com_banners', 'component', 0, 1, 1, 4, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners', 0, '', 1, 10, 0, '*', 1),
(3, 'menu', 'com_banners', 'Banners', '', 'Banners/Banners', 'index.php?option=com_banners', 'component', 0, 2, 2, 4, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners', 0, '', 2, 3, 0, '*', 1),
(4, 'menu', 'com_banners_categories', 'Categories', '', 'Banners/Categories', 'index.php?option=com_categories&extension=com_banners', 'component', 0, 2, 2, 6, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners-cat', 0, '', 4, 5, 0, '*', 1),
(5, 'menu', 'com_banners_clients', 'Clients', '', 'Banners/Clients', 'index.php?option=com_banners&view=clients', 'component', 0, 2, 2, 4, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners-clients', 0, '', 6, 7, 0, '*', 1),
(6, 'menu', 'com_banners_tracks', 'Tracks', '', 'Banners/Tracks', 'index.php?option=com_banners&view=tracks', 'component', 0, 2, 2, 4, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners-tracks', 0, '', 8, 9, 0, '*', 1),
(7, 'menu', 'com_contact', 'Contacts', '', 'Contacts', 'index.php?option=com_contact', 'component', 0, 1, 1, 8, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:contact', 0, '', 11, 16, 0, '*', 1),
(8, 'menu', 'com_contact', 'Contacts', '', 'Contacts/Contacts', 'index.php?option=com_contact', 'component', 0, 7, 2, 8, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:contact', 0, '', 12, 13, 0, '*', 1),
(9, 'menu', 'com_contact_categories', 'Categories', '', 'Contacts/Categories', 'index.php?option=com_categories&extension=com_contact', 'component', 0, 7, 2, 6, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:contact-cat', 0, '', 14, 15, 0, '*', 1),
(10, 'menu', 'com_messages', 'Messaging', '', 'Messaging', 'index.php?option=com_messages', 'component', 0, 1, 1, 15, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:messages', 0, '', 17, 22, 0, '*', 1),
(11, 'menu', 'com_messages_add', 'New Private Message', '', 'Messaging/New Private Message', 'index.php?option=com_messages&task=message.add', 'component', 0, 10, 2, 15, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:messages-add', 0, '', 18, 19, 0, '*', 1),
(12, 'menu', 'com_messages_read', 'Read Private Message', '', 'Messaging/Read Private Message', 'index.php?option=com_messages', 'component', 0, 10, 2, 15, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:messages-read', 0, '', 20, 21, 0, '*', 1),
(13, 'menu', 'com_newsfeeds', 'News Feeds', '', 'News Feeds', 'index.php?option=com_newsfeeds', 'component', 0, 1, 1, 17, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:newsfeeds', 0, '', 23, 28, 0, '*', 1),
(14, 'menu', 'com_newsfeeds_feeds', 'Feeds', '', 'News Feeds/Feeds', 'index.php?option=com_newsfeeds', 'component', 0, 13, 2, 17, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:newsfeeds', 0, '', 24, 25, 0, '*', 1),
(15, 'menu', 'com_newsfeeds_categories', 'Categories', '', 'News Feeds/Categories', 'index.php?option=com_categories&extension=com_newsfeeds', 'component', 0, 13, 2, 6, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:newsfeeds-cat', 0, '', 26, 27, 0, '*', 1),
(16, 'menu', 'com_redirect', 'Redirect', '', 'Redirect', 'index.php?option=com_redirect', 'component', 0, 1, 1, 24, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:redirect', 0, '', 39, 40, 0, '*', 1),
(17, 'menu', 'com_search', 'Basic Search', '', 'Basic Search', 'index.php?option=com_search', 'component', 0, 1, 1, 19, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:search', 0, '', 31, 32, 0, '*', 1),
(18, 'menu', 'com_weblinks', 'Weblinks', '', 'Weblinks', 'index.php?option=com_weblinks', 'component', 0, 1, 1, 21, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:weblinks', 0, '', 33, 38, 0, '*', 1),
(19, 'menu', 'com_weblinks_links', 'Links', '', 'Weblinks/Links', 'index.php?option=com_weblinks', 'component', 0, 18, 2, 21, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:weblinks', 0, '', 34, 35, 0, '*', 1),
(20, 'menu', 'com_weblinks_categories', 'Categories', '', 'Weblinks/Categories', 'index.php?option=com_categories&extension=com_weblinks', 'component', 0, 18, 2, 6, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:weblinks-cat', 0, '', 36, 37, 0, '*', 1),
(21, 'menu', 'com_finder', 'Smart Search', '', 'Smart Search', 'index.php?option=com_finder', 'component', 0, 1, 1, 27, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:finder', 0, '', 29, 30, 0, '*', 1),
(22, 'menu', 'com_joomlaupdate', 'Joomla! Update', '', 'Joomla! Update', 'index.php?option=com_joomlaupdate', 'component', 0, 1, 1, 28, 0, 0, '0000-00-00 00:00:00', 0, 0, 'class:joomlaupdate', 0, '', 39, 40, 0, '*', 1),
(101, 'mainmenu', 'Сувенирная продукция', 'home', '', '2014-07-18-14-15-38/home', 'index.php?option=com_zoo&view=item&layout=item', 'component', 1, 105, 2, 10000, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"item_id":"1","application":"1","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":1,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 46, 47, 1, '*', 0),
(102, 'main', 'com_zoo', 'com-zoo', '', 'com-zoo', 'index.php?option=com_zoo', 'component', 0, 1, 1, 10000, 0, 0, '0000-00-00 00:00:00', 0, 1, 'components/com_zoo/assets/images/zoo_16.png', 0, '', 41, 42, 0, '', 1),
(103, 'mainmenu', 'О компании', 'o-kompanii', '', 'o-kompanii', 'index.php?option=com_content&view=article&id=1', 'component', 1, 1, 1, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","urls_position":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 43, 44, 0, '*', 0),
(104, 'mainmenu', 'Контакты', 'kontakty', '', 'kontakty', 'index.php?option=com_content&view=article&id=2', 'component', 1, 1, 1, 22, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","urls_position":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 49, 50, 0, '*', 0),
(105, 'mainmenu', 'Продукты', '2014-07-18-14-15-38', '', '2014-07-18-14-15-38', '#', 'url', 1, 1, 1, 0, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"dropdown-toggle js-activated","menu_image":"","menu_text":1}', 45, 48, 0, '*', 0),
(106, 'main', 'COM_FOXCONTACT_MENU', 'com-foxcontact-menu', '', 'com-foxcontact-menu', 'index.php?option=com_foxcontact', 'component', 0, 1, 1, 10014, 0, 0, '0000-00-00 00:00:00', 0, 1, '../media/com_foxcontact/images/email-16.png', 0, '', 51, 52, 0, '', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_menu_types`
--

CREATE TABLE IF NOT EXISTS `sdc98_menu_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `menutype` varchar(24) NOT NULL,
  `title` varchar(48) NOT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_menutype` (`menutype`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `sdc98_menu_types`
--

INSERT INTO `sdc98_menu_types` (`id`, `menutype`, `title`, `description`) VALUES
(1, 'mainmenu', 'Main Menu', 'The main menu for the site');

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_messages`
--

CREATE TABLE IF NOT EXISTS `sdc98_messages` (
  `message_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id_from` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id_to` int(10) unsigned NOT NULL DEFAULT '0',
  `folder_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `priority` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` text NOT NULL,
  PRIMARY KEY (`message_id`),
  KEY `useridto_state` (`user_id_to`,`state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_messages_cfg`
--

CREATE TABLE IF NOT EXISTS `sdc98_messages_cfg` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `cfg_name` varchar(100) NOT NULL DEFAULT '',
  `cfg_value` varchar(255) NOT NULL DEFAULT '',
  UNIQUE KEY `idx_user_var_name` (`user_id`,`cfg_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_modules`
--

CREATE TABLE IF NOT EXISTS `sdc98_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `position` varchar(50) NOT NULL DEFAULT '',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `module` varchar(50) DEFAULT NULL,
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `showtitle` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `params` text NOT NULL,
  `client_id` tinyint(4) NOT NULL DEFAULT '0',
  `language` char(7) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `published` (`published`,`access`),
  KEY `newsfeeds` (`module`,`published`),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=93 ;

--
-- Дамп данных таблицы `sdc98_modules`
--

INSERT INTO `sdc98_modules` (`id`, `title`, `note`, `content`, `ordering`, `position`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `published`, `module`, `access`, `showtitle`, `params`, `client_id`, `language`) VALUES
(1, 'Main Menu', '', '', 1, 'top-menu', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 1, 0, '{"menutype":"mainmenu","startLevel":"1","endLevel":"0","showAllChildren":"0","tag_id":"","class_sfx":"","window_open":"","layout":"printsolution:default2","moduleclass_sfx":" top-menu","cache":"1","cache_time":"900","cachemode":"itemid"}', 0, '*'),
(2, 'Login', '', '', 1, 'login', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_login', 1, 1, '', 1, '*'),
(3, 'Popular Articles', '', '', 3, 'cpanel', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_popular', 3, 1, '{"count":"5","catid":"","user_id":"0","layout":"_:default","moduleclass_sfx":"","cache":"0","automatic_title":"1"}', 1, '*'),
(4, 'Recently Added Articles', '', '', 4, 'cpanel', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_latest', 3, 1, '{"count":"5","ordering":"c_dsc","catid":"","user_id":"0","layout":"_:default","moduleclass_sfx":"","cache":"0","automatic_title":"1"}', 1, '*'),
(8, 'Toolbar', '', '', 1, 'toolbar', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_toolbar', 3, 1, '', 1, '*'),
(9, 'Quick Icons', '', '', 1, 'icon', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_quickicon', 3, 1, '', 1, '*'),
(10, 'Logged-in Users', '', '', 2, 'cpanel', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_logged', 3, 1, '{"count":"5","name":"1","layout":"_:default","moduleclass_sfx":"","cache":"0","automatic_title":"1"}', 1, '*'),
(12, 'Admin Menu', '', '', 1, 'menu', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 3, 1, '{"layout":"","moduleclass_sfx":"","shownew":"1","showhelp":"1","cache":"0"}', 1, '*'),
(13, 'Admin Submenu', '', '', 1, 'submenu', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_submenu', 3, 1, '', 1, '*'),
(14, 'User Status', '', '', 2, 'status', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_status', 3, 1, '', 1, '*'),
(15, 'Title', '', '', 1, 'title', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_title', 3, 1, '', 1, '*'),
(16, 'Login Form', '', '', 7, 'position-7', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_login', 1, 1, '{"greeting":"1","name":"0"}', 0, '*'),
(17, 'Breadcrumbs', '', '', 1, 'position-2', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_breadcrumbs', 1, 1, '{"moduleclass_sfx":"","showHome":"1","homeText":"Home","showComponent":"1","separator":"","cache":"1","cache_time":"900","cachemode":"itemid"}', 0, '*'),
(79, 'Multilanguage status', '', '', 1, 'status', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_multilangstatus', 3, 1, '{"layout":"_:default","moduleclass_sfx":"","cache":"0"}', 1, '*'),
(86, 'Joomla Version', '', '', 1, 'footer', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_version', 3, 1, '{"format":"short","product":"1","layout":"_:default","moduleclass_sfx":"","cache":"0"}', 1, '*'),
(87, 'ZOO Category', '', '', 0, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_zoocategory', 1, 1, '', 0, '*'),
(88, 'ZOO Comment', '', '', 0, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_zoocomment', 1, 1, '', 0, '*'),
(89, 'ZOO Item', '', '', 0, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_zooitem', 1, 1, '', 0, '*'),
(90, 'ZOO Quick Icons', '', '', 2, 'icon', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_zooquickicon', 1, 1, '', 1, '*'),
(91, 'ZOO Tag', '', '', 0, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_zootag', 1, 1, '', 0, '*'),
(92, 'Заказать демо', '', '', 1, 'demo-form', 643, '2014-07-21 09:41:45', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_foxcontact', 1, 1, '{"to_address":"dummy@address.com, another@address.com","cc_address":"","bcc_address":"","email_subject":"\\u0417\\u0430\\u044f\\u0432\\u043a\\u0430 \\u0441 \\u0432\\u0430\\u0448\\u0435\\u0433\\u043e \\u0441\\u0430\\u0439\\u0442\\u0430","jmessenger_user":"0","page_subheading":"\\u041f\\u043e\\u0436\\u0430\\u043b\\u0443\\u0439\\u0441\\u0442\\u0430, \\u0437\\u0430\\u043f\\u043e\\u043b\\u043d\\u0438\\u0442\\u0435 \\u0441\\u043b\\u0435\\u0434\\u0443\\u044e\\u0449\\u0443\\u044e \\u0444\\u043e\\u0440\\u043c\\u0443","form_width":"470","form_unit":"px","customhtml0":"\\u041f\\u043e\\u0441\\u043b\\u0435 \\u043e\\u0442\\u043f\\u0440\\u0430\\u0432\\u043a\\u0438 \\u0437\\u0430\\u043f\\u0440\\u043e\\u0441\\u0430 \\u043d\\u0430 \\u0412\\u0430\\u0448 email \\u0431\\u0443\\u0434\\u0443\\u0442 \\u0432\\u044b\\u0441\\u043b\\u0430\\u043d\\u044b \\u043b\\u043e\\u0433\\u0438\\u043d \\u0438 \\u043f\\u0430\\u0440\\u043e\\u043b\\u044c \\u0434\\u043b\\u044f \\u0434\\u043e\\u0441\\u0442\\u0443\\u043f\\u0430 \\u0432 \\u0430\\u0434\\u043c\\u0438\\u043d\\u0438\\u0441\\u0442\\u0440\\u0430\\u0442\\u0438\\u0432\\u043d\\u0443\\u044e \\u0447\\u0430\\u0441\\u0442\\u044c \\u0438 CRM \\u0434\\u0435\\u043c\\u043e\\u0441\\u0430\\u0439\\u0442\\u0430 <a href=\\"http:\\/\\/demo.printondemandsolution.ru\\">demo.printondemandsolution.ru<\\/a>","customhtml0display":"1","customhtml0order":"-1000","customhtml1":"","customhtml1display":"1","customhtml1order":"1000","labelsdisplay":"1","labelswidth":"100","labelsunit":"%","sender0":"\\u0412\\u0430\\u0448\\u0435 \\u0438\\u043c\\u044f","sender0display":"2","sender0order":"5","sender1":"E-mail","sender1display":"2","sender1order":"15","sender1isemail":"1","senderwidth":"100","senderunit":"%","text0":"\\u0422\\u0435\\u043b\\u0435\\u0444\\u043e\\u043d","text0display":"1","text0order":"10","text1":"","text1display":"0","text1order":"20","text2":"","text2display":"0","text2order":"25","text3":"","text3display":"0","text3order":"30","text4":"","text4display":"0","text4order":"35","text5":"","text5display":"0","text5order":"40","text6":"","text6display":"0","text6order":"45","text7":"","text7display":"0","text7order":"50","text8":"","text8display":"0","text8order":"55","text9":"","text9display":"0","text9order":"60","textwidth":"100","textunit":"%","dropdown0":"\\u041a\\u0430\\u043a \\u0432\\u044b \\u0443\\u0437\\u043d\\u0430\\u043b\\u0438 \\u043e \\u043d\\u0430\\u0441?","dropdown0display":"0","dropdown0values":"\\u041f\\u043e\\u0438\\u0441\\u043a \\u0432 \\u0438\\u043d\\u0442\\u0435\\u0440\\u043d\\u0435\\u0442\\u0435,\\u0420\\u0435\\u043a\\u043e\\u043c\\u0435\\u043d\\u0434\\u0430\\u0446\\u0438\\u0438 \\u0434\\u0440\\u0443\\u0433\\u0430,\\u041f\\u043e\\u043b\\u043e\\u0436\\u0438\\u0442\\u0435\\u043b\\u044c\\u043d\\u044b\\u0439 \\u043e\\u0442\\u0437\\u044b\\u0432 \\u0432 \\u0421\\u041c\\u0418","dropdown0order":"65","dropdown1":"","dropdown1display":"0","dropdown1values":"","dropdown1order":"70","dropdown2":"","dropdown2display":"0","dropdown2values":"","dropdown2order":"75","dropdownwidth":"85","dropdownunit":"%","textarea0":"\\u041e\\u043f\\u0438\\u0448\\u0438\\u0442\\u0435 \\u0432\\u0430\\u0448 \\u0437\\u0430\\u043f\\u0440\\u043e\\u0441","textarea0display":"0","textarea0order":"80","textarea1":"","textarea1display":"0","textarea1order":"85","textarea2":"","textarea2display":"0","textarea2order":"90","textareawidth":"85","textareaheight":"180","textareaunit":"%","checkbox0":"\\u042f \\u0441\\u043e\\u0433\\u043b\\u0430\\u0441\\u0435\\u043d \\u0441 \\u0432\\u0430\\u0448\\u0438\\u043c\\u0438 \\u043f\\u0440\\u0430\\u0432\\u0438\\u043b\\u0430\\u043c\\u0438 \\u0438 \\u0443\\u0441\\u043b\\u043e\\u0432\\u0438\\u044f\\u043c\\u0438","checkbox0display":"0","checkbox0order":"95","checkbox1":"","checkbox1display":"0","checkbox1order":"100","checkbox2":"","checkbox2display":"0","checkbox2order":"105","checkbox3":"","checkbox3display":"0","checkbox3order":"110","checkbox4":"","checkbox4display":"0","checkbox4order":"115","uploaddisplay":"0","uploadmethod":"1","upload":"\\u0412\\u044b\\u0431\\u0435\\u0440\\u0435\\u0442\\u0435 \\u0444\\u0430\\u0439\\u043b\\u044b \\u0434\\u043b\\u044f \\u043f\\u0440\\u0438\\u043a\\u0440\\u0435\\u043f\\u043b\\u0435\\u043d\\u0438\\u044f","uploadmax_file_size":"10000","submittext":"\\u041f\\u043e\\u043b\\u0443\\u0447\\u0438\\u0442\\u044c \\u0434\\u043e\\u0441\\u0442\\u0443\\u043f","submittype":"0","submiticon":"-1","resetbutton":"0","resettext":"\\u0421\\u0431\\u0440\\u043e\\u0441","resettype":"0","reseticon":"-1","email_sent_action":"0","email_sent_text":"\\u041c\\u044b \\u043f\\u043e\\u043b\\u0443\\u0447\\u0438\\u043b\\u0438 \\u0432\\u0430\\u0448\\u0435 \\u0441\\u043e\\u043e\\u0431\\u0449\\u0435\\u043d\\u0438\\u0435. \\u041c\\u044b \\u0441\\u0432\\u044f\\u0436\\u0435\\u043c\\u0441\\u044f \\u0441 \\u0432\\u0430\\u043c\\u0438 \\u0432 \\u0442\\u0435\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043d\\u0435\\u0441\\u043a\\u043e\\u043b\\u044c\\u043a\\u0438\\u0445 \\u0434\\u043d\\u0435\\u0439.","email_sent_textdisplay":"1","email_sent_page":"103","copy_to_submitter":"1","email_copy_subject":"\\u0421\\u043f\\u0430\\u0441\\u0438\\u0431\\u043e \\u0437\\u0430 \\u0432\\u0430\\u0448\\u0435 \\u043e\\u0431\\u0440\\u0430\\u0449\\u0435\\u043d\\u0438\\u0435 \\u043a \\u043d\\u0430\\u043c","email_copy_text":"\\u041c\\u044b \\u043f\\u043e\\u043b\\u0443\\u0447\\u0438\\u043b\\u0438 \\u0432\\u0430\\u0448\\u0435 \\u0441\\u043e\\u043e\\u0431\\u0449\\u0435\\u043d\\u0438\\u0435. \\u041c\\u044b \\u0441\\u0432\\u044f\\u0436\\u0435\\u043c\\u0441\\u044f \\u0441 \\u0432\\u0430\\u043c\\u0438 \\u0432 \\u0442\\u0435\\u0447\\u0435\\u043d\\u0438\\u0435 \\u043d\\u0435\\u0441\\u043a\\u043e\\u043b\\u044c\\u043a\\u0438\\u0445 \\u0434\\u043d\\u0435\\u0439.","email_copy_summary":"0","spam_check":"1","spam_words":"www,http,url=,href=,link=,.txt,shit,fuck","spam_detected_text":"\\u0418\\u0437\\u0432\\u0438\\u043d\\u0438\\u0442\\u0435, \\u043d\\u043e \\u0441\\u0438\\u0441\\u0442\\u0435\\u043c\\u0430 \\u0441\\u0447\\u0438\\u0442\\u0430\\u0435\\u0442, \\u0447\\u0442\\u043e \\u0432\\u0430\\u0448\\u0435 \\u0441\\u043e\\u043e\\u0431\\u0449\\u0435\\u043d\\u0438\\u0435 \\u0441\\u043e\\u0434\\u0435\\u0440\\u0436\\u0438\\u0442 \\u043d\\u0435\\u0436\\u0435\\u043b\\u0430\\u0442\\u0435\\u043b\\u044c\\u043d\\u0443\\u044e \\u0440\\u0435\\u043a\\u043b\\u0430\\u043c\\u0443, \\u043f\\u043e\\u044d\\u0442\\u043e\\u043c\\u0443 \\u043e\\u043d\\u043e <b>\\u0431\\u044b\\u043b\\u043e \\u0437\\u0430\\u0431\\u043b\\u043e\\u043a\\u0438\\u0440\\u043e\\u0432\\u0430\\u043d\\u043e<\\/b>.<br \\/>\\u0415\\u0441\\u043b\\u0438 \\u0432\\u044b \\u0441\\u0447\\u0438\\u0442\\u0430\\u0435\\u0442\\u0435, \\u0447\\u0442\\u043e \\u044d\\u0442\\u043e \\u043e\\u0448\\u0438\\u0431\\u043a\\u0430, \\u0442\\u043e, \\u043f\\u043e\\u0436\\u0430\\u043b\\u0443\\u0439\\u0441\\u0442\\u0430, \\u0432\\u0435\\u0440\\u043d\\u0438\\u0442\\u0435\\u0441\\u044c \\u0438 \\u043f\\u043e\\u043f\\u0440\\u043e\\u0431\\u0443\\u0439\\u0442\\u0435 \\u0435\\u0449\\u0451 \\u0440\\u0430\\u0437, \\u0438\\u0437\\u0431\\u0435\\u0433\\u0430\\u044f \\u0442\\u0430\\u043a\\u0438\\u0445 \\u0441\\u043b\\u043e\\u0432 \\u043a\\u0430\\u043a <i>www, http,<\\/i> \\u0438 \\u0442\\u0430\\u043a \\u0434\\u0430\\u043b\\u0435\\u0435.","spam_detected_textdisplay":"1","stdcaptchadisplay":"0","stdcaptcha":"\\u041a\\u043b\\u044e\\u0447 \\u0437\\u0430\\u0449\\u0438\\u0442\\u044b","stdcaptchatype":"0","stdcaptcha_length":"5","stdcaptchawidth":"150","stdcaptchaheight":"75","stdcaptchafont":"-1","stdcaptchafontmin":"14","stdcaptchafontmax":"20","stdcaptchaangle":"20","stdcaptcha_backgroundcolor":"#ffffff","stdcaptcha_textcolor":"#191919","stdcaptcha_disturbcolor":"#c8c8c8","layout":"_:default","stylesheet":"neon.css","moduleclass_sfx":"","acymailing":"0","acymailing_checkboxes":"hidden|hidden","acymailing_auto_checked":"0","jnews":"0","jnews_checkboxes":"hidden|hidden","jnews_auto_checked":"0","othernewsletters":"1"}', 0, '*');

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_modules_menu`
--

CREATE TABLE IF NOT EXISTS `sdc98_modules_menu` (
  `moduleid` int(11) NOT NULL DEFAULT '0',
  `menuid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`moduleid`,`menuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sdc98_modules_menu`
--

INSERT INTO `sdc98_modules_menu` (`moduleid`, `menuid`) VALUES
(1, 0),
(2, 0),
(3, 0),
(4, 0),
(6, 0),
(7, 0),
(8, 0),
(9, 0),
(10, 0),
(12, 0),
(13, 0),
(14, 0),
(15, 0),
(16, 0),
(17, 0),
(79, 0),
(86, 0),
(90, 0),
(92, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_newsfeeds`
--

CREATE TABLE IF NOT EXISTS `sdc98_newsfeeds` (
  `catid` int(11) NOT NULL DEFAULT '0',
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `link` varchar(200) NOT NULL DEFAULT '',
  `filename` varchar(200) DEFAULT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `numarticles` int(10) unsigned NOT NULL DEFAULT '1',
  `cache_time` int(10) unsigned NOT NULL DEFAULT '3600',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `rtl` tinyint(4) NOT NULL DEFAULT '0',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `language` char(7) NOT NULL DEFAULT '',
  `params` text NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `metadata` text NOT NULL,
  `xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`published`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_overrider`
--

CREATE TABLE IF NOT EXISTS `sdc98_overrider` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `constant` varchar(255) NOT NULL,
  `string` text NOT NULL,
  `file` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_redirect_links`
--

CREATE TABLE IF NOT EXISTS `sdc98_redirect_links` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `old_url` varchar(255) NOT NULL,
  `new_url` varchar(255) NOT NULL,
  `referer` varchar(150) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `published` tinyint(4) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_link_old` (`old_url`),
  KEY `idx_link_modifed` (`modified_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_schemas`
--

CREATE TABLE IF NOT EXISTS `sdc98_schemas` (
  `extension_id` int(11) NOT NULL,
  `version_id` varchar(20) NOT NULL,
  PRIMARY KEY (`extension_id`,`version_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sdc98_schemas`
--

INSERT INTO `sdc98_schemas` (`extension_id`, `version_id`) VALUES
(700, '2.5.22'),
(10014, '1.9.0');

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_session`
--

CREATE TABLE IF NOT EXISTS `sdc98_session` (
  `session_id` varchar(200) NOT NULL DEFAULT '',
  `client_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `guest` tinyint(4) unsigned DEFAULT '1',
  `time` varchar(14) DEFAULT '',
  `data` mediumtext,
  `userid` int(11) DEFAULT '0',
  `username` varchar(150) DEFAULT '',
  `usertype` varchar(50) DEFAULT '',
  PRIMARY KEY (`session_id`),
  KEY `whosonline` (`guest`,`usertype`),
  KEY `userid` (`userid`),
  KEY `time` (`time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sdc98_session`
--

INSERT INTO `sdc98_session` (`session_id`, `client_id`, `guest`, `time`, `data`, `userid`, `username`, `usertype`) VALUES
('blaetc9fdus6t4vg58prgq2tb5', 0, 1, '1405935622', '__default|a:7:{s:15:"session.counter";i:17;s:19:"session.timer.start";i:1405926423;s:18:"session.timer.last";i:1405935620;s:17:"session.timer.now";i:1405935622;s:22:"session.client.browser";s:102:"Mozilla/5.0 (Windows NT 6.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36";s:8:"registry";O:9:"JRegistry":1:{s:7:"\0*\0data";O:8:"stdClass":0:{}}s:4:"user";O:5:"JUser":26:{s:9:"\0*\0isRoot";b:0;s:2:"id";i:0;s:4:"name";N;s:8:"username";N;s:5:"email";N;s:8:"password";N;s:14:"password_clear";s:0:"";s:8:"usertype";N;s:5:"block";N;s:9:"sendEmail";i:0;s:12:"registerDate";N;s:13:"lastvisitDate";N;s:10:"activation";N;s:6:"params";N;s:6:"groups";a:0:{}s:5:"guest";i:1;s:13:"lastResetTime";N;s:10:"resetCount";N;s:10:"\0*\0_params";O:9:"JRegistry":1:{s:7:"\0*\0data";O:8:"stdClass":0:{}}s:14:"\0*\0_authGroups";a:1:{i:0;i:1;}s:14:"\0*\0_authLevels";a:2:{i:0;i:1;i:1;i:1;}s:15:"\0*\0_authActions";N;s:12:"\0*\0_errorMsg";N;s:10:"\0*\0_errors";a:0:{}s:3:"aid";i:0;s:10:"superadmin";N;}}', 0, '', ''),
('oeltgei8ddg27brcmphs4qn6b6', 1, 0, '1405935708', '__default|a:8:{s:15:"session.counter";i:71;s:19:"session.timer.start";i:1405926472;s:18:"session.timer.last";i:1405935704;s:17:"session.timer.now";i:1405935706;s:22:"session.client.browser";s:102:"Mozilla/5.0 (Windows NT 6.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36";s:8:"registry";O:9:"JRegistry":1:{s:7:"\0*\0data";O:8:"stdClass":4:{s:11:"application";O:8:"stdClass":1:{s:4:"lang";s:0:"";}s:13:"com_installer";O:8:"stdClass":3:{s:7:"message";s:0:"";s:17:"extension_message";s:0:"";s:12:"redirect_url";N;}s:18:"com_zooapplication";i:1;s:11:"com_modules";O:8:"stdClass":3:{s:7:"modules";O:8:"stdClass":1:{s:6:"filter";O:8:"stdClass":1:{s:18:"client_id_previous";i:0;}}s:4:"edit";O:8:"stdClass":1:{s:6:"module";O:8:"stdClass":2:{s:4:"data";N;s:2:"id";a:1:{i:0;i:92;}}}s:3:"add";O:8:"stdClass":1:{s:6:"module";O:8:"stdClass":2:{s:12:"extension_id";N;s:6:"params";N;}}}}}s:4:"user";O:5:"JUser":26:{s:9:"\0*\0isRoot";b:1;s:2:"id";s:3:"643";s:4:"name";s:10:"Super User";s:8:"username";s:5:"admin";s:5:"email";s:11:"asd@asd.com";s:8:"password";s:34:"$P$DgTuaj7OFuuLKGiqg9c/Nmu.uvs/kQ/";s:14:"password_clear";s:0:"";s:8:"usertype";s:10:"deprecated";s:5:"block";s:1:"0";s:9:"sendEmail";s:1:"1";s:12:"registerDate";s:19:"2014-07-17 12:42:54";s:13:"lastvisitDate";s:19:"2014-07-18 13:14:43";s:10:"activation";s:1:"0";s:6:"params";s:0:"";s:6:"groups";a:1:{i:8;s:1:"8";}s:5:"guest";i:0;s:13:"lastResetTime";s:19:"0000-00-00 00:00:00";s:10:"resetCount";s:1:"0";s:10:"\0*\0_params";O:9:"JRegistry":1:{s:7:"\0*\0data";O:8:"stdClass":0:{}}s:14:"\0*\0_authGroups";a:2:{i:0;i:1;i:1;i:8;}s:14:"\0*\0_authLevels";a:4:{i:0;i:1;i:1;i:1;i:2;i:2;i:3;i:3;}s:15:"\0*\0_authActions";N;s:12:"\0*\0_errorMsg";N;s:10:"\0*\0_errors";a:0:{}s:3:"aid";i:0;s:10:"superadmin";b:1;}s:13:"session.token";s:32:"3a00a754e59e55494260834bba89c927";}', 643, 'admin', '');

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_template_styles`
--

CREATE TABLE IF NOT EXISTS `sdc98_template_styles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `template` varchar(50) NOT NULL DEFAULT '',
  `client_id` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `home` char(7) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_template` (`template`),
  KEY `idx_home` (`home`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Дамп данных таблицы `sdc98_template_styles`
--

INSERT INTO `sdc98_template_styles` (`id`, `template`, `client_id`, `home`, `title`, `params`) VALUES
(2, 'bluestork', 1, '1', 'Bluestork - Default', '{"useRoundedCorners":"1","showSiteName":"0"}'),
(3, 'atomic', 0, '0', 'Atomic - Default', '{}'),
(4, 'beez_20', 0, '0', 'Beez2 - Default', '{"wrapperSmall":"53","wrapperLarge":"72","logo":"images\\/joomla_black.gif","sitetitle":"Joomla!","sitedescription":"Open Source Content Management","navposition":"left","templatecolor":"personal","html5":"0"}'),
(5, 'hathor', 1, '0', 'Hathor - Default', '{"showSiteName":"0","colourChoice":"","boldText":"0"}'),
(6, 'beez5', 0, '0', 'Beez5 - Default', '{"wrapperSmall":"53","wrapperLarge":"72","logo":"images\\/sampledata\\/fruitshop\\/fruits.gif","sitetitle":"Joomla!","sitedescription":"Open Source Content Management","navposition":"left","html5":"0"}'),
(7, 'printsolution', 0, '1', 'printsolution - По умолчанию', '{}');

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_updates`
--

CREATE TABLE IF NOT EXISTS `sdc98_updates` (
  `update_id` int(11) NOT NULL AUTO_INCREMENT,
  `update_site_id` int(11) DEFAULT '0',
  `extension_id` int(11) DEFAULT '0',
  `categoryid` int(11) DEFAULT '0',
  `name` varchar(100) DEFAULT '',
  `description` text NOT NULL,
  `element` varchar(100) DEFAULT '',
  `type` varchar(20) DEFAULT '',
  `folder` varchar(20) DEFAULT '',
  `client_id` tinyint(3) DEFAULT '0',
  `version` varchar(10) DEFAULT '',
  `data` text NOT NULL,
  `detailsurl` text NOT NULL,
  `infourl` text NOT NULL,
  PRIMARY KEY (`update_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Available Updates' AUTO_INCREMENT=64 ;

--
-- Дамп данных таблицы `sdc98_updates`
--

INSERT INTO `sdc98_updates` (`update_id`, `update_site_id`, `extension_id`, `categoryid`, `name`, `description`, `element`, `type`, `folder`, `client_id`, `version`, `data`, `detailsurl`, `infourl`) VALUES
(2, 3, 0, 0, 'Armenian', '', 'pkg_hy-AM', 'package', '', 0, '2.5.8.1', '', 'http://update.joomla.org/language/details/hy-AM_details.xml', ''),
(3, 3, 0, 0, 'Bahasa Indonesia', '', 'pkg_id-ID', 'package', '', 0, '2.5.20.1', '', 'http://update.joomla.org/language/details/id-ID_details.xml', ''),
(4, 3, 0, 0, 'Danish', '', 'pkg_da-DK', 'package', '', 0, '2.5.20.1', '', 'http://update.joomla.org/language/details/da-DK_details.xml', ''),
(5, 3, 0, 0, 'Khmer', '', 'pkg_km-KH', 'package', '', 0, '2.5.7.1', '', 'http://update.joomla.org/language/details/km-KH_details.xml', ''),
(6, 3, 0, 0, 'Swedish', '', 'pkg_sv-SE', 'package', '', 0, '2.5.10.1', '', 'http://update.joomla.org/language/details/sv-SE_details.xml', ''),
(7, 3, 0, 0, 'Hungarian', '', 'pkg_hu-HU', 'package', '', 0, '2.5.14.1', '', 'http://update.joomla.org/language/details/hu-HU_details.xml', ''),
(8, 3, 0, 0, 'Bulgarian', '', 'pkg_bg-BG', 'package', '', 0, '2.5.7.1', '', 'http://update.joomla.org/language/details/bg-BG_details.xml', ''),
(9, 3, 0, 0, 'French', '', 'pkg_fr-FR', 'package', '', 0, '2.5.22.1', '', 'http://update.joomla.org/language/details/fr-FR_details.xml', ''),
(10, 3, 0, 0, 'Italian', '', 'pkg_it-IT', 'package', '', 0, '2.5.22.1', '', 'http://update.joomla.org/language/details/it-IT_details.xml', ''),
(11, 3, 0, 0, 'Spanish', '', 'pkg_es-ES', 'package', '', 0, '2.5.20.1', '', 'http://update.joomla.org/language/details/es-ES_details.xml', ''),
(12, 3, 0, 0, 'Dutch', '', 'pkg_nl-NL', 'package', '', 0, '2.5.22.1', '', 'http://update.joomla.org/language/details/nl-NL_details.xml', ''),
(13, 3, 0, 0, 'Turkish', '', 'pkg_tr-TR', 'package', '', 0, '2.5.20.1', '', 'http://update.joomla.org/language/details/tr-TR_details.xml', ''),
(14, 3, 0, 0, 'Ukrainian', '', 'pkg_uk-UA', 'package', '', 0, '2.5.13.11', '', 'http://update.joomla.org/language/details/uk-UA_details.xml', ''),
(15, 3, 0, 0, 'Slovak', '', 'pkg_sk-SK', 'package', '', 0, '2.5.22.1', '', 'http://update.joomla.org/language/details/sk-SK_details.xml', ''),
(16, 3, 0, 0, 'Belarusian', '', 'pkg_be-BY', 'package', '', 0, '2.5.8.1', '', 'http://update.joomla.org/language/details/be-BY_details.xml', ''),
(17, 3, 0, 0, 'Latvian', '', 'pkg_lv-LV', 'package', '', 0, '2.5.22.1', '', 'http://update.joomla.org/language/details/lv-LV_details.xml', ''),
(18, 3, 0, 0, 'Estonian', '', 'pkg_et-EE', 'package', '', 0, '2.5.21.1', '', 'http://update.joomla.org/language/details/et-EE_details.xml', ''),
(19, 3, 0, 0, 'Romanian', '', 'pkg_ro-RO', 'package', '', 0, '2.5.11.1', '', 'http://update.joomla.org/language/details/ro-RO_details.xml', ''),
(20, 3, 0, 0, 'Flemish', '', 'pkg_nl-BE', 'package', '', 0, '2.5.22.1', '', 'http://update.joomla.org/language/details/nl-BE_details.xml', ''),
(21, 3, 0, 0, 'Macedonian', '', 'pkg_mk-MK', 'package', '', 0, '2.5.20.1', '', 'http://update.joomla.org/language/details/mk-MK_details.xml', ''),
(22, 3, 0, 0, 'Japanese', '', 'pkg_ja-JP', 'package', '', 0, '2.5.22.1', '', 'http://update.joomla.org/language/details/ja-JP_details.xml', ''),
(23, 3, 0, 0, 'Serbian Latin', '', 'pkg_sr-YU', 'package', '', 0, '2.5.20.1', '', 'http://update.joomla.org/language/details/sr-YU_details.xml', ''),
(24, 3, 0, 0, 'Arabic Unitag', '', 'pkg_ar-AA', 'package', '', 0, '2.5.21.1', '', 'http://update.joomla.org/language/details/ar-AA_details.xml', ''),
(25, 3, 0, 0, 'German', '', 'pkg_de-DE', 'package', '', 0, '2.5.22.1', '', 'http://update.joomla.org/language/details/de-DE_details.xml', ''),
(26, 3, 0, 0, 'Norwegian Bokmal', '', 'pkg_nb-NO', 'package', '', 0, '2.5.16.1', '', 'http://update.joomla.org/language/details/nb-NO_details.xml', ''),
(27, 3, 0, 0, 'English AU', '', 'pkg_en-AU', 'package', '', 0, '2.5.22.1', '', 'http://update.joomla.org/language/details/en-AU_details.xml', ''),
(28, 3, 0, 0, 'English US', '', 'pkg_en-US', 'package', '', 0, '2.5.22.1', '', 'http://update.joomla.org/language/details/en-US_details.xml', ''),
(29, 3, 0, 0, 'Serbian Cyrillic', '', 'pkg_sr-RS', 'package', '', 0, '2.5.20.1', '', 'http://update.joomla.org/language/details/sr-RS_details.xml', ''),
(30, 3, 0, 0, 'Lithuanian', '', 'pkg_lt-LT', 'package', '', 0, '2.5.7.1', '', 'http://update.joomla.org/language/details/lt-LT_details.xml', ''),
(31, 3, 0, 0, 'Albanian', '', 'pkg_sq-AL', 'package', '', 0, '2.5.1.5', '', 'http://update.joomla.org/language/details/sq-AL_details.xml', ''),
(32, 3, 0, 0, 'Czech', '', 'pkg_cs-CZ', 'package', '', 0, '2.5.22.1', '', 'http://update.joomla.org/language/details/cs-CZ_details.xml', ''),
(33, 3, 0, 0, 'Persian', '', 'pkg_fa-IR', 'package', '', 0, '2.5.22.1', '', 'http://update.joomla.org/language/details/fa-IR_details.xml', ''),
(34, 3, 0, 0, 'Galician', '', 'pkg_gl-ES', 'package', '', 0, '2.5.7.4', '', 'http://update.joomla.org/language/details/gl-ES_details.xml', ''),
(35, 3, 0, 0, 'Polish', '', 'pkg_pl-PL', 'package', '', 0, '2.5.22.1', '', 'http://update.joomla.org/language/details/pl-PL_details.xml', ''),
(36, 3, 0, 0, 'Syriac', '', 'pkg_sy-IQ', 'package', '', 0, '2.5.19.1', '', 'http://update.joomla.org/language/details/sy-IQ_details.xml', ''),
(37, 3, 0, 0, 'Portuguese', '', 'pkg_pt-PT', 'package', '', 0, '2.5.8.1', '', 'http://update.joomla.org/language/details/pt-PT_details.xml', ''),
(38, 3, 0, 0, 'Russian', '', 'pkg_ru-RU', 'package', '', 0, '2.5.22.1', '', 'http://update.joomla.org/language/details/ru-RU_details.xml', ''),
(39, 3, 0, 0, 'Hebrew', '', 'pkg_he-IL', 'package', '', 0, '2.5.7.1', '', 'http://update.joomla.org/language/details/he-IL_details.xml', ''),
(40, 3, 0, 0, 'Catalan', '', 'pkg_ca-ES', 'package', '', 0, '2.5.21.1', '', 'http://update.joomla.org/language/details/ca-ES_details.xml', ''),
(41, 3, 0, 0, 'Laotian', '', 'pkg_lo-LA', 'package', '', 0, '2.5.6.1', '', 'http://update.joomla.org/language/details/lo-LA_details.xml', ''),
(42, 3, 0, 0, 'Afrikaans', '', 'pkg_af-ZA', 'package', '', 0, '2.5.16.1', '', 'http://update.joomla.org/language/details/af-ZA_details.xml', ''),
(43, 3, 0, 0, 'Chinese Simplified', '', 'pkg_zh-CN', 'package', '', 0, '2.5.20.1', '', 'http://update.joomla.org/language/details/zh-CN_details.xml', ''),
(44, 3, 0, 0, 'Greek', '', 'pkg_el-GR', 'package', '', 0, '2.5.6.1', '', 'http://update.joomla.org/language/details/el-GR_details.xml', ''),
(45, 3, 0, 0, 'Finnish', '', 'pkg_fi-FI', 'package', '', 0, '2.5.20.1', '', 'http://update.joomla.org/language/details/fi-FI_details.xml', ''),
(46, 3, 0, 0, 'Portuguese Brazil', '', 'pkg_pt-BR', 'package', '', 0, '2.5.9.1', '', 'http://update.joomla.org/language/details/pt-BR_details.xml', ''),
(47, 3, 0, 0, 'Chinese Traditional', '', 'pkg_zh-TW', 'package', '', 0, '2.5.19.1', '', 'http://update.joomla.org/language/details/zh-TW_details.xml', ''),
(48, 3, 0, 0, 'Vietnamese', '', 'pkg_vi-VN', 'package', '', 0, '2.5.8.1', '', 'http://update.joomla.org/language/details/vi-VN_details.xml', ''),
(49, 3, 0, 0, 'Kurdish Sorani', '', 'pkg_ckb-IQ', 'package', '', 0, '2.5.9.1', '', 'http://update.joomla.org/language/details/ckb-IQ_details.xml', ''),
(50, 3, 0, 0, 'Bengali', '', 'pkg_bn-BD', 'package', '', 0, '2.5.0.1', '', 'http://update.joomla.org/language/details/bn-BD_details.xml', ''),
(51, 3, 0, 0, 'Bosnian', '', 'pkg_bs-BA', 'package', '', 0, '2.5.22.1', '', 'http://update.joomla.org/language/details/bs-BA_details.xml', ''),
(52, 3, 0, 0, 'Croatian', '', 'pkg_hr-HR', 'package', '', 0, '2.5.13.1', '', 'http://update.joomla.org/language/details/hr-HR_details.xml', ''),
(53, 3, 0, 0, 'Azeri', '', 'pkg_az-AZ', 'package', '', 0, '2.5.7.1', '', 'http://update.joomla.org/language/details/az-AZ_details.xml', ''),
(54, 3, 0, 0, 'Norwegian Nynorsk', '', 'pkg_nn-NO', 'package', '', 0, '2.5.8.1', '', 'http://update.joomla.org/language/details/nn-NO_details.xml', ''),
(55, 3, 0, 0, 'Tamil India', '', 'pkg_ta-IN', 'package', '', 0, '2.5.22.1', '', 'http://update.joomla.org/language/details/ta-IN_details.xml', ''),
(56, 3, 0, 0, 'Scottish Gaelic', '', 'pkg_gd-GB', 'package', '', 0, '2.5.7.1', '', 'http://update.joomla.org/language/details/gd-GB_details.xml', ''),
(57, 3, 0, 0, 'Thai', '', 'pkg_th-TH', 'package', '', 0, '2.5.21.1', '', 'http://update.joomla.org/language/details/th-TH_details.xml', ''),
(58, 3, 0, 0, 'Basque', '', 'pkg_eu-ES', 'package', '', 0, '1.7.0.1', '', 'http://update.joomla.org/language/details/eu-ES_details.xml', ''),
(59, 3, 0, 0, 'Uyghur', '', 'pkg_ug-CN', 'package', '', 0, '2.5.7.2', '', 'http://update.joomla.org/language/details/ug-CN_details.xml', ''),
(60, 3, 0, 0, 'Korean', '', 'pkg_ko-KR', 'package', '', 0, '2.5.11.1', '', 'http://update.joomla.org/language/details/ko-KR_details.xml', ''),
(61, 3, 0, 0, 'Hindi', '', 'pkg_hi-IN', 'package', '', 0, '2.5.6.1', '', 'http://update.joomla.org/language/details/hi-IN_details.xml', ''),
(62, 3, 0, 0, 'Welsh', '', 'pkg_cy-GB', 'package', '', 0, '2.5.6.1', '', 'http://update.joomla.org/language/details/cy-GB_details.xml', ''),
(63, 3, 0, 0, 'Swahili', '', 'pkg_sw-KE', 'package', '', 0, '2.5.21.1', '', 'http://update.joomla.org/language/details/sw-KE_details.xml', '');

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_update_categories`
--

CREATE TABLE IF NOT EXISTS `sdc98_update_categories` (
  `categoryid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT '',
  `description` text NOT NULL,
  `parent` int(11) DEFAULT '0',
  `updatesite` int(11) DEFAULT '0',
  PRIMARY KEY (`categoryid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Update Categories' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_update_sites`
--

CREATE TABLE IF NOT EXISTS `sdc98_update_sites` (
  `update_site_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT '',
  `type` varchar(20) DEFAULT '',
  `location` text NOT NULL,
  `enabled` int(11) DEFAULT '0',
  `last_check_timestamp` bigint(20) DEFAULT '0',
  PRIMARY KEY (`update_site_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Update Sites' AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `sdc98_update_sites`
--

INSERT INTO `sdc98_update_sites` (`update_site_id`, `name`, `type`, `location`, `enabled`, `last_check_timestamp`) VALUES
(1, 'Joomla Core', 'collection', 'http://update.joomla.org/core/list.xml', 1, 1405926517),
(2, 'Joomla Extension Directory', 'collection', 'http://update.joomla.org/jed/list.xml', 1, 1405926518),
(3, 'Accredited Joomla! Translations', 'collection', 'http://update.joomla.org/language/translationlist.xml', 1, 1405926518),
(4, 'Foxcontact update site', 'extension', 'http://www.fox.ra.it/phocadownload/foxcontact.xml', 1, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_update_sites_extensions`
--

CREATE TABLE IF NOT EXISTS `sdc98_update_sites_extensions` (
  `update_site_id` int(11) NOT NULL DEFAULT '0',
  `extension_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`update_site_id`,`extension_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Links extensions to update sites';

--
-- Дамп данных таблицы `sdc98_update_sites_extensions`
--

INSERT INTO `sdc98_update_sites_extensions` (`update_site_id`, `extension_id`) VALUES
(1, 700),
(2, 700),
(3, 600),
(4, 10014);

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_usergroups`
--

CREATE TABLE IF NOT EXISTS `sdc98_usergroups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Adjacency List Reference Id',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `title` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_usergroup_parent_title_lookup` (`parent_id`,`title`),
  KEY `idx_usergroup_title_lookup` (`title`),
  KEY `idx_usergroup_adjacency_lookup` (`parent_id`),
  KEY `idx_usergroup_nested_set_lookup` (`lft`,`rgt`) USING BTREE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Дамп данных таблицы `sdc98_usergroups`
--

INSERT INTO `sdc98_usergroups` (`id`, `parent_id`, `lft`, `rgt`, `title`) VALUES
(1, 0, 1, 20, 'Public'),
(2, 1, 6, 17, 'Registered'),
(3, 2, 7, 14, 'Author'),
(4, 3, 8, 11, 'Editor'),
(5, 4, 9, 10, 'Publisher'),
(6, 1, 2, 5, 'Manager'),
(7, 6, 3, 4, 'Administrator'),
(8, 1, 18, 19, 'Super Users');

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_users`
--

CREATE TABLE IF NOT EXISTS `sdc98_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(150) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `password` varchar(100) NOT NULL DEFAULT '',
  `usertype` varchar(25) NOT NULL DEFAULT '',
  `block` tinyint(4) NOT NULL DEFAULT '0',
  `sendEmail` tinyint(4) DEFAULT '0',
  `registerDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lastvisitDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `activation` varchar(100) NOT NULL DEFAULT '',
  `params` text NOT NULL,
  `lastResetTime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Date of last password reset',
  `resetCount` int(11) NOT NULL DEFAULT '0' COMMENT 'Count of password resets since lastResetTime',
  PRIMARY KEY (`id`),
  KEY `usertype` (`usertype`),
  KEY `idx_name` (`name`),
  KEY `idx_block` (`block`),
  KEY `username` (`username`),
  KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=644 ;

--
-- Дамп данных таблицы `sdc98_users`
--

INSERT INTO `sdc98_users` (`id`, `name`, `username`, `email`, `password`, `usertype`, `block`, `sendEmail`, `registerDate`, `lastvisitDate`, `activation`, `params`, `lastResetTime`, `resetCount`) VALUES
(643, 'Super User', 'admin', 'asd@asd.com', '$P$DgTuaj7OFuuLKGiqg9c/Nmu.uvs/kQ/', 'deprecated', 0, 1, '2014-07-17 12:42:54', '2014-07-21 07:08:30', '0', '', '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_user_notes`
--

CREATE TABLE IF NOT EXISTS `sdc98_user_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `subject` varchar(100) NOT NULL DEFAULT '',
  `body` text NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_user_id` int(10) unsigned NOT NULL,
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `review_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_category_id` (`catid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_user_profiles`
--

CREATE TABLE IF NOT EXISTS `sdc98_user_profiles` (
  `user_id` int(11) NOT NULL,
  `profile_key` varchar(100) NOT NULL,
  `profile_value` varchar(255) NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `idx_user_id_profile_key` (`user_id`,`profile_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Simple user profile storage table';

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_user_usergroup_map`
--

CREATE TABLE IF NOT EXISTS `sdc98_user_usergroup_map` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Foreign Key to #__users.id',
  `group_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Foreign Key to #__usergroups.id',
  PRIMARY KEY (`user_id`,`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sdc98_user_usergroup_map`
--

INSERT INTO `sdc98_user_usergroup_map` (`user_id`, `group_id`) VALUES
(643, 8);

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_viewlevels`
--

CREATE TABLE IF NOT EXISTS `sdc98_viewlevels` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `title` varchar(100) NOT NULL DEFAULT '',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `rules` varchar(5120) NOT NULL COMMENT 'JSON encoded access control.',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_assetgroup_title_lookup` (`title`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `sdc98_viewlevels`
--

INSERT INTO `sdc98_viewlevels` (`id`, `title`, `ordering`, `rules`) VALUES
(1, 'Public', 0, '[1]'),
(2, 'Registered', 1, '[6,2,8]'),
(3, 'Special', 2, '[6,3,8]');

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_weblinks`
--

CREATE TABLE IF NOT EXISTS `sdc98_weblinks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(11) NOT NULL DEFAULT '0',
  `sid` int(11) NOT NULL DEFAULT '0',
  `title` varchar(250) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `url` varchar(250) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `hits` int(11) NOT NULL DEFAULT '0',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '1',
  `access` int(11) NOT NULL DEFAULT '1',
  `params` text NOT NULL,
  `language` char(7) NOT NULL DEFAULT '',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `metadata` text NOT NULL,
  `featured` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Set if link is featured.',
  `xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`state`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_featured_catid` (`featured`,`catid`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_zoo_application`
--

CREATE TABLE IF NOT EXISTS `sdc98_zoo_application` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `application_group` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `sdc98_zoo_application`
--

INSERT INTO `sdc98_zoo_application` (`id`, `name`, `alias`, `application_group`, `description`, `params`) VALUES
(1, 'Продукты', 'produkty', 'jbuniversal', '', ' {\n	"group": "jbuniversal",\n	"template": "catalog",\n	"global.config.yoo_support": "0",\n	"global.config.rborder": "0",\n	"global.config.column_heightfix": "0",\n	"global.config.wrap_item_style": "div",\n	"global.config.category_image_height": "150",\n	"global.config.category_image_width": "150",\n	"global.config.show_feed_link": "0",\n	"global.config.feed_title": "",\n	"global.config.alternate_feed_link": "",\n	"global.config.category_teaser_image_height": "50",\n	"global.config.category_teaser_image_width": "50",\n	"global.config.items_per_page": "20",\n	"global.config.item_order":  {\n		"0": "_itemname",\n		"1": "",\n		"2": "",\n		"3": "",\n		"4": "",\n		"5": "",\n		"6": "",\n		"7": "",\n		"8": "",\n		"9": "",\n		"10": "",\n		"11": "",\n		"12": ""\n	},\n	"global.config.alpha_index": "0",\n	"global.config.alpha_chars": "0",\n	"global.config.layout_frontpage": "__auto__",\n	"global.config.layout_category": "__auto__",\n	"global.config.layout_subcategory": "__auto__",\n	"global.config.layout_subcategory_columns": "__auto__",\n	"global.config.layout_subcategories": "__auto__",\n	"global.config.layout_items": "__auto__",\n	"global.config.layout_item_columns": "__auto__",\n	"global.config.layout_alphaindex": "__auto__",\n	"global.config.layout_pagination": "__auto__",\n	"global.config.layout_tag": "__auto__",\n	"global.config.layout_comments": "__auto__",\n	"global.config.layout_comment": "__auto__",\n	"global.config.layout_respond": "__auto__",\n	"global.config.layout_mysubmissions": "__auto__",\n	"global.config.layout_administration": "__auto__",\n	"global.config.layout_submission": "__auto__",\n	"global.config.lastmodified": "1405666871",\n	"global.template.show_alpha_index": "0",\n	"global.template.category_show": "1",\n	"global.template.category_subtitle": "1",\n	"global.template.category_teaser_text": "1",\n	"global.template.category_image": "1",\n	"global.template.category_image_align": "left",\n	"global.template.category_text": "1",\n	"global.template.subcategory_show": "1",\n	"global.template.subcategory_teaser_text": "1",\n	"global.template.subcategory_teaser_image": "1",\n	"global.template.subcategory_teaser_image_align": "left",\n	"global.template.subcategory_empty": "1",\n	"global.template.subcategory_cols": "1",\n	"global.template.subcategory_order": "0",\n	"global.template.subcategory_items_count_show": "1",\n	"global.template.subcategory_items_count": "5",\n	"global.template.item_cols": "1",\n	"global.template.item_order": "0",\n	"global.template.item_pagination": "1",\n	"global.template.lastmodified": "1405666871",\n	"global.template.item_full_image_align": "left",\n	"global.template.item_teaser_image_align": "left",\n	"global.template.item_related_image_align": "left",\n	"global.template.item_subcategory_item_image_align": "left",\n	"global.jbzoo_cart_config.enable": "0",\n	"global.jbzoo_cart_config.auth": "0",\n	"global.jbzoo_cart_config.submission-id": "",\n	"global.jbzoo_cart_config.type-layout": "",\n	"global.jbzoo_cart_config.currency": "RUB",\n	"global.jbzoo_cart_config.admin-email": "",\n	"global.jbzoo_cart_config.email-admin-layout": "",\n	"global.jbzoo_cart_config.email-user-layout": "",\n	"global.jbzoo_cart_config.element-image": "791f1142-2344-40f3-a136-bf3c0d00a2ae",\n	"global.jbzoo_cart_config.nopaid-order": "0",\n	"global.jbzoo_cart_config.payment-enabled": "0",\n	"global.jbzoo_cart_config.robox-enabled": "0",\n	"global.jbzoo_cart_config.robox-debug": "0",\n	"global.jbzoo_cart_config.robox-login": "",\n	"global.jbzoo_cart_config.robox-password1": "",\n	"global.jbzoo_cart_config.robox-password2": "",\n	"global.jbzoo_cart_config.ikassa-enabled": "0",\n	"global.jbzoo_cart_config.ikassa-shopid": "",\n	"global.jbzoo_cart_config.ikassa-key": "",\n	"global.comments.enable_comments": "0",\n	"global.comments.require_name_and_mail": "0",\n	"global.comments.registered_users_only": "0",\n	"global.comments.approved": "0",\n	"global.comments.time_between_user_posts": "120",\n	"global.comments.email_notification": "",\n	"global.comments.email_reply_notification": "0",\n	"global.comments.avatar": "1",\n	"global.comments.order": "ASC",\n	"global.comments.max_depth": "5",\n	"global.comments.facebook_enable": "0",\n	"global.comments.facebook_app_id": "",\n	"global.comments.facebook_app_secret": "",\n	"global.comments.twitter_enable": "0",\n	"global.comments.twitter_consumer_key": "",\n	"global.comments.twitter_consumer_secret": "",\n	"global.comments.akismet_enable": "0",\n	"global.comments.akismet_api_key": "",\n	"global.comments.mollom_enable": "0",\n	"global.comments.mollom_public_key": "",\n	"global.comments.mollom_private_key": "",\n	"global.comments.blacklist": ""\n}');

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_zoo_category`
--

CREATE TABLE IF NOT EXISTS `sdc98_zoo_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `application_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `parent` int(11) NOT NULL,
  `ordering` int(11) NOT NULL,
  `published` tinyint(1) NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ALIAS_INDEX` (`alias`),
  KEY `PUBLISHED_INDEX` (`published`),
  KEY `APPLICATIONID_ID_INDEX` (`application_id`,`published`,`id`),
  KEY `APPLICATIONID_ID_INDEX2` (`application_id`,`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_zoo_category_item`
--

CREATE TABLE IF NOT EXISTS `sdc98_zoo_category_item` (
  `category_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  PRIMARY KEY (`category_id`,`item_id`),
  KEY `ITEMID_INDEX` (`item_id`),
  KEY `CATEGORYID_INDEX` (`category_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_zoo_comment`
--

CREATE TABLE IF NOT EXISTS `sdc98_zoo_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `user_type` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `content` text NOT NULL,
  `state` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `STATE_INDEX` (`state`),
  KEY `CREATED_INDEX` (`created`),
  KEY `ITEMID_INDEX` (`item_id`),
  KEY `AUTHOR_INDEX` (`author`),
  KEY `ITEMID_STATE_INDEX` (`item_id`,`state`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_zoo_item`
--

CREATE TABLE IF NOT EXISTS `sdc98_zoo_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `application_id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `modified_by` int(11) NOT NULL,
  `publish_up` datetime NOT NULL,
  `publish_down` datetime NOT NULL,
  `priority` int(11) NOT NULL,
  `hits` int(11) NOT NULL,
  `state` tinyint(3) NOT NULL,
  `access` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_by_alias` varchar(255) NOT NULL,
  `searchable` int(11) NOT NULL,
  `elements` longtext NOT NULL,
  `params` longtext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ALIAS_INDEX` (`alias`),
  KEY `PUBLISH_INDEX` (`publish_up`,`publish_down`),
  KEY `STATE_INDEX` (`state`),
  KEY `ACCESS_INDEX` (`access`),
  KEY `CREATED_BY_INDEX` (`created_by`),
  KEY `NAME_INDEX` (`name`),
  KEY `APPLICATIONID_INDEX` (`application_id`),
  KEY `TYPE_INDEX` (`type`),
  KEY `MULTI_INDEX` (`application_id`,`access`,`state`,`publish_up`,`publish_down`),
  KEY `MULTI_INDEX2` (`id`,`access`,`state`,`publish_up`,`publish_down`),
  KEY `ID_APPLICATION_INDEX` (`id`,`application_id`),
  FULLTEXT KEY `SEARCH_FULLTEXT` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `sdc98_zoo_item`
--

INSERT INTO `sdc98_zoo_item` (`id`, `application_id`, `type`, `name`, `alias`, `created`, `modified`, `modified_by`, `publish_up`, `publish_down`, `priority`, `hits`, `state`, `access`, `created_by`, `created_by_alias`, `searchable`, `elements`, `params`) VALUES
(1, 1, 'product', 'Сувенирная продукция', 'suvenirnaya-produkciya', '2014-07-18 13:42:45', '2014-07-21 08:39:34', 643, '2014-07-18 13:42:45', '0000-00-00 00:00:00', 0, 19, 1, 1, 643, '', 1, ' {\n	"f6bf4bf3-98d5-4741-af75-c1985b8728e3":  {\n		"0":  {\n			"file": "images\\/banners\\/back_main.png",\n			"title": "",\n			"link": "",\n			"target": "0",\n			"rel": ""\n		}\n	},\n	"fc498cea-a276-4ce7-9719-50526c5742d7":  {\n		"0":  {\n			"value": "\\u041e\\u0442\\u043a\\u0440\\u043e\\u0439 \\u0441\\u0432\\u043e\\u0439 \\u0441\\u0430\\u0439\\u0442 \\u0437\\u0430\\u043a\\u0430\\u0437\\u043e\\u0432 \\u043d\\u0430 \\u0441\\u0443\\u0432\\u0435\\u043d\\u0438\\u0438\\u0440\\u043d\\u0443\\u044e \\u043f\\u0440\\u043e\\u0434\\u0443\\u043a\\u0446\\u0438\\u044e"\n		}\n	},\n	"9f59fe6b-b76d-45f9-8cb7-3413012ae8df":  {\n		"0":  {\n			"value": "<p><span>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed posuere molestie lectus ut volutpat. Vivamus et venenatis mauris, posuere placerat ipsum. Proin lacinia orci est, vitae elementum tellus viverra ut. Nunc feugiat magna ac eros elementum aliquet. Nulla at porttitor odio. Quisque sed orci et orci scelerisque semper.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed posuere molestie lectus ut volutpat. Vivamus et venenatis mauris, posuere placerat ipsum. Proin lacinia orci est, vitae elementum tellus viverra ut. Nunc feugiat magna ac eros elementum aliquet. Nulla at porttitor odio. Quisque sed orci et orci scelerisque semper<\\/span><\\/p>\\r\\n<p><span>Vivamus et venenatis mauris, posuere placerat ipsum. Proin lacinia orci est, vitae elementum tellus viverra ut<\\/span><\\/p>"\n		}\n	},\n	"d1f9817c-a486-446f-91b2-955d8e4a3e6d":  {\n		"0":  {\n			"value": "<p><span>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed posuere molestie lectus ut volutpat. Vivamus et venenatis mauris, posuere placerat ipsum. Proin lacinia orci est, vitae elementum tellus viverra ut. Nunc feugiat magna ac eros elementum aliquet. Nulla at porttitor odio. Quisque sed orci et orci scelerisque semper.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed posuere molestie lectus ut volutpat. Vivamus et venenatis mauris, posuere placerat ipsum. Proin lacinia orci est, vitae elementum tellus viverra ut. Nunc feugiat magna ac eros elementum aliquet. Nulla at porttitor odio. Quisque sed orci et orci scelerisque semper<\\/span><\\/p>"\n		}\n	},\n	"17c85ebf-6a4e-498c-b0e1-5c0a19d59c87":  {\n		"0":  {\n			"value": "<p><span>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed posuere molestie lectus ut volutpat. Vivamus et venenatis mauris, posuere placerat ipsum. Proin lacinia orci est, vitae elementum tellus viverra ut. Nunc feugiat magna ac eros elementum aliquet. Nulla at porttitor odio. Quisque sed orci et orci scelerisque semper.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed posu\\u00a0orci est, vitae elementum tellus viverra ut. Nunc feugiat magna ac eros elementum aliquet. Nulla at porttitor odio. Quisque sed orci et orci scelerisque semper\\u00a0Vivamus et venenatis mauris, posuere placerat ipsum. Proin lacinia orci est, vitae elementum tellus viverra ut. Nunc feugiat magna ac eros elementum aliquet. Nulla at porttitor odio. Quisque sed orci et orci scelerisque semper<\\/span><\\/p>"\n		}\n	},\n	"223ad369-8472-47c6-94e8-18d804cf0f51":  {\n		"0":  {\n			"value": "<p><span>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed posuere molestie lectus ut volutpat. Vivamus et venenatis mauris, posuere placerat ipsum. Proin lacinia orci est, vitae elementum tellus viverra ut. Nunc feugiat magna ac eros elementum aliquet. Nulla at porttitor odio. Quisque sed orci et orci scelerisque semper.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed posuere molestie lectus ut volutpat. Vivamus et venenatis mauris, posuere placerat ipsum. Proin lacinia orci est, vitae elementum tellus viverra ut. Nunc feugiat magna ac eros elementum aliquet. Nulla at porttitor odio. Quisque sed orci et orci scelerisque semper\\u00a0Vivamus et venenatis mauris, posuere placerat ipsum. Proin lacinia orci est, vitae elementum tellus viverra ut. Nunc feugiat magna ac eros elementum aliquet. Nulla at porttitor odio. Quisque sed orci et orci scelerisque semper<\\/span><\\/p>"\n		}\n	},\n	"760604ad-f737-4cb5-9ccd-15f05ed9da19":  {\n		"0":  {\n			"file": "images\\/krywka.png",\n			"title": "\\u041a\\u0440\\u0443\\u0436\\u043a\\u0438",\n			"link": "",\n			"target": "0",\n			"rel": ""\n		},\n		"1":  {\n			"file": "images\\/krywka.png",\n			"title": "\\u0424\\u0443\\u0442\\u0431\\u043e\\u043b\\u043a\\u0438",\n			"link": "",\n			"target": "0",\n			"rel": ""\n		},\n		"2":  {\n			"file": "images\\/krywka.png",\n			"title": "\\u041f\\u043e\\u0434\\u0443\\u0448\\u043a\\u0438",\n			"link": "",\n			"target": "0",\n			"rel": ""\n		},\n		"3":  {\n			"file": "images\\/krywka.png",\n			"title": "\\u0411\\u0440\\u0435\\u043b\\u043e\\u043a\\u0438",\n			"link": "",\n			"target": "0",\n			"rel": ""\n		},\n		"4":  {\n			"file": "images\\/krywka.png",\n			"title": "\\u041f\\u0430\\u0437\\u043b\\u044b",\n			"link": "",\n			"target": "0",\n			"rel": ""\n		},\n		"5":  {\n			"file": "images\\/krywka.png",\n			"title": "\\u041a\\u0440\\u0443\\u0436\\u043a\\u04382",\n			"link": "",\n			"target": "0",\n			"rel": ""\n		},\n		"6":  {\n			"file": "images\\/krywka.png",\n			"title": "",\n			"link": "",\n			"target": "0",\n			"rel": ""\n		},\n		"7":  {\n			"file": "images\\/krywka.png",\n			"title": "\\u041f\\u043e\\u0434\\u0443\\u0448\\u043a\\u04382",\n			"link": "",\n			"target": "0",\n			"rel": ""\n		}\n	},\n	"991126ed-ac39-4c0d-abc0-b42058a85b6a":  {\n		"0":  {\n			"value": "<h3>\\u041e\\u043d\\u043b\\u0430\\u0439\\u043d \\u0440\\u0435\\u0448\\u0435\\u043d\\u0438\\u0435 \\u0434\\u043b\\u044f \\u0444\\u043e\\u0442\\u043e\\u0446\\u0435\\u043d\\u0442\\u0440\\u043e\\u0432, \\u043f\\u043e\\u043b\\u0438\\u0433\\u0440\\u0430\\u0444\\u0438\\u0447\\u0435\\u0441\\u043a\\u0438\\u0445 \\u0438 \\u0441\\u0443\\u0432\\u0435\\u043d\\u0438\\u0440\\u043d\\u044b\\u0445 \\u043a\\u043e\\u043c\\u043f\\u0430\\u043d\\u0438\\u0439<\\/h3>\\r\\n<p>\\u0417\\u0434\\u0435\\u0441\\u044c \\u0434\\u043e\\u043b\\u0436\\u043d\\u0430 \\u043a\\u0440\\u0430\\u0442\\u043a\\u043e \\u0440\\u0430\\u0441\\u0448\\u0438\\u0444\\u0440\\u043e\\u0432\\u044b\\u0432\\u0430\\u0442\\u044c\\u0441\\u044f \\u0441\\u0443\\u0442\\u044c \\u043f\\u0440\\u0435\\u0434\\u043b\\u043e\\u0436\\u0435\\u043d\\u0438\\u044f + \\u043f\\u0435\\u0440\\u0435\\u0447\\u0438\\u0441\\u043b\\u0435\\u043d\\u0438\\u0435 \\u043a\\u0430\\u043a\\u0438\\u0445-\\u0442\\u043e \\u043a\\u043b\\u044e\\u0447\\u0432\\u044b\\u0445 \\u043f\\u043b\\u044e\\u0449\\u0435\\u043a, \\u043a\\u043e\\u0442\\u043e\\u0440\\u044b\\u0435 \\u043f\\u043e\\u043b\\u0443\\u0447\\u0438\\u0442 \\u043a\\u043b\\u0438\\u0435\\u043d\\u0442. \\u0417\\u0434\\u0435\\u0441\\u044c \\u0434\\u043e\\u043b\\u0436\\u043d\\u0430 \\u043a\\u0440\\u0430\\u0442\\u043a\\u043e \\u0440\\u0430\\u0441\\u0448\\u0438\\u0444\\u0440\\u043e\\u0432\\u044b\\u0432\\u0430\\u0442\\u044c\\u0441\\u044f \\u0441\\u0443\\u0442\\u044c \\u043f\\u0440\\u0435\\u0434\\u043b\\u043e\\u0436\\u0435\\u043d\\u0438\\u044f + \\u043f\\u0435\\u0440\\u0435\\u0447\\u0438\\u0441\\u043b\\u0435\\u043d\\u0438\\u0435 \\u043a\\u0430\\u043a\\u0438\\u0445-\\u0442\\u043e \\u043a\\u043b\\u044e\\u0447\\u0432\\u044b\\u0445 \\u043f\\u043b\\u044e\\u0449\\u0435\\u043a, \\u043a\\u043e\\u0442\\u043e\\u0440\\u044b\\u0435 \\u043f\\u043e\\u043b\\u0443\\u0447\\u0438\\u0442 \\u043a\\u043b\\u0438\\u0435\\u043d\\u0442. \\u0417\\u0434\\u0435\\u0441\\u044c \\u0434\\u043e\\u043b\\u0436\\u043d\\u0430 \\u043a\\u0440\\u0430\\u0442\\u043a\\u043e \\u0440\\u0430\\u0441\\u0448\\u0438\\u0444\\u0440\\u043e\\u0432\\u044b\\u0432\\u0430\\u0442\\u044c\\u0441\\u044f \\u0441\\u0443\\u0442\\u044c \\u043f\\u0440\\u0435\\u0434\\u043b\\u043e \\u0436\\u0435\\u043d\\u0438\\u044f + \\u043f\\u0435\\u0440\\u0435\\u0447\\u0438\\u0441\\u043b\\u0435\\u043d\\u0438\\u0435 \\u043a\\u0430\\u043a\\u0438\\u0445-\\u0442\\u043e \\u043a\\u043b\\u044e\\u0447\\u0432\\u044b\\u0445 \\u043f\\u043b\\u044e\\u0449\\u0435\\u043a, \\u043a\\u043e\\u0442\\u043e\\u0440\\u044b\\u0435 \\u043f\\u043e\\u043b\\u0443\\u0447\\u0438\\u0442 \\u043a\\u043b\\u0438\\u0435\\u043d\\u0442.<\\/p>"\n		}\n	},\n	"6ae4eff9-ae4d-4d81-843d-e410772c6216":  {\n		"0":  {\n			"value": "<h3>\\u041b\\u044e\\u0431\\u044b\\u0435 \\u0432\\u0438\\u0434\\u044b \\u0441\\u0443\\u0432\\u0435\\u043d\\u0438\\u0440\\u043d\\u043e\\u0439 \\u043f\\u0440\\u043e\\u0434\\u0443\\u043a\\u0446\\u0438\\u0438<\\/h3>\\r\\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed posuere molestie lectus ut volutpat. Vivamus et venenatis mauris, posuere placerat ipsum. Proin lacinia orci est, vitae elementum tellus viverra ut. Nunc feugiat magna ac eros elementum aliquet. Nulla at porttitor odio. Quisque sed orci et orci scelerisque semper.<\\/p>"\n		}\n	},\n	"9d84de56-17b7-4a77-8fb0-830b550e0326":  {\n		"item":  {\n			"0": "2",\n			"1": "3",\n			"2": "5",\n			"3": "4"\n		}\n	}\n}', ' {\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": "",\n	"config.enable_comments": "1",\n	"config.primary_category": ""\n}'),
(2, 1, 'otzyv', 'Вася Пупкин', 'vasya-pupkin', '2014-07-21 08:07:17', '2014-07-21 08:09:27', 643, '2014-07-21 08:07:17', '0000-00-00 00:00:00', 0, 0, 1, 1, 643, '', 1, ' {\n	"f1d24f49-b005-445a-ba39-464495584b28":  {\n		"0":  {\n			"file": "images\\/boy.png",\n			"title": "",\n			"link": "",\n			"target": "0",\n			"rel": ""\n		}\n	},\n	"40edc4ec-c691-4ac7-95a3-a6f6a00ff962":  {\n		"0":  {\n			"value": "\\u0433\\u0435\\u043d\\u0435\\u0440\\u0430\\u043b\\u044c\\u043d\\u044b\\u0439 \\u0434\\u0438\\u0440\\u0435\\u043a\\u0442\\u043e\\u0440 \\u00ab\\u041a\\u043e\\u043c\\u043f\\u0430\\u043d\\u0438\\u0438\\u00bb"\n		}\n	},\n	"1c850df9-9085-4164-822d-e94fcfd546e7":  {\n		"0":  {\n			"value": "http:\\/\\/www.\\u0441\\u0430\\u0439\\u0442\\u043a\\u043e\\u043c\\u043f\\u0430\\u043d\\u0438\\u0438.\\u0440\\u0443",\n			"text": "",\n			"target": "0",\n			"custom_title": "",\n			"rel": ""\n		}\n	},\n	"f143880c-43d0-4814-9f20-b68f093cc67e":  {\n		"0":  {\n			"value": "<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed posuere molestie lectusut volutpat. Vivamus et venenatis mauris, posuere placerat ipsum. Proin laciniaorci est, vitae elementum tellus viverra ut. Nunc feugiat magna\\u201d ac eros elementum aliquet. Nulla at porttitor odio. Quisque sed orci et orci scelerisque semper.<\\/p>"\n		}\n	}\n}', ' {\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": "",\n	"config.enable_comments": "1",\n	"config.primary_category": ""\n}'),
(3, 1, 'otzyv', 'Вася Пупкин 2', 'vasya-pupkin-2', '2014-07-21 08:37:19', '2014-07-21 08:38:07', 643, '2014-07-21 08:07:17', '0000-00-00 00:00:00', 0, 0, 1, 1, 643, '', 1, ' {\n	"f1d24f49-b005-445a-ba39-464495584b28":  {\n		"0":  {\n			"file": "images\\/boy.png",\n			"title": "",\n			"link": "",\n			"target": "0",\n			"rel": ""\n		}\n	},\n	"40edc4ec-c691-4ac7-95a3-a6f6a00ff962":  {\n		"0":  {\n			"value": "\\u0433\\u0435\\u043d\\u0435\\u0440\\u0430\\u043b\\u044c\\u043d\\u044b\\u0439 \\u0434\\u0438\\u0440\\u0435\\u043a\\u0442\\u043e\\u0440 \\u00ab\\u041a\\u043e\\u043c\\u043f\\u0430\\u043d\\u0438\\u0438\\u00bb"\n		}\n	},\n	"1c850df9-9085-4164-822d-e94fcfd546e7":  {\n		"0":  {\n			"value": "http:\\/\\/www.\\u0441\\u0430\\u0439\\u0442\\u043a\\u043e\\u043c\\u043f\\u0430\\u043d\\u0438\\u0438.\\u0440\\u0443",\n			"text": "",\n			"target": "0",\n			"custom_title": "",\n			"rel": ""\n		}\n	},\n	"f143880c-43d0-4814-9f20-b68f093cc67e":  {\n		"0":  {\n			"value": "<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed posuere molestie lectusut volutpat. Vivamus et venenatis mauris, posuere placerat ipsum. Proin laciniaorci est, vitae elementum tellus viverra ut. Nunc feugiat magna\\u201d ac eros elementum aliquet. Nulla at porttitor odio. Quisque sed orci et orci scelerisque semper.<\\/p>"\n		}\n	}\n}', ' {\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": "",\n	"config.enable_comments": "1",\n	"config.primary_category": ""\n}'),
(4, 1, 'otzyv', 'Вася Пупкин 4', 'vasya-pupkin-4', '2014-07-21 08:37:28', '2014-07-21 08:38:46', 643, '2014-07-21 08:07:17', '0000-00-00 00:00:00', 0, 0, 1, 1, 643, '', 1, ' {\n	"f1d24f49-b005-445a-ba39-464495584b28":  {\n		"0":  {\n			"file": "images\\/boy.png",\n			"title": "",\n			"link": "",\n			"target": "0",\n			"rel": ""\n		}\n	},\n	"40edc4ec-c691-4ac7-95a3-a6f6a00ff962":  {\n		"0":  {\n			"value": "\\u0433\\u0435\\u043d\\u0435\\u0440\\u0430\\u043b\\u044c\\u043d\\u044b\\u0439 \\u0434\\u0438\\u0440\\u0435\\u043a\\u0442\\u043e\\u0440 \\u00ab\\u041a\\u043e\\u043c\\u043f\\u0430\\u043d\\u0438\\u0438\\u00bb"\n		}\n	},\n	"1c850df9-9085-4164-822d-e94fcfd546e7":  {\n		"0":  {\n			"value": "http:\\/\\/www.\\u0441\\u0430\\u0439\\u0442\\u043a\\u043e\\u043c\\u043f\\u0430\\u043d\\u0438\\u0438.\\u0440\\u0443",\n			"text": "",\n			"target": "0",\n			"custom_title": "",\n			"rel": ""\n		}\n	},\n	"f143880c-43d0-4814-9f20-b68f093cc67e":  {\n		"0":  {\n			"value": "<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed posuere molestie lectusut volutpat. Vivamus et venenatis mauris, posuere placerat ipsum. Proin laciniaorci est, vitae elementum tellus viverra ut. Nunc feugiat magna\\u201d ac eros elementum aliquet. Nulla at porttitor odio. Quisque sed orci et orci scelerisque semper.<\\/p>"\n		}\n	}\n}', ' {\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": "",\n	"config.enable_comments": "1",\n	"config.primary_category": ""\n}'),
(5, 1, 'otzyv', 'Вася Пупкин 3', 'vasya-pupkin-3', '2014-07-21 08:37:28', '2014-07-21 08:38:27', 643, '2014-07-21 08:07:17', '0000-00-00 00:00:00', 0, 0, 1, 1, 643, '', 1, ' {\n	"f1d24f49-b005-445a-ba39-464495584b28":  {\n		"0":  {\n			"file": "images\\/boy.png",\n			"title": "",\n			"link": "",\n			"target": "0",\n			"rel": ""\n		}\n	},\n	"40edc4ec-c691-4ac7-95a3-a6f6a00ff962":  {\n		"0":  {\n			"value": "\\u0433\\u0435\\u043d\\u0435\\u0440\\u0430\\u043b\\u044c\\u043d\\u044b\\u0439 \\u0434\\u0438\\u0440\\u0435\\u043a\\u0442\\u043e\\u0440 \\u00ab\\u041a\\u043e\\u043c\\u043f\\u0430\\u043d\\u0438\\u0438\\u00bb"\n		}\n	},\n	"1c850df9-9085-4164-822d-e94fcfd546e7":  {\n		"0":  {\n			"value": "http:\\/\\/www.\\u0441\\u0430\\u0439\\u0442\\u043a\\u043e\\u043c\\u043f\\u0430\\u043d\\u0438\\u0438.\\u0440\\u0443",\n			"text": "",\n			"target": "0",\n			"custom_title": "",\n			"rel": ""\n		}\n	},\n	"f143880c-43d0-4814-9f20-b68f093cc67e":  {\n		"0":  {\n			"value": "<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed posuere molestie lectusut volutpat. Vivamus et venenatis mauris, posuere placerat ipsum. Proin laciniaorci est, vitae elementum tellus viverra ut. Nunc feugiat magna\\u201d ac eros elementum aliquet. Nulla at porttitor odio. Quisque sed orci et orci scelerisque semper.<\\/p>"\n		}\n	}\n}', ' {\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": "",\n	"config.enable_comments": "1",\n	"config.primary_category": ""\n}');

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_zoo_jbzoo_index`
--

CREATE TABLE IF NOT EXISTS `sdc98_zoo_jbzoo_index` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `element_id` varchar(50) NOT NULL,
  `value_number` double DEFAULT NULL,
  `value_datetime` datetime DEFAULT NULL,
  `value_string` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `element_id_value_number` (`element_id`,`value_number`),
  KEY `element_id_value_datetime` (`element_id`,`value_datetime`),
  KEY `value_string` (`value_string`),
  KEY `item_id` (`item_id`),
  KEY `element_id_value_string` (`element_id`,`value_string`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=243 ;

--
-- Дамп данных таблицы `sdc98_zoo_jbzoo_index`
--

INSERT INTO `sdc98_zoo_jbzoo_index` (`id`, `item_id`, `element_id`, `value_number`, `value_datetime`, `value_string`) VALUES
(242, 1, '_itempublish_up', NULL, '2014-07-18 13:42:45', NULL),
(241, 1, '_itemmodified', NULL, '2014-07-21 08:39:34', NULL),
(239, 1, '_itempublish_up', 2014, NULL, NULL),
(240, 1, '_itemcreated', NULL, '2014-07-18 13:42:45', NULL),
(238, 1, '_itempublish_down', 0, NULL, NULL),
(236, 1, '_itemfrontpage', 0, NULL, NULL),
(237, 1, '_itemmodified', 2014, NULL, NULL),
(233, 1, '_itempublish_up', NULL, NULL, '2014-07-18 13:42:45'),
(234, 1, '_itemauthor', 643, NULL, NULL),
(235, 1, '_itemcreated', 2014, NULL, NULL),
(232, 1, '_itempublish_down', NULL, NULL, '0000-00-00 00:00:00'),
(227, 1, '_itemauthor', NULL, NULL, '643'),
(228, 1, '_itemcreated', NULL, NULL, '2014-07-18 13:42:45'),
(229, 1, '_itemfrontpage', NULL, NULL, '0'),
(230, 1, '_itemmodified', NULL, NULL, '2014-07-21 08:39:34'),
(225, 1, '760604ad-f737-4cb5-9ccd-15f05ed9da19', NULL, NULL, 'Кружки2'),
(231, 1, '_itemname', NULL, NULL, 'Сувенирная продукция'),
(226, 1, '760604ad-f737-4cb5-9ccd-15f05ed9da19', NULL, NULL, 'Подушки2'),
(224, 1, '760604ad-f737-4cb5-9ccd-15f05ed9da19', NULL, NULL, 'Пазлы'),
(223, 1, '760604ad-f737-4cb5-9ccd-15f05ed9da19', NULL, NULL, 'Брелоки'),
(220, 1, '760604ad-f737-4cb5-9ccd-15f05ed9da19', NULL, NULL, 'Кружки'),
(221, 1, '760604ad-f737-4cb5-9ccd-15f05ed9da19', NULL, NULL, 'Футболки'),
(222, 1, '760604ad-f737-4cb5-9ccd-15f05ed9da19', NULL, NULL, 'Подушки'),
(59, 2, '40edc4ec-c691-4ac7-95a3-a6f6a00ff962', NULL, NULL, 'генеральный директор «Компании»'),
(60, 2, '_itemauthor', NULL, NULL, '643'),
(61, 2, '_itemcreated', NULL, NULL, '2014-07-21 08:07:17'),
(62, 2, '_itemfrontpage', NULL, NULL, '0'),
(63, 2, '_itemmodified', NULL, NULL, '2014-07-21 08:09:27'),
(64, 2, '_itemname', NULL, NULL, 'Вася Пупкин'),
(65, 2, '_itempublish_down', NULL, NULL, '0000-00-00 00:00:00'),
(66, 2, '_itempublish_up', NULL, NULL, '2014-07-21 08:07:17'),
(67, 2, '_itemauthor', 643, NULL, NULL),
(68, 2, '_itemcreated', 2014, NULL, NULL),
(69, 2, '_itemfrontpage', 0, NULL, NULL),
(70, 2, '_itemmodified', 2014, NULL, NULL),
(71, 2, '_itempublish_down', 0, NULL, NULL),
(72, 2, '_itempublish_up', 2014, NULL, NULL),
(73, 2, '_itemcreated', NULL, '2014-07-21 08:07:17', NULL),
(74, 2, '_itemmodified', NULL, '2014-07-21 08:09:27', NULL),
(75, 2, '_itempublish_up', NULL, '2014-07-21 08:07:17', NULL),
(219, 1, 'fc498cea-a276-4ce7-9719-50526c5742d7', NULL, NULL, 'Открой свой сайт заказов на сувениирную продукцию'),
(179, 3, '_itemmodified', 2014, NULL, NULL),
(181, 3, '_itempublish_up', 2014, NULL, NULL),
(180, 3, '_itempublish_down', 0, NULL, NULL),
(178, 3, '_itemfrontpage', 0, NULL, NULL),
(177, 3, '_itemcreated', 2014, NULL, NULL),
(176, 3, '_itemauthor', 643, NULL, NULL),
(175, 3, '_itempublish_up', NULL, NULL, '2014-07-21 08:07:17'),
(174, 3, '_itempublish_down', NULL, NULL, '0000-00-00 00:00:00'),
(173, 3, '_itemname', NULL, NULL, 'Вася Пупкин 2'),
(170, 3, '_itemcreated', NULL, NULL, '2014-07-21 08:37:19'),
(171, 3, '_itemfrontpage', NULL, NULL, '0'),
(172, 3, '_itemmodified', NULL, NULL, '2014-07-21 08:38:07'),
(212, 4, '_itemfrontpage', 0, NULL, NULL),
(213, 4, '_itemmodified', 2014, NULL, NULL),
(211, 4, '_itemcreated', 2014, NULL, NULL),
(210, 4, '_itemauthor', 643, NULL, NULL),
(209, 4, '_itempublish_up', NULL, NULL, '2014-07-21 08:07:17'),
(208, 4, '_itempublish_down', NULL, NULL, '0000-00-00 00:00:00'),
(207, 4, '_itemname', NULL, NULL, 'Вася Пупкин 4'),
(206, 4, '_itemmodified', NULL, NULL, '2014-07-21 08:38:46'),
(205, 4, '_itemfrontpage', NULL, NULL, '0'),
(204, 4, '_itemcreated', NULL, NULL, '2014-07-21 08:37:28'),
(203, 4, '_itemauthor', NULL, NULL, '643'),
(202, 4, '40edc4ec-c691-4ac7-95a3-a6f6a00ff962', NULL, NULL, 'генеральный директор «Компании»'),
(195, 5, '_itemfrontpage', 0, NULL, NULL),
(196, 5, '_itemmodified', 2014, NULL, NULL),
(194, 5, '_itemcreated', 2014, NULL, NULL),
(193, 5, '_itemauthor', 643, NULL, NULL),
(192, 5, '_itempublish_up', NULL, NULL, '2014-07-21 08:07:17'),
(191, 5, '_itempublish_down', NULL, NULL, '0000-00-00 00:00:00'),
(190, 5, '_itemname', NULL, NULL, 'Вася Пупкин 3'),
(189, 5, '_itemmodified', NULL, NULL, '2014-07-21 08:38:27'),
(188, 5, '_itemfrontpage', NULL, NULL, '0'),
(187, 5, '_itemcreated', NULL, NULL, '2014-07-21 08:37:28'),
(186, 5, '_itemauthor', NULL, NULL, '643'),
(185, 5, '40edc4ec-c691-4ac7-95a3-a6f6a00ff962', NULL, NULL, 'генеральный директор «Компании»'),
(169, 3, '_itemauthor', NULL, NULL, '643'),
(168, 3, '40edc4ec-c691-4ac7-95a3-a6f6a00ff962', NULL, NULL, 'генеральный директор «Компании»'),
(182, 3, '_itemcreated', NULL, '2014-07-21 08:37:19', NULL),
(183, 3, '_itemmodified', NULL, '2014-07-21 08:38:07', NULL),
(184, 3, '_itempublish_up', NULL, '2014-07-21 08:07:17', NULL),
(197, 5, '_itempublish_down', 0, NULL, NULL),
(198, 5, '_itempublish_up', 2014, NULL, NULL),
(199, 5, '_itemcreated', NULL, '2014-07-21 08:37:28', NULL),
(200, 5, '_itemmodified', NULL, '2014-07-21 08:38:27', NULL),
(201, 5, '_itempublish_up', NULL, '2014-07-21 08:07:17', NULL),
(214, 4, '_itempublish_down', 0, NULL, NULL),
(215, 4, '_itempublish_up', 2014, NULL, NULL),
(216, 4, '_itemcreated', NULL, '2014-07-21 08:37:28', NULL),
(217, 4, '_itemmodified', NULL, '2014-07-21 08:38:46', NULL),
(218, 4, '_itempublish_up', NULL, '2014-07-21 08:07:17', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_zoo_rating`
--

CREATE TABLE IF NOT EXISTS `sdc98_zoo_rating` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) DEFAULT NULL,
  `element_id` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `value` tinyint(4) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_zoo_search_index`
--

CREATE TABLE IF NOT EXISTS `sdc98_zoo_search_index` (
  `item_id` int(11) NOT NULL,
  `element_id` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`item_id`,`element_id`),
  FULLTEXT KEY `SEARCH_FULLTEXT` (`value`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sdc98_zoo_search_index`
--

INSERT INTO `sdc98_zoo_search_index` (`item_id`, `element_id`, `value`) VALUES
(1, '6ae4eff9-ae4d-4d81-843d-e410772c6216', 'Любые виды сувенирной продукции\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Sed posuere molestie lectus ut volutpat. Vivamus et venenatis mauris, posuere placerat ipsum. Proin lacinia orci est, vitae elementum tellus viverra ut. Nunc feugiat magna ac eros elementum aliquet. Nulla at porttitor odio. Quisque sed orci et orci scelerisque semper.'),
(1, '760604ad-f737-4cb5-9ccd-15f05ed9da19', 'Кружки\nФутболки\nПодушки\nБрелоки\nПазлы\nКружки2\n\nПодушки2'),
(1, '991126ed-ac39-4c0d-abc0-b42058a85b6a', 'Онлайн решение для фотоцентров, полиграфических и сувенирных компаний\r\nЗдесь должна кратко расшифровываться суть предложения + перечисление каких-то ключвых плющек, которые получит клиент. Здесь должна кратко расшифровываться суть предложения + перечисление каких-то ключвых плющек, которые получит клиент. Здесь должна кратко расшифровываться суть предло жения + перечисление каких-то ключвых плющек, которые получит клиент.'),
(1, '223ad369-8472-47c6-94e8-18d804cf0f51', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed posuere molestie lectus ut volutpat. Vivamus et venenatis mauris, posuere placerat ipsum. Proin lacinia orci est, vitae elementum tellus viverra ut. Nunc feugiat magna ac eros elementum aliquet. Nulla at porttitor odio. Quisque sed orci et orci scelerisque semper.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed posuere molestie lectus ut volutpat. Vivamus et venenatis mauris, posuere placerat ipsum. Proin lacinia orci est, vitae elementum tellus viverra ut. Nunc feugiat magna ac eros elementum aliquet. Nulla at porttitor odio. Quisque sed orci et orci scelerisque semper Vivamus et venenatis mauris, posuere placerat ipsum. Proin lacinia orci est, vitae elementum tellus viverra ut. Nunc feugiat magna ac eros elementum aliquet. Nulla at porttitor odio. Quisque sed orci et orci scelerisque semper'),
(1, 'fc498cea-a276-4ce7-9719-50526c5742d7', 'Открой свой сайт заказов на сувениирную продукцию'),
(1, '9f59fe6b-b76d-45f9-8cb7-3413012ae8df', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed posuere molestie lectus ut volutpat. Vivamus et venenatis mauris, posuere placerat ipsum. Proin lacinia orci est, vitae elementum tellus viverra ut. Nunc feugiat magna ac eros elementum aliquet. Nulla at porttitor odio. Quisque sed orci et orci scelerisque semper.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed posuere molestie lectus ut volutpat. Vivamus et venenatis mauris, posuere placerat ipsum. Proin lacinia orci est, vitae elementum tellus viverra ut. Nunc feugiat magna ac eros elementum aliquet. Nulla at porttitor odio. Quisque sed orci et orci scelerisque semper\r\nVivamus et venenatis mauris, posuere placerat ipsum. Proin lacinia orci est, vitae elementum tellus viverra ut'),
(1, 'd1f9817c-a486-446f-91b2-955d8e4a3e6d', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed posuere molestie lectus ut volutpat. Vivamus et venenatis mauris, posuere placerat ipsum. Proin lacinia orci est, vitae elementum tellus viverra ut. Nunc feugiat magna ac eros elementum aliquet. Nulla at porttitor odio. Quisque sed orci et orci scelerisque semper.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed posuere molestie lectus ut volutpat. Vivamus et venenatis mauris, posuere placerat ipsum. Proin lacinia orci est, vitae elementum tellus viverra ut. Nunc feugiat magna ac eros elementum aliquet. Nulla at porttitor odio. Quisque sed orci et orci scelerisque semper'),
(1, '17c85ebf-6a4e-498c-b0e1-5c0a19d59c87', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed posuere molestie lectus ut volutpat. Vivamus et venenatis mauris, posuere placerat ipsum. Proin lacinia orci est, vitae elementum tellus viverra ut. Nunc feugiat magna ac eros elementum aliquet. Nulla at porttitor odio. Quisque sed orci et orci scelerisque semper.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed posu orci est, vitae elementum tellus viverra ut. Nunc feugiat magna ac eros elementum aliquet. Nulla at porttitor odio. Quisque sed orci et orci scelerisque semper Vivamus et venenatis mauris, posuere placerat ipsum. Proin lacinia orci est, vitae elementum tellus viverra ut. Nunc feugiat magna ac eros elementum aliquet. Nulla at porttitor odio. Quisque sed orci et orci scelerisque semper'),
(2, '40edc4ec-c691-4ac7-95a3-a6f6a00ff962', 'генеральный директор «Компании»'),
(2, 'f143880c-43d0-4814-9f20-b68f093cc67e', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed posuere molestie lectusut volutpat. Vivamus et venenatis mauris, posuere placerat ipsum. Proin laciniaorci est, vitae elementum tellus viverra ut. Nunc feugiat magna” ac eros elementum aliquet. Nulla at porttitor odio. Quisque sed orci et orci scelerisque semper.'),
(3, 'f143880c-43d0-4814-9f20-b68f093cc67e', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed posuere molestie lectusut volutpat. Vivamus et venenatis mauris, posuere placerat ipsum. Proin laciniaorci est, vitae elementum tellus viverra ut. Nunc feugiat magna” ac eros elementum aliquet. Nulla at porttitor odio. Quisque sed orci et orci scelerisque semper.'),
(4, '40edc4ec-c691-4ac7-95a3-a6f6a00ff962', 'генеральный директор «Компании»'),
(4, 'f143880c-43d0-4814-9f20-b68f093cc67e', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed posuere molestie lectusut volutpat. Vivamus et venenatis mauris, posuere placerat ipsum. Proin laciniaorci est, vitae elementum tellus viverra ut. Nunc feugiat magna” ac eros elementum aliquet. Nulla at porttitor odio. Quisque sed orci et orci scelerisque semper.'),
(5, '40edc4ec-c691-4ac7-95a3-a6f6a00ff962', 'генеральный директор «Компании»'),
(5, 'f143880c-43d0-4814-9f20-b68f093cc67e', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed posuere molestie lectusut volutpat. Vivamus et venenatis mauris, posuere placerat ipsum. Proin laciniaorci est, vitae elementum tellus viverra ut. Nunc feugiat magna” ac eros elementum aliquet. Nulla at porttitor odio. Quisque sed orci et orci scelerisque semper.'),
(3, '40edc4ec-c691-4ac7-95a3-a6f6a00ff962', 'генеральный директор «Компании»');

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_zoo_submission`
--

CREATE TABLE IF NOT EXISTS `sdc98_zoo_submission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `application_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `state` tinyint(3) NOT NULL,
  `access` int(11) NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ALIAS_INDEX` (`alias`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_zoo_tag`
--

CREATE TABLE IF NOT EXISTS `sdc98_zoo_tag` (
  `item_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`item_id`,`name`),
  UNIQUE KEY `NAME_ITEMID_INDEX` (`name`,`item_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `sdc98_zoo_version`
--

CREATE TABLE IF NOT EXISTS `sdc98_zoo_version` (
  `version` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sdc98_zoo_version`
--

INSERT INTO `sdc98_zoo_version` (`version`) VALUES
('3.1.6');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
